#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function
import pandas as pd
from lib_util import pyetl
from lib_util import lib_log
from collections import OrderedDict
from lib_util import get_filename
from socket import gethostname
from lib_util import utilities
from lib_util import lib_log
# import re
# import codecs
from csv import QUOTE_ALL,QUOTE_MINIMAL,QUOTE_NONE,QUOTE_NONNUMERIC
import os,re
import codecs
# import numpy as np
from datetime import date, timedelta, datetime
import gc
# import math
# from decimal import Decimal, ROUND_HALF_UP, ROUND_FLOOR, ROUND_CEILING


logger = lib_log.Logger()


class LoadFile(pyetl.FilePyEtl):
    def __init__(self, base_directory, input_dir, output_dir):
        super(LoadFile, self).__init__()
        self.empty_df_flag = True
        self.base_directory = base_directory
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.files_data = OrderedDict([
            ('company', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "company.txt"),
                "sep": "|",
                "usecols": ['company_code','company_name','job_status','iconum','jurisdiction_incorporated'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),


            ('fight', {

                "path_or_buf": os.path.join(self.input_dir,
                                            "fight.txt"),
                "sep": "|",
                "usecols": ['company_code','id','announce_date','campaign_type_cd','proxy_fight_flg','title','marketcap','fight_synopsis'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('company_identifier', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "company_identifier.txt"),
                "sep": "|",
                "usecols": ['company_code','code','identifier'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('company_sic', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "company_sic.txt"),
                "sep": "|",
                "usecols": ['company_code','sic_code','seq'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('SR_LookupFightCampaignType', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "SR_LookupFightCampaignType.txt"),
                "sep": "|",
                "usecols": ['Code','Description'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('SR_LookupFilingType', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "SR_LookupFilingType.txt"),
                "sep": "|",
                "usecols": ['Code','Description'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('company_ticker', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "company_ticker.txt"),
                "sep": "|",
                "usecols": ['company_code','primary_listing','stock_exchange','ticker'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('filermst', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "filermst.txt"),
                "sep": "|",
                "usecols": ['iconum','sect_code','ind_code'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('sector', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "sector.txt"),
                "sep": "|",
                "usecols": ['sect_code','sector'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('industries', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "industries.txt"),
                "sep": "|",
                "usecols": ['ind_code','industry'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('fight_source', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "fight_source.txt"),
                "sep": "|",
                "usecols": ['seat_granted_to_dissident_flg', 'contentious_13d_item_flg','publish_flg', 'unsolicited_hostile_flg', 'description','special_exhibit_cd', 'source_type_cd','dissident_filing_flg','fight_id','filing_date','proxy_fight_formal_notice_flg'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('fight_participant', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "fight_participant.txt"),
                "sep": "|",
                "usecols": ['fight_id','participant_cd'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('proponent_lookup', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "proponent_lookup.txt"),
                "sep": "|",
                "usecols": ['core_activist_flg','iconum','id'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),
             ])

        # self.results = OrderedDict([

        #     ('temp_shark_news', {
        #         "path_or_buf":os.path.join(self.output_dir,
        #                                    "temp_shark_news.txt"),
        #         "sep":"|",
        #         "encoding": 'latin-1',
        #         "quoting":QUOTE_ALL,
        #         "index":False,
        #     }),
                                                                                 
        #  ])

         
    def transform(self):
        #merge all the left joines for one dataframe
        company = self.company.copy()
        fight = self.fight.copy()
        fight_source = self.fight_source.copy()
        SR_LookupFightCampaignType = self.SR_LookupFightCampaignType.copy()
        SR_LookupFilingType = self.SR_LookupFilingType.copy()
        company_identifier = self.company_identifier.copy()
        filermst = self.filermst.copy()
        sector = self.sector.copy()
        industries = self.industries.copy()
        company_sic = self.company_sic.copy()
        company_ticker = self.company_ticker.copy()
        fight_participant = self.fight_participant.copy()
        proponent_lookup = self.proponent_lookup.copy()

        #Strip all the LTRIM,RTRIM
        company.job_status = company.job_status.str.strip()
        fight.campaign_type_cd = fight.campaign_type_cd.str.strip()
        fight_source.source_type_cd = fight_source.source_type_cd.str.strip()
        fight_source.source_type_cd = fight_source.special_exhibit_cd.str.strip()
        SR_LookupFightCampaignType.Code = SR_LookupFightCampaignType.Code.str.strip()
        SR_LookupFilingType.code = SR_LookupFilingType.Code.str.strip()
        company_identifier.identifier = company_identifier.identifier.str.strip()
        sector.sector = sector.sector.str.strip()
        industries.industry = industries.industry.str.strip()

        #res2 will create 2nd df(two) = Significant Developments
        res2 = company.merge(fight, how ='left',on=["company_code"]) 
        res2 = res2.merge(fight_source, how ='left',left_on=["id"], right_on=["fight_id"]) 
        res2= res2.merge(SR_LookupFightCampaignType, how ='left', left_on=["campaign_type_cd"], right_on=["Code"])
        res2= res2.merge(SR_LookupFilingType, how ='left', left_on=["source_type_cd"], right_on=["Code"])
        company_identifier2 = company_identifier[company_identifier.identifier == 'CUSIP']
        res2= res2.merge(company_identifier2,how ='left', on=["company_code"])
        res2= res2.merge(filermst, how ='left', on=["iconum"])
        res2= res2.merge(sector, how ='left', on=["sect_code"])
        res2= res2.merge(industries, how ='left', on=["ind_code"])
        company_sic2 = company_sic[company_sic.seq==1]
        res2= res2.merge(company_sic2,how ='left', on=["company_code"])
        company_ticker1 = company_ticker[company_ticker.primary_listing==-1]
        res2= res2.merge(company_ticker1, how ='left', on=["company_code"])
        res2= res2.merge(fight_participant, how ='left', left_on=["id"], right_on=["fight_id"])
        res2= res2.merge(proponent_lookup, how ='left', left_on=["participant_cd"], right_on=["id"])
        print(len(res2))
        
        res2.job_status = res2.job_status.fillna('WIP')
        res2 = res2[res2['job_status'].isin(["APR" ,"CHIP"])]  
        res2.campaign_type_cd = res2.campaign_type_cd.fillna('XXX')
        res2 = res2[~res2['campaign_type_cd'].isin(['13DFILER'])] 
        res2 = res2[~res2['announce_date'].isin(res2['filing_date'])]
        res2 = res2[res2.announce_date > '2006-01-01 00:00:00.000']
        res2 = res2[pd.to_datetime(res2.filing_date) >= (datetime.now() - timedelta(days=10))]
       
        res2['fight_id'] = res2.id_x.astype('int')
        res2.drop(['fight_id_x','id_x','fight_id_y'], axis=1, inplace=True)
        date=pd.to_datetime(res2['announce_date']).dt.strftime('%Y%m%d').astype('str')
        fid=res2['fight_id'].astype('str')
        res2['story_id'] = date+fid
        res2['type'] = 'new'
        f = lambda x: 1 if x==True else 0
        na = lambda x: 0 if pd.x==null else x
        na_x = lambda x: 'XXX' if pd.x==null else x
        res2.unsolicited_hostile_flg = res2.unsolicited_hostile_flg.apply(f)
        res2.proxy_fight_formal_notice_flg = res2.proxy_fight_formal_notice_flg.apply(f)
        res2.proxy_fight_flg = res2.proxy_fight_flg.apply(f)
        res2.publish_flg = res2.publish_flg.apply(f)
        res2.seat_granted_to_dissident_flg = res2.seat_granted_to_dissident_flg.apply(f)
        res2.dissident_filing_flg = res2.dissident_filing_flg.apply(f)
        res2.contentious_13d_item_flg = res2.contentious_13d_item_flg.apply(f)

        def headline2(unsolicited_hostile_flg,announce_date,filing_date,title,description,proxy_fight_formal_notice_flg,\
                        special_exhibit_cd,proxy_fight_flg,publish_flg, dissident_filing_flg, seat_granted_to_dissident_flg,\
                       contentious_13d_item_flg,source_type_cd ):
            unsolicited_hostile_flg = unsolicited_hostile_flg.apply(na)
            if unsolicited_hostile_flg in (1,-1) and announce_date>'2006-01-01 00:00:00.000' and pd.to_datetime(filing_date) >= (datetime.now() - timedelta(days=10)):
                return 'Update to '+title+' Activist Campaign - '+description+' Discloses Unsolicited Offer'      #--Priority #2
            proxy_fight_formal_notice_flg = proxy_fight_formal_notice_flg.apply(na)
            if proxy_fight_formal_notice_flg in (1,-1):
                return title+' Activist Campaign Escalated to Formal Proxy Fight'                                 #--Priority #3
            special_exhibit_cd = special_exhibit_cd.fillna('XXX')
            if str(special_exhibit_cd) =='SETTLE':
                concate_1= 'Settlement Agreement Disclosed Ending '+title                                          #--Priority #4a
                concate_2= ' Proxy Fight' if proxy_fight_flg.fillna(0) in (1,-1) else ' Activist Campaign'
                return concate_1+concate_2
            if str(special_exhibit_cd) =='STAND':
                concate_1= 'Standstill Agreement Disclosed Ending '+title                                          #--Priority #4b
                concate_2= ' Proxy Fight' if proxy_fight_flg.fillna(0) in (1,-1) else ' Activist Campaign'
                return concate_1+concate_2
            publish_flg = publish_flg.fillna(0)
            dissident_filing_flg = dissident_filing_flg.fillna(0)
            proxy_fight_flg = proxy_fight_flg.fillna(0)
            seat_granted_to_dissident_flg = seat_granted_to_dissident_flg.fillna(0)
            contentious_13d_item_flg = contentious_13d_item_flg.fillna(0)
            source_type_cd = source_type_cd.fillna('XXX')
            #special_exhibit_cd = special_exhibit_cd.fillna('XXX')

            if publish_flg in (1, -1) and dissident_filing_flg == 0:
                concate_1= 'Standstill Agreement Disclosed Ending '+title                                           #--Priority #5
                concate_2= ' Proxy Fight' if proxy_fight_flg in (1,-1) else ' Activist Campaign'
                return concate_1+concate_2
            if seat_granted_to_dissident_flg in (1, -1):
                concate_1= 'Update to '+ title                                                                      #--Priority #6                
                concate_2= ' Proxy Fight - Board Representation Granted to Activist' if proxy_fight_flg in (1,-1) else ' Activist Campaign - Board Representation Granted to Activist'
                return concate_1+concate_2
            if dissident_filing_flg in (1, -1) and source_type_cd in ('DEFC14A', 'DEFC14C', 'DEFN14A') and special_exhibit_cd.isnull(): 
                return 'Dissident Definitive Contested Proxy Filed in ' + title + ' Proxy Fight'  #--Priority #7
            if dissident_filing_flg in (1, -1) and source_type_cd in ('PREC14A', 'PREC14C', 'PREN14A') and special_exhibit_cd.isnull(): 
                return 'Dissident Preliminary Contested Proxy Filed in ' + title + ' Proxy Fight'  #--Priority #8
            if dissident_filing_flg in (1, -1) and special_exhibit_cd.fillna('XXX') == 'BOARD_LETTER' : 
                return 'Update to ' + title + ' Activist Campaign - ' + e.description + ' Discloses Letter to Board' #--Priority #9
            if dissident_filing_flg in (1, -1) and source_type_cd == 'PR' and special_exhibit_cd.isnull() : 
                return 'Update to ' + title + ' Campaign - New Activist Press Release Disclosed' #--Priority #10
            if dissident_filing_flg in (1, -1) and source_type_cd == '13D/A' and contentious_13d_item_flg in (1, -1) and special_exhibit_cd.IsNull() : 
                return 'Update to ' + title + ' Activist Campaign - Hostile 13D/A Filed' #--Priority #11
    
        res2['headline']=res2[['unsolicited_hostile_flg','announce_date','filing_date','title','description','proxy_fight_formal_notice_flg',\
                        'special_exhibit_cd','proxy_fight_flg','publish_flg','dissident_filing_flg', 'seat_granted_to_dissident_flg',\
                       'contentious_13d_item_flg','source_type_cd']].apply(lambda x:headline2(x['unsolicited_hostile_flg'] ,\
                        x['announce_date'] ,x['filing_date'] , x['title'] ,x['description'] ,x['proxy_fight_formal_notice_flg'] ,\
                        x['special_exhibit_cd'] ,x['proxy_fight_flg'],x['publish_flg'],x['dissident_filing_flg'],x['seat_granted_to_dissident_flg'],\
                        x['contentious_13d_item_flg'],x['source_type_cd']),axis=1)
                                                                                                                                                                                                          
        def headline_rank2(unsolicited_hostile_flg, announce_date, filing_date,proxy_fight_formal_notice_flg,special_exhibit_cd,\
                        publish_flg,dissident_filing_flg,seat_granted_to_dissident_flg,source_type_cd,contentious_13d_item_flg):
            unsolicited_hostile_flg = unsolicited_hostile_flg.fillna(0)
            if unsolicited_hostile_flg in (1, -1) and announce_date > '2006-01-01 00:00:00.000' and pd.to_datetime(filing_date) >= (datetime.now() - timedelta(days=10)):
                return 2  #--Priority #2
            proxy_fight_formal_notice_flg = proxy_fight_formal_notice_flg.fillna(0)
            if proxy_fight_formal_notice_flg in (1, -1):
                return 3 #--Priority #3
            special_exhibit_cd = special_exhibit_cd.fillna('XXX')
            if special_exhibit_cd_ == 'SETTLE':
                return 4 #--Priority #4a
            if special_exhibit_cd_ == 'STAND':
                return 5 #--Priority #4b
            publish_flg = publish_flg.fillna(0)
            dissident_filing_flg = dissident_filing_flg.fillna(0)
            if publish_flg in (1, -1) and dissident_filing_flg == 0:
                return 6 #--Priority #5
            seat_granted_to_dissident_flg = seat_granted_to_dissident_flg.fillna(0)
            if seat_granted_to_dissident_flg in (1, -1):
                return 7 #--Priority #6
            source_type_cd = source_type_cd.fillna('XXX')
            if dissident_filing_flg in (1, -1) and source_type_cd in ('DEFC14A', 'DEFC14C', 'DEFN14A') and special_exhibit_cd.isnull():
                return 8 #--Priority #7
            if dissident_filing_flg in (1, -1) and source_type_cd in ('PREC14A', 'PREC14C', 'PREN14A') and special_exhibit_cd.isnull() :     #--Priority #8
                return 9
            if dissident_filing_flg in (1, -1) and special_exhibit_cd == 'BOARD_LETTER':    #--Priority #9
                return 10
            if dissident_filing_flg in (1, -1) and source_type_cd == 'PR' and special_exhibit_cd.isnull() :
                return 11       #--Priority #10
            
            contentious_13d_item_flg = contentious_13d_item_flg.fillna(0)
            if dissident_filing_flg in (1, -1) and source_type_cd == '13D/A' and contentious_13d_item_flg in (1, -1) and special_exhibit_cd.isnull():
                return 12      #--Priority #11
            
        res2['headline_rank'] = res2[['unsolicited_hostile_flg', 'announce_date', 'filing_date','proxy_fight_formal_notice_flg','special_exhibit_cd',\
                        'publish_flg','dissident_filing_flg','seat_granted_to_dissident_flg','source_type_cd','contentious_13d_item_flg']]\
                        .apply(lambda x:headline_rank2(x['unsolicited_hostile_flg'] ,x['announce_date'] ,x['filing_date'] ,\
                         x['proxy_fight_formal_notice_flg'] ,x['special_exhibit_cd'],x['publish_flg'],x['dissident_filing_flg'],\
                         x['seat_granted_to_dissident_flg'],x['source_type_cd'],x['contentious_13d_item_flg']),axis=1)
                        
        res2['publication_date']= pd.to_datetime(res2.filing_date)
        x= datetime.now().strftime('%H%M%S')
        res2.loc[res2['filing_date']==pd.datetime.now(),'publication_time']=x
        res2.loc[res2['filing_date']!=pd.datetime.now(),'publication_time']='180000'  
        res2['language'] = 'en'
        res2['cusip'] = res2.code
        res2['factset_id'] = res2['iconum_x'].astype('int')
        res2['event_type'] = 'Significant Developments'
        res2['fds_sector'] = res2['sect_code'].astype('int')
        res2['fds_sector_name'] = res2['sector']
        res2['fds_industry'] = res2['ind_code'].astype('int')
        res2['fds_industry_name'] = res2['industry']
        res2['jurisdiction_incorporated'] = res2['jurisdiction_incorporated'].fillna('United States')
        res2['market_cap'] = res2.marketcap
        res2['sic_code'] = res2['sic_code']#.astype('int')
        res2['campaign_type'] = res2['Description']
        res2['campaign_summary'] = res2['fight_synopsis']
        res2['delivery_timestamp'] = datetime.now().strftime('%Y%m%d%H%M%S')
        res2['company_name'] = res2['company_name']
        res2['company_ticker'] = res2['ticker']
        res2['company_stock_exchange'] = res2['stock_exchange']
        res2['company_parent_name'] = res2['company_name']
        res2['company_parent_ticker'] = res2['ticker']
        res2['company_parent_stock_exchange'] = res2['stock_exchange']
        res2['company_parent_cusip'] = res2['code']
        res2['company_parent_factset_id'] = res2['iconum_x'].astype('int')
        res2['sharkwatch_50_member'] = res2['core_activist_flg'].apply(f)
        res2['proponent_iconum'] = res2['iconum_y']#.astype('int')

        res2.sort_values(by=['fight_id'], inplace=True)
        #res2 = res2.loc[res2['headline'].notnull()]

        res2['headline'] = res2['headline'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res2['fds_sector_name'] = res2['fds_sector_name'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res2['fds_industry_name'] = res2['fds_industry_name'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res2['jurisdiction_incorporated'] = res2['jurisdiction_incorporated'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res2['market_cap'] = res2['market_cap'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res2['campaign_type'] = res2['campaign_type'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res2['latest_development'] = res2['headline'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res2['campaign_summary'] = res2['campaign_summary'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res2['company_name'] = res2['company_name'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res2['company_parent_name'] = res2['company_parent_name'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')

        res2 = res2[['fight_id','story_id','type','headline' ,'publication_date','publication_time','language','cusip','factset_id','event_type'
            ,'fds_sector','fds_sector_name','fds_industry','fds_industry_name','jurisdiction_incorporated','market_cap','sic_code','campaign_type'
            ,'latest_development','campaign_summary','delivery_timestamp','company_name','company_ticker','company_stock_exchange'
            ,'company_parent_name','company_parent_ticker','company_parent_stock_exchange','company_parent_cusip','company_parent_factset_id'
            ,'sharkwatch_50_member','proponent_iconum','headline_rank']]
        
        res2.to_csv("D:/User/hjanagam/out/SharkNews/df2vscode.csv")
            


        #self.temp_shark_news = res2.copy()
        

