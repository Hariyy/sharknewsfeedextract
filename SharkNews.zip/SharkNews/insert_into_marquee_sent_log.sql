INSERT INTO marquee_sent_log (
	fight_id
	,publication_date
	)
SELECT fight_id
    ,publication_date
FROM Truecourse_Lion.dbo.temp_shark_news a (NOLOCK)
WHERE NOT EXISTS (
        SELECT fight_id
        FROM marquee_sent_log b (NOLOCK)
        WHERE a.fight_id = b.fight_id
        AND a.publication_date = b.publication_date
        AND Convert(DATE ,b.run_date) >= DATEADD(day, -3, CONVERT(DATE, getdate()))
        AND Convert(DATE ,b.run_date) <= Convert(DATE, getdate(), 112)
        )
ORDER BY publication_date
GO
