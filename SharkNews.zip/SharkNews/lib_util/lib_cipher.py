﻿# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:        lib_cipher.py
# Author:      mguffroy
#
# Created:     13/05/2013
# Copyright:   (c) factset 2013
#-------------------------------------------------------------------------------

from itertools import cycle 
import base64
import codecs
import random

crypt = ('A8Zr4Q1tgb' '_SW6nXhyE3'
         'Rujk70DFCi' 'VolmTYGpa-'
         'Hq5wxB2NUI' 'szeJdcKO9P'
         'vLfM')
private_key = 0xC3D2E1F0


__all__ = ['Cipher', 'NotEncrypted', 'AlreadyEncrypted', 'NotImplementedCipherAlgorithm', 'InvalidEncryption']

class NotEncrypted(Exception):
    """ Exception raised when we ask data to be decrypted, and they are not encrypted """
    pass

class AlreadyEncrypted(Exception):
    """ Exception raised when we ask already encrypted data to be encrypted """
    pass

class NotImplementedCipherAlgorithm(Exception):
    """ Exception raised when we select an inexistant cipher algorithm """
    pass

class InvalidEncryption(Exception):
    """ Encrypted string is invalid """
    pass

class Cipher:
    """
        Encrypt/Decrypt information
        WARNING: xor cipher is not the most secure algorithm.
                 AES should be better, but would need some extra package.
                 For only hidding clear password inside configuration files it is acceptable
                 BUT DO NOT use it, if you are looking for more than only hidding short informations like password.
    """
    def __init__(self, algo="xor", key="MyS€cr€tK€y'{$£"):
        """
            Instantiate a cipher object
        """
        self.available_algo = ['xor', 'l4crypt']
        # define a prefix for crypted information
        self.prefix = "crypted:"
        self.set_algo(algo)
        self.set_key(key)

    def set_key(self, key):
        """
            Change the key to use
        """
        self.key = key

    def set_algo(self, algo):
        """
            Change the cipher algorithm to use
        """
        if algo not in self.available_algo:
            raise NotImplementedCipherAlgorithm("{} is not a valid cipher algorithm.\n Available: {}".format(algo, str(self.available_algo)))
        else:
            self.algo = algo

    def _is_crypted(self, data):
        """
            Return True if data is an encrypted string
        """
        return len(data) >= len(self.prefix) and data[:len(self.prefix)] == self.prefix

    def _xor_cipher(self, data):
        """
            Encrypt or decrypt data using the xor cipher algorithm
        """
        key=bytes(bytes(self.key,'utf-8'))
        decode = self._is_crypted(data)
        if decode:
            data = base64.b64decode(data[len(self.prefix):])
        data = str(bytes(x^y for x,y in zip(data,cycle(key))),'utf-8')
        if not decode:
            data = self.prefix + str(base64.b64encode(bytes(data,"utf-8")),'utf-8')
        return data.replace('\n','')

    def _l4crypt_encrypt(self, data, encoding = 'utf-8-sig'):
        """
            Encrypt data using l4crypt algorithm
            The following characters are not supported: é ç
        """
        dw = _dw_rand()
        public_key = _dw_rand()
        # encode with signature
        dataencoded = data.encode(encoding)
        nb_dword = (len(dataencoded)+3)/4
        encoded = dataencoded
        # add end of string + random bytes at the end
        encoded += ('\0' + format(dw, 'x'))[:4*(nb_dword) - len(dataencoded)]
        encoded = str(encoded.encode('hex'))

        encrypted = _write_dword(private_key ^ public_key ^ _make_mask(0))
        # encrypt with public key
        for i in range(nb_dword*2):
            # manage endianness
            packet = encoded[i*4:(i+1)*4]
            permuted_packet = ''
            for j in range(0, len(packet), 2):
                permuted_packet += packet[len(packet)-(j+2):len(packet)-j]

            encrypted += _write_dword(int(permuted_packet, 16) ^ public_key ^ _make_mask(i+1))

        return self.prefix + encrypted

    def _l4crypt_decrypt(self, data):
        """
            Decrypt data using l4crypt algorithm
        """
        data = data[len(self.prefix):]
        nb_dword = (len(data)+5)//6
        if nb_dword<2:
            raise InvalidEncryption(data)

        # Read public key
        public_key = _read_dword(data[:6])
        public_key ^= private_key

        # Do not read key again
        decrypted = []
        for i in range(1, nb_dword, 1):
            decrypted.append(_read_dword(data[i*6:(i+1)*6]) ^ public_key ^ _make_mask(i))

        # Reorder bytes inside a dword due to endianness
        str_decrypted = ''
        is_end_of_string = False
        for packet in decrypted:
            # byte 00 is the end of string (char '\0')
            # it separates the password from the trailing random bytes
            packet = format(packet, '04x')
            for i in range(0, len(packet), 2):
                byte = packet[max(0, len(packet)-(i+2)):len(packet)-i]
                if byte == '00':
                    is_end_of_string = True
                    break
                str_decrypted += packet[max(0, len(packet)-(i+2)):len(packet)-i]
            if is_end_of_string:
                break

        str_decrypted = codecs.decode(str_decrypted,'hex') 
        encoding = get_encoding_from_bytes(str_decrypted[:4])
        if encoding:
            str_decrypted = str_decrypted.decode(encoding)
        return str_decrypted

    def encrypt(self, data):
        """
            Encrypt data
        """
        if  self._is_crypted(data):
            raise AlreadyEncrypted(data)
        else:
            if self.algo == 'xor':
                return self._xor_cipher(data)
            elif self.algo == 'l4crypt':
                return self._l4crypt_encrypt(data)
            else:
                raise NotImplementedCipherAlgorithm()

    def decrypt(self, data):
        """
            Decrypt data
        """
        if  self._is_crypted(data):
            if self.algo == 'xor':
                return self._xor_cipher(data)
            elif self.algo == 'l4crypt':
                return self._l4crypt_decrypt(data)
            else:
                raise NotImplementedCipherAlgorithm()
        else:
            raise NotEncrypted(data)



def _write_dword(dw):
    result = ''
    for i in range(6):
        result += crypt[(dw >> (6*i)) & 0x0000003F]
    return result

def _read64(letter):
    for i in range(len(crypt)):
        if crypt[i] != letter:
            continue
        return i

    raise InvalidEncryption(letter)
    return 0

def _read_dword(string):
    dw = 0
    for i in range(6):
        dw |= _read64(string[i]) << 6*i
    return dw

def _make_mask(dw):
    dw &= 0x000000FF
    dw |= dw << 8
    dw |= dw << 16
    return dw

def _dw_rand():
    dw1 = random.getrandbits(6)
    dw2 = random.getrandbits(6)
    dw3 = random.getrandbits(6)
    dw1 |= (dw3&0x000001) << 15
    dw2 |= (dw3&0x000002) << 14

    return dw1 | (dw2 << 16)

def get_encoding_from_file(filename):
    """
        Sniff the BOM of a file and find the corresponding encoding
    """
    f = file(filename,'rb')
    header = f.read(4) # Read just the first four bytes.
    f.close()
    return get_encoding_from_bytes(header)

def get_encoding_from_bytes(bytes):
    """
        Return the encoding from the BOM or None if no encoding has been found.
        It might be ASCII then.
    """
    # Don't change this to a map, because it is ordered!!!
    encodings = [ ( codecs.BOM_UTF32_BE, 'utf-32' ),
    ( codecs.BOM_UTF32_LE, 'utf-32' ),
    ( codecs.BOM_UTF16_BE, 'utf-16' ),
    ( codecs.BOM_UTF16_LE, 'utf-16' ),
    ( codecs.BOM_UTF8, 'utf-8-sig' ) ]
    for curHeader,encoding in encodings:
        if bytes.find(curHeader)==0:
            return encoding
    return None

def main():
    """
        Unittest for this lib
        Execution of main should pass without raising error
    """
    data = "mot de passe en clair 78 @ ! &"
    # Test l4crypt encrypt and decrypt methods
    l4crypt = Cipher('l4crypt')
    encrypt = l4crypt.encrypt(data)
    decrypt = l4crypt.decrypt(encrypt)
    assert data == decrypt, "decrypted data is not equals to encrypted data"

    data = "mot de passe en clair 78 @ è &"
    xor = Cipher()

    # Test xor_cipher method
    encrypt = xor._xor_cipher(data)
    decrypt = xor._xor_cipher(encrypt)
    assert data == decrypt, "decrypted data is not equals to encrypted data"

    # Test encrypt method
    assert encrypt == xor.encrypt(data)
    try:
        xor.encrypt(encrypt)
        assert False, "Should not be here"
    except AlreadyEncrypted as e:
        assert encrypt == str(e)

    # Test decrypt method
    assert decrypt == xor.decrypt(encrypt)
    assert data == xor.decrypt(encrypt)
    try:
        xor.decrypt(data)
        assert False, "Should not be here"
    except NotEncrypted as e:
        assert data == str(e)

if __name__ == '__main__':
    main()
