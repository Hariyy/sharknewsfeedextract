upload_incoming_file
=====
Objective:
----------
This module is used to upload incoming feeds to sql server

Function:
---------

.. automodule:: upload_incoming_file
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance: