feed_ui_insert
==============
It is used to ingest log and dbg file to feed ui tables.

Objective:
----------
The module is used to ingest feed lof to FEED UI

Function:
----------
.. automodule:: feed_ui_insert
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance: