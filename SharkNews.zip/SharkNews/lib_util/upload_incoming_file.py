#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
upload_incoming_file.py
=======================

**Incoming Format File**
    Create an XML format file in which you define all run time parameters. It's name should be same as incoming file name. If incoming file name has a timestamp init, don't add that in the format file name.

    Format File Example::

        <?xml version='1.0' encoding='utf-8'?>
        <incoming_feed>
            <file_properties>
                <!-- default is 0, if the file doesn't have header, use none  -->
                <property name = "header" value = "none"/>
                <!--default is csv.quote_all, use csv.quote_minimal , csv.quote_all , csv.quote_nonnumeric  or csv.quote_none-->
                <property name = "quoting" value = "csv.quote_all"/>
                <!-- default is 'utf-8', use https://docs.python.org/3/library/codecs.html#standard-encodings -->
                <property name = "encoding" value = "utf-8"/>
                <!-- default is '|', specify delimeter/separator -->
                <property name = "delimeter" value = "|"/>
                <!-- default is none, if the file is less then 500 mb and loads quickly, use chunk size none,
                    else set it between 10000 and 100000  based on performance-->
                <property name = "chunksize" value = "none"/>
                <!-- default is 0, if you find header as first row in the data, use 1 to exclude it>
                <property name = "skiprows" value = "0"/>
            </file_properties>
            <!-- provide column name and order, always begin id from 0
                name= name of the column
                datatype = default is default if no conversion needed, specify the datatype if needed (str, int, float, long)
                datetime = default is false, make it true if the column is datetime
                drop_column = default is false, make it true if would like to drop the column
                new_columnname = default is default, specify the name if you would like to change it
                index_col= default is false, make it true if you would like to index the df based on the column-->
            <columns>
                <column id="0" name="col0" datatype = "default" datetime= "false" drop_column="false" new_columnname = "default" index_col = "false"/>
                <column id="1" name="col1" datatype = "default" datetime= "false" drop_column="false" new_columnname = "default" index_col = "false"/>
                <column id="2" name="col2" datatype = "default" datetime= "false" drop_column="false" new_columnname = "default" index_col = "false"/>
                <column id="3" name="col3" datatype = "default" datetime= "false" drop_column="false" new_columnname = "default" index_col = "false"/>
                <column id="4" name="col4" datatype = "default" datetime= "false" drop_column="false" new_columnname = "default" index_col = "false"/>
                <column id="5" name="col5" datatype = "default" datetime= "false" drop_column="false" new_columnname = "default" index_col = "false"/>
                <column id="6" name="col6" datatype = "default" datetime= "false" drop_column="false" new_columnname = "default" index_col = "false"/>
            </columns>
            <sql>
                <property name = "sql_table" value = "table_name"/>
                <-- mention sql table name inplace of table_name -->
                <property name = "if_exists" value = "replace"/>
                <!--  value: fail/replace/append
                        fail: If table exists, do nothing.
                        replace: If table exists, drop it, recreate it, and insert data.
                        append: If table exists, insert data. Create if does not exist.-->

            </sql>
        </incoming_feed>

    Code Example::

        # config_file = path of software.ini
        # incoming_config_file = path of incoming format file
        # incoming_file = path of a file o upload

        from  upload_incoming_file import UploadIncomingFile

        upload_file = UploadIncomingFile(config_file, incoming_config_file, incoming_file)
        upload_file.upload_file_to_sql()

        config_file = path of software.ini
        incoming_config_file = path of incoming format file
        incoming_file = path of a file to upload

"""

from __future__ import unicode_literals
from __future__ import print_function
import codecs
import glob
import json
import os
import csv
import io
import numpy as np
from .getconfig import GetConfig
import pandas as pd
import datetime
from sqlalchemy import create_engine
import urllib.parse
from .utilities import capture_trace, decrypt_pw
from . import lib_log
import xml.etree.ElementTree as ET
import socket
import sys
import time
from batch_lib import call
import math
from .get_server_config import GetServerConfig


__version__ = '1.0'


class UploadIncomingFile(object):
    def __init__(self, config_file, incoming_config_file, incoming_file):
        self.server_config = GetServerConfig()
        self.incoming_config_file = self.server_config.get_dir_for_current_host(incoming_config_file)
        self.incoming_file = self.server_config.get_dir_for_current_host(incoming_file)
        self.logger = lib_log.Logger()
        self.configuration_file = self.server_config.get_dir_for_current_host(config_file)
        self.config_par = GetConfig(self.configuration_file)
        self.server = self.server_config.get_sql_server_name(self.config_par.config.get('feed', 'server').strip())
        self.database = self.server_config.get_sql_db_name(self.server,self.config_par.config.get('feed', 'database').strip())
        self.sql_failover_partner = self.server_config.get_sql_failover_partner(self.server)
        self.sql_user = "FeedAdminLogin"
        self.sql_password = decrypt_pw("crypted:ptfLrrPwSb8AHnebZAlG-brA8ijg4AebrgQAm0zg1AT7YgtAiG3SgA")
        self.column_list = []
        self.primary_column_list = []
        self.convert_columns_datetime_list = []
        self.drop_columns_list = []
        self.rename_header_dict = {}
        self.dtype_change_dict = {}
        self.convert_dtype_dict = {}
        self.decode_columns_dict = {}
        self.index_col_list = None
        self.na_values_dict = {}
        self.header = 0
        self.skiprows = 0
        self.names = None
        self.encoding = 'utf-8'
        self.quoting = csv.QUOTE_ALL
        self.chunksize = None
        self.delimeter = '|'
        self.error_bad_lines = False
        self.iterator = False
        self.sql_table_name = None
        self.sql_temp_database = None
        self.if_exists = 'replace'
        self.auto_truncate = False
        self.exec_info = pd.DataFrame(
            columns=['read_incoming_configfile', 'read_file_data', 'upload_dataframe_to_sqlserver'])
        self.hostname = socket.gethostname()
        self.batch_directory = 'D:\\Batch\\' if self.hostname  == 'lionbatcha02' else 'd:\\Datagroup1\\batch\\'
        self.insert_dataframe = None

        try:
            if not os.path.isfile(self.incoming_config_file):
                er_msg = ("Configuration file doesn't exists: {}".format(self.incoming_config_file))
                raise ValueError(er_msg)
            if not os.path.isfile(self.incoming_file):
                er_msg = ("Incoming file doesn't exists: {}".format(self.incoming_file))
                raise ValueError(er_msg)

            self.__read_incoming_configfile(self.incoming_config_file)
            if self.auto_truncate:
                self.get_sql_columns_length()
        except:
            raise
        self.driver = '{SQL Server Native Client 10.0}'
        self.add_connection_property = ""
        try :
            self.sqlversion = self.config_par.config.get('feed', 'sqlversion').strip()
            if self.sqlversion == '2016':
                self.driver = '{ODBC Driver 13 for SQL Server}'
                self.add_connection_property = ";MultiSubnetFailover=yes"
        except:
            pass

    def __read_incoming_configfile(self, incoming_config_file):
        try:
            pre = datetime.datetime.now()  # use utc
            tree = ET.parse(incoming_config_file)
            root = tree.getroot()

            # get the file properties
            for element in root.iter('file_properties'):
                for el in element.iter('property'):
                    if el.attrib.get('name') == 'header':
                        if el.attrib.get('value') == '0':
                            self.header = 0
                        else:
                            self.header = None
                    elif el.attrib.get('name') == 'quoting':
                        if el.attrib.get('value').lower() == 'csv.quote_all':
                            self.quoting = csv.QUOTE_ALL
                        elif el.attrib.get('value').lower() == 'csv.quote_none':
                            self.quoting = csv.QUOTE_NONE
                        elif el.attrib.get('value').lower() == 'csv.quote_nonnumeric':
                            self.quoting = csv.QUOTE_NONNUMERIC
                        elif el.attrib.get('value').lower() == 'csv.quote_minimal':
                            self.quoting = csv.QUOTE_MINIMAL
                        else:
                            er_msg = ("Incorrect quoting parameter: {}".format(el.attrib.get('value')))
                            raise ValueError(er_msg)
                    elif el.attrib.get('name') == 'encoding':
                        self.encoding = el.attrib.get('value')
                    elif el.attrib.get('name') == 'delimeter':
                        if el.attrib.get('value') == '\\t':
                            self.delimeter = '\t'
                        else:
                            self.delimeter = el.attrib.get('value')
                    elif el.attrib.get('name') == 'chunksize':
                        if el.attrib.get('value').lower() == 'none':
                            self.chunksize = None
                        else:
                            self.chunksize = int(el.attrib.get('value'))
                            self.iterator = True
                    elif el.attrib.get('name') == 'skiprows':
                        if int(el.attrib.get('value')):
                            self.skiprows = int(el.attrib.get('value'))

            # get list of columns
            for element in root.iter('columns'):
                for el in element.iter('column'):
                    self.column_list.insert(int(el.attrib.get('id')), el.attrib.get('name'))
                    if el.attrib.get('datetime').lower() != "false":
                        self.convert_columns_datetime_list.append(el.attrib.get('name'))
                    if el.attrib.get('drop_column').lower() == "true":
                        self.drop_columns_list.append(el.attrib.get('name'))
                    if el.attrib.get('new_columnname').lower() != "default":
                        self.rename_header_dict.update({el.attrib.get('name'): el.attrib.get('new_columnname')})
                    if el.attrib.get('index_col').lower() == "true":
                        self.index_col_list.append = int(el.attrib.get('id'))
                    self.na_values_dict.update({el.attrib.get('name'): el.attrib.get('na_values').split(",") if el.attrib.get('na_values') is not None else []})
                    if el.attrib.get('datatype').lower() != "default":
                        self.dtype_change_dict.update({el.attrib.get('name'): el.attrib.get('datatype')})
                    if el.attrib.get('encoding') is not None:
                        try:
                            codecInfo = codecs.lookup(el.attrib.get('encoding'))
                            if codecInfo.name != self.encoding:
                                self.decode_columns_dict.update({el.attrib.get('name'): codecInfo.name})
                        except LookupError:
                            pass #ignore if value is not a valid codec
                    if self.header is None:
                        self.names = self.column_list

                    for key, value in self.dtype_change_dict.items():
                        if value == 'str':
                            self.dtype_change_dict[key] = str
                        if value == 'int':
                            self.dtype_change_dict[key] = int
                        if value == 'float':
                            self.dtype_change_dict[key] = float
                        if value == 'long':
                            self.dtype_change_dict[key] = long

                            # get sql informaton
            for element in root.iter('sql'):
                for el in element.iter('property'):
                    if el.attrib.get('name') == "sql_table":
                        self.sql_table_name = el.attrib.get('value')
                    if el.attrib.get('name') == "if_exists":
                        self.if_exists = el.attrib.get('value')
                    if el.attrib.get('name') == "temp_database":
                        self.sql_temp_database = self.server_config.get_sql_db_name(self.server,el.attrib.get('value'))
                    if el.attrib.get('name') == "auto_truncate" and el.attrib.get('value').lower()=="true":
                        self.auto_truncate = True

            self.exec_info.loc[0, 'read_incoming_configfile'] = str(datetime.datetime.now() - pre)
        except:
            self.logger.write_dbg('{}'.format(capture_trace()))
            self.log_exec_info()
            raise

    def read_file_data(self, incoming_file):
        """
        **Objective**
            It will read the data from the file and returns the dataframe .

        :param file_path: provide the path of the file you want to load
        :param dtype: used to change the datatype of columns
        :return dataframe:

        Example
        *******

        Example::

        """
        try:
            pre = datetime.datetime.now()  # use utc

            if self.chunksize:
                dt = pd.read_csv(incoming_file, names=self.names, index_col=self.index_col_list,
                                 converters=self.dtype_change_dict, sep=self.delimeter,
                                 header=self.header, encoding=self.encoding, quoting=self.quoting,
                                 chunksize=self.chunksize, error_bad_lines=self.error_bad_lines, iterator=self.iterator,
                                 skiprows=self.skiprows,skip_blank_lines=True,na_values =self.na_values_dict,
                                 keep_default_na=False, skipinitialspace=True)
                df = pd.concat(dt, ignore_index=True)
            else:
                df = pd.read_csv(incoming_file, names=self.names, sep=self.delimeter, index_col=self.index_col_list,
                                 header=self.header, encoding=self.encoding, quoting=self.quoting,
                                 dtype=self.dtype_change_dict, error_bad_lines=self.error_bad_lines,
                                 skiprows=self.skiprows, skip_blank_lines=True,na_values =self.na_values_dict,
                                 keep_default_na=False, skipinitialspace=True)
            if self.convert_columns_datetime_list:
                for column in self.convert_columns_datetime_list:
                    if column in df.columns:
                        df[column] = pd.to_datetime(df[column], errors="coerce")
            if self.drop_columns_list:
                for column in self.drop_columns_list:
                    if column in df.columns:
                        df.drop(column, axis=1, inplace=True)
            if self.rename_header_dict:
                for old, new in self.rename_header_dict.items():
                    if old in df.columns:
                        df.rename(columns={old: new}, inplace=True)
            if self.auto_truncate and self.convert_dtype_dict:
                for col,props in self.convert_dtype_dict.items():
                    if col in df.columns:
                        if str(props["Datatype"]).lower() in ['varchar','char','nvarchar'] and props["MaxLength"] > 0:
                            df[col] = df[col].str[:props["MaxLength"]]   
                        elif str(props["Datatype"]).lower() in ['datetime']:
                            df[col] = pd.to_datetime(df[col], errors="coerce")
                        elif str(props["Datatype"]).lower() in ['numeric','decimal']:
                            format = '%.'+str(props["scale"])+'f'
                            df[col] = pd.to_numeric(df[col], errors="coerce").map(lambda x: format % x if not math.isnan(x) else x)
            if self.decode_columns_dict:
                for column, decode_format in self.decode_columns_dict.items():
                    column = self.rename_header_dict[column] if self.rename_header_dict.has_key(column) else column
                    if column in df.columns:
                        try:
                            df[column].apply(lambda x: x.encode(self.encoding, 'ignore').decode(decode_format, 'ignore'))
                        except:
                            pass
            self.exec_info.loc[0, 'read_file_data'] = str(datetime.datetime.now() - pre)
            return df
        except:
            raise

    def upload_dataframe_to_sqlserver(self, df):
        """
        **Objective**
            It will upload the dataframe to the sql table .

        :param df: dataframe to be loaded into the sql table
        """
        try:
            if self.sql_failover_partner.strip():
                self.logger.write_log("Included FailoverPartner {0}".format(self.sql_failover_partner))
                failover_property = ';FAILOVER_PARTNER='+ self.sql_failover_partner
            else:
                failover_property = self.add_connection_property
            pre = datetime.datetime.now()  # use utc
            if self.sql_table_name is not None:
                connection_string = urllib.parse.quote_plus(
                    'DRIVER=' + self.driver +
                    ';SERVER=' + self.server +
                    ';DATABASE=' + self.database +
                    ';UID=' + self.sql_user +
                    ';PWD=' + self.sql_password + 
                    ';APP=CCSDBFeed-' + os.path.basename(os.path.dirname(self.server_config.current_dir)) + failover_property)
                engine = create_engine(
                    'mssql+pyodbc:///?odbc_connect=%s' % connection_string)  # sqlalchemy ,convert_unicode=False
                df.to_sql(self.sql_table_name, engine, if_exists=self.if_exists, chunksize=self.chunksize, index=0)
                self.exec_info.loc[0, 'upload_dataframe_to_sqlserver'] = str(datetime.datetime.now() - pre)
            else:
                er_msg = "SQL table name note provided"
                ValueError(er_msg)
        except Exception:
            raise

    def upload_file_to_sql(self):
        try:
            self.upload_dataframe_to_sqlserver(self.read_file_data(self.incoming_file))
            exe_buffer = io.StringIO()
            self.exec_info.to_csv(exe_buffer, sep='|', header=True, index=0)
            self.logger.write_log('\n{}'.format(exe_buffer.getvalue()))
        except Exception:
            self.logger.write_dbg('{}'.format(capture_trace()))
            self.log_exec_info()
            raise

    def log_exec_info(self):
        exe_buffer = io.StringIO()
        self.exec_info.to_csv(exe_buffer, sep='|', header=True, index=0)
        self.logger.write_log('\n{}'.format(exe_buffer.getvalue()))

    def load_incremental_file_to_sqlserver(self, archive_folder_path = None, deef_file = None):
        """
        **Objective**
            This function is to load the incremental files using the provided deef file.

        :param archive_folder_path: provide the path of the archive folder of the feed that generates full file, function will get the latest out of the sub folders.
        :param deef_file: provide the full path of the deef file of incoming file that you want to load incrementally.

        Example
        *******
        ENV.define("job_name", "SegmentFeed")
        ENV.define("incoming_dir", os.path.join(root,'\\In\\Incoming', job_name+"\\"))
        ENV.define("config_file_staging", os.path.join(base_directory , 'software.ini'))
        ENV.define("base_directory", os.path.join(root,'batch', job_name))
        ENV.define("archive_dir", os.path.join(root,'archive' , job_name))

        incoming_file = os.path.join(incoming_dir, "Segment_SICNAIC.txt")
        upload_delete_file = upload_incoming_file.UploadIncomingFile(config_file=config_file_staging,
                                                                             incoming_config_file=os.path.join(base_directory, 'segment_sicnaic_conf_insert.xml'),
                                                                             incoming_file=incoming_file)
        upload_delete_file.load_incremental_file_to_sqlserver(archive_folder_path = archive_dir,deef_file = os.path.join(base_directory,'Segment_SICNAIC.deef'))

        """
        try:
            original_table = self.sql_table_name
            delete_table = 'temp_'+(original_table[original_table.find('.')+1:] if '.' in original_table else original_table)+'_delete'
            orig_if_exists = self.if_exists
            orig_database = self.database
            temp_database = self.sql_temp_database if self.sql_temp_database is not None else self.database

            if deef_file is not None:
                archive_folder_path = self.server_config.get_dir_for_current_host(archive_folder_path)
                deef_file = self.server_config.get_dir_for_current_host(deef_file)
                if archive_folder_path is None or not os.path.isdir(archive_folder_path):
                    raise Exception("Full file archive folder path is missing")

                #get old archive directory & run deef
                old_archive_file = os.path.join(self.get_latest_archive(archive_folder_path),os.path.basename(self.incoming_file))
                self.logger.write_log("old_archive_file::"+str(old_archive_file))
                self.logger.write_log("c:\python36_64\python.exe " + os.path.join(self.batch_directory,'deef.pyz') + " --conf " + deef_file + " --ref " + old_archive_file + " --new " + self.incoming_file + " --out " + os.path.dirname(self.incoming_file) + " --pool 6")
                return_value =  call("c:\python36_64\python.exe " + os.path.join(self.batch_directory,'deef.pyz') + " --conf " + deef_file + " --ref " + old_archive_file + " --new " + self.incoming_file + " --out " + os.path.dirname(self.incoming_file) + " --pool 6")
                return_code = return_value[0]
                out_data = return_value[1]
                err_data = return_value[2]
                if return_code != 0 or "Can't process file" in err_data or "WindowsError" in err_data:
                    if err_data != '':
                        raise Exception(err_data)
                    else:
                        raise Exception(out_data)
                self.logger.write_log("\nDeef process successfully completed")

                delete_file = os.path.join(os.path.dirname(self.incoming_file),'delete_'+os.path.splitext(os.path.basename(self.incoming_file))[0]+'.dat')
                insert_file = os.path.join(os.path.dirname(self.incoming_file),'insert_'+os.path.splitext(os.path.basename(self.incoming_file))[0]+'.dat')

                #load delete file to temp table if exists
                if(os.path.isfile(delete_file)):

                    #get primary columns from deef file
                    self.primary_column_list = []
                    with open (deef_file, 'r') as deeffile:
                        content = deeffile.readlines()
                        cols_list = [str(x.split(';')[2]) for x in content if x.rstrip('\n')[-2:] == ';1']
                    for col in cols_list:
                        self.primary_column_list.append(self.rename_header_dict[col] if self.rename_header_dict.has_key(col) else col)

                    #using the primary key columns list dynamically create temp_delete table
                    query = "if object_id('"+temp_database+".dbo."+delete_table+"') is not null begin drop table "+temp_database+".dbo."+delete_table+" end select top 1 "+ ",".join(self.primary_column_list) +" into " +temp_database+".dbo."+delete_table+ " from " + orig_database + "." + (original_table if "." in original_table else "dbo."+original_table) + " where 1 = 2"
                    print(query)
                    self.exe_sql(query)

                    #read delete.dat file and load it to the temp_delete table
                    delete_df = self.read_file_data(delete_file)
                    self.sql_table_name = delete_table
                    self.database = temp_database
                    self.if_exists = "append"
                    self.upload_dataframe_to_sqlserver(delete_df)  
                    self.logger.write_log("\nRecords successfully inserted to {}".format(delete_table))
            
                    #using the primary key columns list dynamically generate the sql delete query & run it to delete the data from main table
                    query = 'delete a from '+ orig_database + '.' + (original_table if '.' in original_table else 'dbo.'+original_table) + ' a inner join '
                    query = query + temp_database + '.dbo.' + delete_table + ' b on '
                    on_col = ''
                    for col in self.primary_column_list:
                        on_col = on_col + ' and a.[' + col + '] = b.['+col+']'
                    query = query + ' ' + on_col.strip()[3:]
                    print(query)
                    rowcount = self.exe_sql(query)
                    self.logger.write_log('Count of rows deleted ::' + str(rowcount ))
                    self.logger.write_log("\nDeleted records from {} successfully".format(original_table))
            else:
                insert_file = self.incoming_file

            #insert the insert.dat/incoming file to main table
            if(os.path.isfile(insert_file)):
                self.insert_dataframe = self.read_file_data(insert_file)
                self.sql_table_name = original_table
                self.database = orig_database
                self.if_exists = orig_if_exists
                self.upload_dataframe_to_sqlserver(self.insert_dataframe)  
                self.logger.write_log("\nRecords successfully inserted to {}".format(original_table))
        except Exception:
            self.logger.write_dbg('{}'.format(capture_trace()))
            self.log_exec_info()
            raise


    def get_latest_archive(self, archive_path):
        try:
            sub_dirs = filter(os.path.isdir, [os.path.join(archive_path, f) for f in os.listdir(archive_path)])
            sub_dirs = sorted(sub_dirs, reverse=True)
            old_dir = ''
            if (len(sub_dirs) > 0):
               old_dir = sub_dirs[0]
            else:
                self.logger.write_dbg('Error: No archive files are available for the deef!!! \n{}'.format(utilities.capture_trace()))
                raise
            return old_dir
        except Exception:
            raise

    def exe_sql(self, query):
        try:
            import pyetl
            etl = pyetl.PyEtl(self.configuration_file)
            if self.sql_failover_partner.strip():
                self.logger.write_log("Included FailoverPartner {0}".format(self.sql_failover_partner))
                failover_property = ';FAILOVER_PARTNER='+ self.sql_failover_partner
            else:
                failover_property = self.add_connection_property
            connection_string = urllib.parse.quote_plus(
                'DRIVER='+ etl.driver +
                ';SERVER=' + etl.server +
                ';DATABASE=' + etl.database +
                ';UID=' + etl.sql_user +
                ';PWD=' + etl.sql_password +
                ';APP=CCSDBFeed-' + os.path.basename(os.path.dirname(self.server_config.current_dir)) +failover_property
            )
            engine = create_engine(
                'mssql+pyodbc:///?odbc_connect=%s' % connection_string)  # sqlalchemy ,convert_unicode=False
            cursor = engine.connect()
            trans = cursor.begin()
            rows = cursor.execute(query)
            trans.commit()
            cursor.close()
            return rows.rowcount
        except Exception:
            self.logger.write_dbg('Database Server Name :  ' + self.database + '/' + self.server)
            self.logger.write_dbg('{}'.format(capture_trace()))
            raise

    def get_sql_columns_length(self):
        try:
            import pyetl
            etl = pyetl.PyEtl(self.configuration_file)
            query = """SELECT 
                        c.name 'ColumnName',
                        t.Name 'Datatype',
                        c.max_length 'MaxLength',
                        c.precision ,
                        c.scale ,
                        c.is_nullable,
                        ISNULL(i.is_primary_key, 0) 'PrimaryKey'
                    FROM    
                        sys.columns c
                    INNER JOIN 
                        sys.types t ON c.user_type_id = t.user_type_id
                    LEFT OUTER JOIN 
                        sys.index_columns ic ON ic.object_id = c.object_id AND ic.column_id = c.column_id
                    LEFT OUTER JOIN 
                        sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id
                    WHERE
                        c.object_id = OBJECT_ID('"""+ self.sql_table_name +"')"

            df = etl.run_sql(query, 'df')
            self.convert_dtype_dict = dict([(i,{"Datatype":a, "MaxLength":b, "precision":c, "scale":d }) for i, a,b,c,d in zip(df.ColumnName, df.Datatype, df.MaxLength, df.precision, df.scale)])
            print(self.convert_dtype_dict)
        except Exception:
            self.logger.write_dbg('Database Server Name :  ' + self.database + '/' + self.server)
            self.logger.write_dbg('{}'.format(capture_trace()))
            raise