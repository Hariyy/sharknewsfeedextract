#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function
from __future__ import unicode_literals
import os
import abc
import csv
import datetime
import math
import os
import re
import urllib.parse
import sys
import traceback
from collections import OrderedDict
from unicodedata import normalize
import pandas as pd
from sqlalchemy import create_engine
import turbodbc
import codecs
import glob
from batch_lib import *
from . import lib_log
from .getconfig import GetConfig
from .utilities import capture_trace, decrypt_pw, filesize_check
from .get_server_config import GetServerConfig
from io import StringIO

__version__ = '2.0'

logger = lib_log.Logger()

def file_size_convert(self, size):
    """
    **Objective**
        It converts memory size from byte to respective unit (KB/MB/GB)

    :param size: pass the byte size
    :return: size with correct unit
    """
    try:
        if not size == 0:
            size_name = ("KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
            i = int(math.floor(math.log(size, 1024)))
            p = math.pow(1024, i)
            s = round(size / p, 2)
            if i > 0 and s > 0:
                return '%s %s' % (s, size_name[i-1])
            else:
                return '%s B' % (size)
        return '%s B' % (size)
    except:
        logger.write_dbg('{}'.format(capture_trace()))
        raise

def log_df_info(self):
    """
    **Objective**
        It converts the data frame into string.

    :return: returns the string to write into the log/dbg file
    """
    try:
        df_buffer = StringIO()
        exe_buffer = StringIO()
        self.df_info.to_csv(df_buffer, sep='|', header=True)
        logger.write_log('\n{}'.format(df_buffer.getvalue()))
        self.exec_info.to_csv(exe_buffer, sep='|', header=True, index=0)
        logger.write_log('\n{}'.format(exe_buffer.getvalue()))

    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def empty_df(self):
    """
    **Objective**
        It raises an error if we have an empty data frame.
        you can use below code in transform function to check
        the empty dataframe.

    self.file_size_check()

    """
    try:
        if len(self.df_info.loc[self.df_info['row_count'] == 0]) > 0:
            log_df_info(self)
            empty_df = self.df_info.loc[self.df_info['row_count'] == 0].\
                                                        reset_index()
            raise ValueError('Empty data frame(s) {}!!'.\
                            format(empty_df['df_name'].tolist()))
    except:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


class PyEtl(object):
    def __init__(self, config_file):
        self.server_config = GetServerConfig()
        # read software.ini and grag the parameters
        self.config_par = GetConfig(self.server_config.get_dir_for_current_host(config_file))
        self.server = self.server_config.get_sql_server_name(self.config_par.config.get('feed', 'server').strip())
        self.database = self.server_config.get_sql_db_name(self.server,self.config_par.config.get('feed', 'database').strip())
        self.output = self.server_config.get_dir_for_current_host(self.config_par.config.get('feed', 'output').strip())
        self.base_dir=os.path.abspath(os.path.curdir).lower()+'\\'
        self.scriptpath = self.config_par.config.get('feed', 'scriptpath').strip()
        self.login_timeout = '60'
        self.sqlversion = 2016
        self.retry = 3
        self.driver = '{ODBC Driver 17 for SQL Server}'
        self.add_connection_property = ";MultiSubnetFailover=yes"
        self.sql_failover_partner = ""
        try :
            self.sqlversion = self.config_par.config.get('feed', 'sqlversion').strip()
            self.sql_failover_partner = self.server_config.get_sql_failover_partner(self.server)
            if self.sql_failover_partner.strip():
                self.add_connection_property = ""
            if self.sqlversion == '2008':
                self.driver = '{SQL Server Native Client 10.0}'
                self.add_connection_property = ""
        except:
            pass

        # save file parameters with default configuration for python standard feeds
        self.delimeter = '|'
        self.header = True
        self.quoting = csv.QUOTE_ALL
        self.encoding = 'utf-8-sig'
        self.escape = None
        self.doublequote = True
        self.quote_header = True
        self.coerce_float = False
        self.float_format = None
        self.line_terminator = '\r\n'


        # file size check parameter
        self.filesize_change_cutoff = 15
        self.turn_off_check_date = None
        self.parallel_processing = False


        # SQL Server parameters
        self.sql_user = 'FeedAdminLogin'
        self.sql_password = decrypt_pw("crypted:ptfLrrPwSb8AHnebZAlG-brA8ijg4AebrgQAm0zg1AT7YgtAiG3SgA")
        self.current_filename = os.path.basename(__file__).replace('.pyc', '')

        # custom function runtime parameters
        self.empty_df_flag = True
        self.convert_float_to_str_flag = False
        self.save_file_chunksize = None

        # stats
        self.exec_info = pd.DataFrame(columns=['run_sql', 'decoding', 'float_str_conv_total', 'transform', 'save_file'])
        self.df_info = pd.DataFrame(
            columns=['df_name', 'df_size', 'row_count', 'time_to_getdata', 'float_str_conv', 'time_to_transform',
                     'time_to_save'])

        self.sql_data = OrderedDict()
        self.results = OrderedDict()
        logger.write_log("DatabaseServerName used for etl:" + self.database + '/' + self.server + ';')
        logger.write_log("Output used for etl:" + self.output + ';')
        self.parameter_dict = {}
        
        self._init_surrogates()

        __metaclass__ = abc.ABCMeta

    def _init_surrogates(self):
        # Surrogates have to be removed before generating XML stream and before dumping data to csv
        # as they were ignored before
        illegal_unichrs_range = [(0x00, 0x08), (0x0B, 0x0C), (0x0E, 0x1F), 
                                (0x7F, 0x84), (0x86, 0x9F), 
                                (0xFDD0, 0xFDDF), (0xFFFE, 0xFFFF)] 
        if sys.maxunicode >= 0x10000:  # not narrow build 
            illegal_unichrs_range.extend([(0x1FFFE, 0x1FFFF), (0x2FFFE, 0x2FFFF), 
                                 (0x3FFFE, 0x3FFFF), (0x4FFFE, 0x4FFFF), 
                                 (0x5FFFE, 0x5FFFF), (0x6FFFE, 0x6FFFF), 
                                 (0x7FFFE, 0x7FFFF), (0x8FFFE, 0x8FFFF), 
                                 (0x9FFFE, 0x9FFFF), (0xAFFFE, 0xAFFFF), 
                                 (0xBFFFE, 0xBFFFF), (0xCFFFE, 0xCFFFF), 
                                 (0xDFFFE, 0xDFFFF), (0xEFFFE, 0xEFFFF), 
                                 (0xFFFFE, 0xFFFFF), (0x10FFFE, 0x10FFFF)]) 
        self.illegal_unichrs = set()
        for char_range in illegal_unichrs_range:
            for char in range(char_range[0], char_range[1]):
                self.illegal_unichrs.add(chr(char))

    @abc.abstractmethod
    def transform(self):
        pass

    def create_parameter_dict(self):
        self.parameter_dict = {"output": self.output,
                               "delimeter": self.delimeter,
                               "header": self.header,
                               "quoting": self.quoting,
                               "encoding": self.encoding,
                               "escape": self.escape,
                               "float_format": self.float_format,
                               "convert_float_to_str_flag": self.convert_float_to_str_flag,
                               "doublequote": self.doublequote}

    def run_sql(self, sql_query, df_name):
        """
        **Objective**
            It is used to run the sql query. It is called inside the class itself.

        :param sql_query: sql query
        :param df_name: data frame name
        :return:
        """
        connection = None
        cursor = None
        try:
            logger.write_log('Begin: Run SQL {}'.format(df_name))  # name the specific file in the message
            if self.sql_failover_partner.strip():
                logger.write_log("Included FailoverPartner {0}".format(self.sql_failover_partner))
                failover_property = ';FAILOVER_PARTNER='+ self.sql_failover_partner
            else:
                failover_property = self.add_connection_property
            connection_string = urllib.parse.quote_plus(
                'DRIVER='+ self.driver +
                ';SERVER=' + self.server +
                ';DATABASE=' + self.database +
                ';UID=' + self.sql_user +
                ';PWD=' + self.sql_password + 
                ';APP= CCSDBFeed-' + os.path.basename(os.path.dirname(self.server_config.current_dir)) + failover_property
            )

            engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' %connection_string, connect_args={'connect_timeout': self.login_timeout})  # sqlalchemy ,convert_unicode=False
            retry = 1
            retry_flag = True
            df = pd.DataFrame()
            while retry_flag:
                try:
                    engine.connect()
                    pre = datetime.datetime.now()  # use utc
                    # run sql
                    df = pd.read_sql_query(sql_query, engine, coerce_float=self.coerce_float)
                    retry_flag = False
                except:
                    if retry < self.retry:
                        retry = retry + 1
                    else:
                        retry_flag = False
                        raise
            logger.write_log('END: Run SQL {}'.format(df_name))  # name the specific file in the message
            # get df information
            self.df_info.loc[df_name , 'df_size'] = file_size_convert(self, sum(block.values.nbytes for block in df.blocks.values()))
            self.df_info.loc[df_name, 'row_count'] = len(df)
            self.df_info.loc[df_name, 'time_to_getdata'] = str(datetime.datetime.now() - pre)
            return df
        except Exception:
            logger.write_dbg('{}'.format(capture_trace()))
            raise

    def save_df(self, df_name, df, file_name):
        """
        **Objective**
            It is called to save the individual file. It is called inside the class itself.

        :param df_name: name of the data frame
        :param df: data frame with the date
        :param file_name: output filename
        :return:
        """
        if self.quoting == csv.QUOTE_ALL:
            self.escape = self.escape if self.escape is not None else None
        else:
            self.escape = None if self.escape is None else self.escape

        # quote the header only in case we are not quoting all the columns
        if self.quote_header and self.quoting != csv.QUOTE_ALL:
            df.rename(columns=lambda x: '"' + x + '"', inplace=True)

        full_path = os.path.join(self.output, file_name)
        pre = datetime.datetime.now()
        with codecs.open(full_path, 'w', self.encoding) as f:
            # f.write(codecs.BOM_UTF8)
            df.to_csv(f, sep=self.delimeter, header=self.header, quoting=self.quoting, index=False,
                      escapechar=self.escape, encoding=self.encoding, chunksize=self.save_file_chunksize,
                      float_format=self.float_format, doublequote=self.doublequote, line_terminator=self.line_terminator)

            self.df_info.loc[df_name, 'time_to_save'] =  str(datetime.datetime.now() - pre)
            del self.results[df_name]
            f.close()

    def decode_df(self, df):
        types = df.apply(lambda x: pd.api.types.infer_dtype(x.values))
        for key, value in types.items():
            value = str(value)
            if value == 'mixed' or value == 'unicode' or value == 'string':
                try:
                    df[key].str.encode('utf-8')
                except UnicodeDecodeError:
                    logger.write_log(
                        'Addressing UnicodeDecodeError; Column having unicode values: {}'.format(key))
                    try:
                        df[key] = df[key].str.decode('cp1252', 'ignore')
                    except UnicodeEncodeError:
                        df[key] = df[key].str.encode('utf-8', 'ignore').str.decode('utf-8', 'ignore')
        return df

    def exec_sql_file(self, file_path):
        """
        **Objective**
            It runs the pre-processing sql script, pass the path of the sql script. It will return the result message.

        :param file_path: provide the sql file path that you would like to execute
        :return: it runs the sql script and returns the execution message




        example::

            ENV.define("base_directory", "D:\\batch\\" + job_name + "\\")
            run = sql.Sql(config_file)
            run.exec_sql_file(os.path.join(base_directory,'createTable.sql'))

        """
        try:
            #file_path = self.server_config.get_dir_for_current_host(file_path, is_calc_path)
            if not os.path.isfile(file_path):
                raise IOError('File does not exist: {}'.format(file_path))
            retry = 1
            retry_flag = True
            sql_server = self.server
            counter=1
            if self.sqlversion == '2016' and self.sql_failover_partner.strip():
                while(retry_flag):
                    connection_string = urllib.parse.quote_plus(
                    'DRIVER='+ self.driver +
                    ';SERVER=' + sql_server +
                    ';DATABASE=' + self.database +
                    ';UID=' + self.sql_user +
                    ';PWD=' + self.sql_password)
                    engine = create_engine('mssql+pyodbc:///?odbc_connect=%s' %connection_string, connect_args={'connect_timeout': self.login_timeout})
                    try:
                        engine.connect()
                        logger.write_log("Connecting to.."+sql_server)
                        break
                    except:
                        sql_server = self.sql_failover_partner
                        counter = counter + 1
                        if(counter > 2):
                            retry_flag = False
                            logger.write_dbg('Unable to connect to servers: {}'.format(self.server + "," + self.sql_failover_partner))
                            raise

            retry_flag = True
            sqlcommand = 'sqlcmd -S ' + sql_server + ' -U ' + self.sql_user + ' -P ' + self.sql_password + ' -d ' + self.database + ' -i ' + file_path + ' -r1 -b -l ' + self.login_timeout
            logger.write_log(sqlcommand)
            while retry_flag:
                try:
                    logger.write_log("try:" + str(retry))
                    logger.write_log(
                        'Begin: exec_sql_file: {}'.format(file_path))  # name the specific file in the message
                    self.exe_sql(sqlcommand)
                    for dbg_file in glob.glob(os.path.join(self.base_dir,'*.dbg')):
                        os.remove(dbg_file)
                    logger.write_log(
                        'End: exec_sql_file: {}'.format(file_path))  # name the specific file in the message
                    retry_flag = False
                except:
                    if retry < self.retry:
                        retry = retry + 1
                    else:
                        retry_flag = False
                        raise
        except Exception:
            logger.write_dbg('DatabaseServerName:' + self.database + '/' + sql_server + ';')
            raise

    @staticmethod
    def exe_sql(cmd):
        call(cmd=cmd, stop=True)

    def execute_sql(self, sql_query):
        
        """
        **Objective**
            It runs the generic queries which may not return any resultset.

        :param sql_query: query that needs to be run on the sql server

        Example
        *******

        example::

            ENV.define("base_directory", "D:\\batch\\" + job_name + "\\")
            run = sql.Sql(config_file)
            run.execute_sql('update test set name = 'testing' where id = 1'))

        """
        try:
            if self.sql_failover_partner.strip():
                logger.write_log("Included FailoverPartner {0}".format(self.sql_failover_partner))
                failover_property = ';FAILOVER_PARTNER='+ self.sql_failover_partner
            else:
                failover_property = self.add_connection_property
            connection_string = urllib.parse.quote_plus(
                'DRIVER='+ self.driver +
                ';SERVER=' + self.server +
                ';DATABASE=' + self.database +
                ';UID=' + self.sql_user +
                ';PWD=' + self.sql_password + 
                ';APP=' + os.path.basename(os.path.dirname(self.server_config.current_dir)) + failover_property
            )
            engine = create_engine(
               'mssql+pyodbc:///?odbc_connect=%s' % connection_string)
            conn = engine.connect().connection
            cursor = conn.cursor()
            cursor.execute(sql_query)
            conn.commit()
        
        except Exception:
            logger.write_dbg('{}'.format(capture_trace()))
            raise

    def upload_dataframe_to_sqlserver(self, df, table_name, if_exists):
        """
        **Objective**
            It will upload the dataframe to the sql table .

        :param df: dataframe to be loaded into the sql table
        :param table_name: tablename for dataframe to be loaded
        :param if_exists: {‘fail’, ‘replace’, ‘append’}
                fail: If table exists, do nothing.
                replace: If table exists, drop it, recreate it, and insert data.
                append: If table exists, insert data. Create if does not exist.
        :return
        example::

            upload_datafarme_to_sqlserver(secondary_job_functions_df, 'Incoming_crowd_secondary_job_functions',
                                                if_exists='append')
        """
        try:
            if self.sql_failover_partner.strip():
                logger.write_log("Included FailoverPartner {0}".format(self.sql_failover_partner))
                failover_property = ';FAILOVER_PARTNER='+ self.sql_failover_partner
            else:
                failover_property = self.add_connection_property
            connection_string = urllib.parse.quote_plus(
                'DRIVER='+ self.driver +
                ';SERVER=' + self.server +
                ';DATABASE=' + self.database +
                ';UID=' + self.sql_user +
                ';PWD=' + self.sql_password + 
                ';APP=CCSDBFeed-' + os.path.basename(os.path.dirname(self.server_config.current_dir)) + failover_property
            )
            engine = create_engine(
                'mssql+pyodbc:///?odbc_connect=%s' % connection_string)  # sqlalchemy ,convert_unicode=False
            df.to_sql(table_name, engine, if_exists=if_exists)

        except Exception:
            logger.write_dbg('Database Server Name :  ' + self.database + '/' + self.server)
            logger.write_dbg('{}'.format(capture_trace()))
            raise

    def read_file_data(self, file_path, sep, dtype, convert_columns_to_datetime=None, drop_columns=None,
                       rename_header_names=None, index_col=None, header=int(0), encoding='utf-8', quoting=int(1),
                       chunksize=None, is_calc_path=True):
        """
        **Objective**
            It will read the data from the file and returns the dataframe .

        :param file_path: provide the path of the file you want to load
        :param sep: delimeter used in the file, provide it as b";" (b"delimeter")
        :param convert_columns_to_datetime: used to convert fields to datetime
        :param dtype: used to change the datatype of columns
        :param drop_columns: It is used for removing the unwanted columns from a dataframe
        :param rename_header_names: It is used for rename the file header names those are compatable with sql table columns
        :param index_col: if it is 0, takes first column in the dataframe as index
        :param header: if file has header int(0), if not int(1)
        :param encoding: specify the encoding of the file
        :param quoting: if all the columns are quoted int(1) else int(0)
        :param chunksize: number of rows upload in chunksize
        :return dataframe:




        Example::

                read_file_data(file_path, sep=',', convert_columns_to_datetime=["ind_term"], dtype={'tele_area_code': 'str'},
                    drop_columns=['ColumnName'],rename_header_names ={'job_term':'job_termination'},
                    index_col=0, header=0, encoding='utf-8', quoting=int(0),
                        dtype= dtype, chunksize=chunksize)
        """
        try:
            file_path = self.server_config.get_dir_for_current_host(file_path, is_calc_path)
            if chunksize:
                dt = pd.read_csv(file_path, sep=sep, index_col=index_col, header=header, encoding=encoding,
                                 quoting=quoting, dtype=dtype, chunksize=chunksize, error_bad_lines=False,
                                 iterator=True)
                df = pd.concat(dt, ignore_index=True)
            else:
                df = pd.read_csv(file_path, sep=sep, index_col=index_col, header=header, encoding=encoding,
                                 quoting=quoting, dtype=dtype, error_bad_lines=False)
            if rename_header_names is not None:
                for old, new in rename_header_names.items():
                    if old in df.columns:
                        df.rename(columns={old: new}, inplace=True)
            if drop_columns is not None:
                for column in drop_columns:
                    if column in df.columns:
                        df.drop(column, axis=1, inplace=True)
            if convert_columns_to_datetime is not None:
                for column in convert_columns_to_datetime:
                    if column in df.columns:
                        df[column] = pd.to_datetime(df[column], coerce=True)
            return df
        except:
            logger.write_dbg('{}'.format(capture_trace()))
            raise

    def cast_float_to_str(self, df):
        """
        **Objective**
            It converts float to string and remove all legging 0's.

        :param df: pass the data frame having float init
        :return: returns the data frame




        example::

            df = self.cast_float_to_str(pd.read_sql_query(sql_query, engine))
        """
        try:
            types = df.apply(lambda x: pd.lib.infer_dtype(x.values))
            for key, value in types.items():
                value = str(value)
                if value == 'floating':
                    try:
                        df[key] = df[key].map('{:f}'.format).astype(str).str.rstrip('0').str.rstrip('.')
                        df[key] = df[key].str.replace('nan', '')
                    except:
                        logger.write_dbg('{}'.format(capture_trace()))
                        raise
            return df
        except Exception:
            logger.write_dbg('{}'.format(capture_trace()))
            raise
        return df

    def prepare_df_info(self):
        """
        **Objective**
            Create the data frame that consists of stat's info of the data frame that is being executed in the package.

        :return: single data frame having summary of stats of all the data frame inside the package
        """
        try:
            if self.sql_data:
                for df_name, sql_query in self.sql_data.items():
                    self.df_info.loc[len(self.df_info)] = [df_name, None, None, None, None, None, None]
                self.df_info.set_index(['df_name'], inplace=True)
        except:
            logger.write_dbg('{}'.format(capture_trace()))
            raise

    def run_etl(self):
        # Run Feed
        self.prepare_df_info()
        self.create_parameter_dict()
        self.transform_func = Transform(self.parameter_dict)

        if self.sql_data:
            try:
                pre = datetime.datetime.now()
                for df_name, sql_query in self.sql_data.items():
                    setattr(self, df_name, self.run_sql(sql_query, df_name))
                self.exec_info.loc[0, 'run_sql']= str(datetime.datetime.now() - pre)
            except Exception:
                logger.write_dbg('Database Server Name :  ' + self.database + '/' + self.server)
                log_df_info(self)
                raise
        else:
            logger.write_dbg('{}'.format(capture_trace()))
            raise ValueError

        # check if we have empty dataframe and raise an error if the flag is set True
        if self.empty_df_flag:
            empty_df(self)

        # address the decoding issue
        try:
            pre = datetime.datetime.now()
            for df_name, file_name in self.sql_data.items():
                setattr(self, df_name, self.decode_df(getattr(self, df_name)))
            self.exec_info.loc[0, 'decoding'] = str(datetime.datetime.now() - pre)
        except Exception:
            log_df_info(self)
            logger.write_dbg('{}'.format(capture_trace()))
            raise

        # convert float to string
        try:
            pre_float = datetime.datetime.now()
            if self.convert_float_to_str_flag:
                for df_name, file_name in self.sql_data.items():
                    pre = datetime.datetime.now()
                    setattr(self, df_name, self.cast_float_to_str(getattr(self, df_name)))
                    self.df_info.loc[df_name, 'float_str_conv'] = str(datetime.datetime.now() - pre)
            self.exec_info.loc[0, 'float_str_conv_total'] = str(datetime.datetime.now() - pre_float)
        except Exception:
            log_df_info(self)
            logger.write_dbg('{}'.format(capture_trace()))
            raise

        # Transform Data
        try:
            pre = datetime.datetime.now()
            self.transform()
            self.exec_info.loc[0, 'transform'] = str(datetime.datetime.now() - pre)
        except Exception:
            log_df_info(self)
            logger.write_dbg('{}'.format(capture_trace()))
            raise

        # Save data to the file
        if any(self.results):
            try:
                pre_save = datetime.datetime.now()
                for df_name, file_name in list(self.results.items()):
                    df = getattr(self, df_name)
                    delattr(self, df_name)

                    pre = datetime.datetime.now()
                    logger.write_log('Begin save file {}: '.format(file_name))
                    self.save_df(df_name=df_name, df=df, file_name=file_name)
                    self.df_info.loc[df_name, 'time_to_save'] = str(datetime.datetime.now() - pre)
                    logger.write_log('End save file {}: '.format(file_name))
                self.exec_info.loc[0, 'save_file'] = str(datetime.datetime.now() - pre_save)

            except Exception:
                log_df_info(self)
                raise
        else:
            logger.write_dbg('Empty Dictionary: {}'.format(self.current_filename))
            raise ValueError

        # log df information to log file
        log_df_info(self)
        # file size check
        logger.write_log("Begin filesize_check" )
        if self.parallel_processing:
            pass
        else:
            filesize_check(base_directory = self.base_dir , output_dir = self.output, filesize_change_cutoff=self.filesize_change_cutoff, turn_off_check_date=self.turn_off_check_date)
        logger.write_log("End filesize_check" )


class Transform():
    def __init__(self, parameter_dict):
        # list of ascii control characters
        self.control_chars = ''.join(map(chr, list(range(0, 9)) + list(range(11, 13)) + list(range(14, 32)) + list(range(127, 128))))
        self.control_char_re = re.compile('[%s]' % re.escape(self.control_chars))
        # get the file parameters
        self.parameter_dict = parameter_dict
        self.escape = parameter_dict['escape']
        self.doublequote = parameter_dict['doublequote']

        self.logger = lib_log.Logger()

    def remove_ascii_control_chars(self, x):
        return self.control_char_re.sub('', x) if x is not None else x

    def replace_unicode_with_ascii(self, x):
        return normalize('NFKD', x.decode('utf-8')).encode('ascii', 'ignore') if x is not None else x

    def quote_column(self, x):
        if self.doublequote is False and self.escape is None:
            try:
                return ''.join(['"', x.decode('cp1252', 'ignore'), '"']) if x is not None else '""'
            except UnicodeEncodeError:
                return ''.join(
                    ['"', x.encode('utf-8', 'ignore').decode('utf-8', 'ignore'), '"']) if x is not None else '""'
        elif self.doublequote is True and self.escape is None:
            try:
                return ''.join(['"', x.decode('cp1252', 'ignore').replace('"', '""'), '"']) if x is not None else '""'
            except UnicodeEncodeError:
                return ''.join(
                    ['"', x.encode('utf-8', 'ignore').decode('utf-8', 'ignore').replace('"', '""'),
                     '"']) if x is not None else '""'
        elif self.doublequote is False and self.escape is not None:
            try:
                return ''.join(
                    ['"', x.decode('cp1252', 'ignore').replace('"', self.escape + '"'), '"']) if x is not None else '""'
            except UnicodeEncodeError:
                return ''.join(
                    ['"', x.encode('utf-8', 'ignore').decode('utf-8', 'ignore').replace('"', self.escape + '"'),
                     '"']) if x is not None else '""'

    def remove_non_ascii(self, x):
        return normalize('NFKC', x.decode('utf-8')).encode('ascii', 'ignore') if x is not None else x

    def convert_blank_to_null(self, x):
        # udf_ConvertBlankToNull
        return "" if x.strip() == "*" or x.strip() == "-" else x.strip() if x is not None else x

    def strip_controlchar(self, x):
        # udf_RemoveAsciiFromEndofString
        return x.strip(self.control_chars)

    def remove_leading_decimal_zero(self, x):
        return str(x).lstrip('0').replace('-0.', '-.') if x is not None else x

    def remove_lagging_decimal_zero(self, x):
        return str(x).rstrip('0').rstrip('.') if x is not None else x

    def get_fdsuid(self, x):
        # ufn_fdsuid
        pass

    def get_fdsuid_to_entityid(self, x):
        # ufn_fdsuid_to_entityid
        pass

class FilePyEtl(object):
    def __init__(self,):
        # read software.ini and grag the parameters
        self.retry = 3

        # custom function runtime parameters
        self.empty_df_flag = True
        self.convert_float_to_str_flag = False
        self.save_file_chunksize = None

        # stats
        self.exec_info = pd.DataFrame(columns=['read_file', 'decoding',
                            'float_str_conv_total', 'transform', 'save_file'])
        self.df_info = pd.DataFrame(
            columns=['df_name', 'df_size', 'row_count', 'time_to_getdata',
                        'float_str_conv', 'time_to_transform', 'time_to_save'])

        self.files_data = OrderedDict()
        self.results = OrderedDict()

        self.parameter_dict = {}

        __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def transform(self):
        pass

    def prepare_df_info(self):
        """
        **Objective**
            Create the data frame that consists of stat's info of the
            data frame that is being executed in the package.

        :return: single data frame having summary of stats of all the
    data frame inside the package
        """
        try:
            if self.files_data:
                for df_name, sql_query in self.files_data.items():
                    self.df_info.loc[len(self.df_info)] = \
                                [df_name, None, None, None, None, None, None]
                self.df_info.set_index(['df_name'], inplace=True)
        except:
            logger.write_dbg('{}'.format(capture_trace()))
            raise

    def read_file(self, df_name,**kwargs):
        """
        **Objective**
            It is used to run the sql query. It is called inside the class itself.

        :param sql_query: sql query
        :param df_name: data frame name
        :return:
        """
        try:
            # name the specific file in the message
            logger.write_log('Begin: Read File{}'.format(df_name))
            pre = datetime.datetime.now()  # use utc
            df = pd.read_csv(kwargs['path_or_buf'] ,
            sep = kwargs.get("sep" , ', ')                                 ,
            delimiter = kwargs.get("delimiter" , None)                     ,
            encoding = kwargs.get("encoding" , None)                       ,
            header = kwargs.get("header" , 'infer')                        ,
            names = kwargs.get("names" , None)                             ,
            index_col = kwargs.get("index_col" , None)                     ,
            usecols = kwargs.get("usecols" , None)                         ,
            squeeze = kwargs.get("squeeze" , False)                        ,
            prefix = kwargs.get("prefix" , None)                           ,
            mangle_dupe_cols = kwargs.get("mangle_dupe_cols" , True)       ,
            dtype = kwargs.get("dtype" , None)                             ,
            engine = kwargs.get("engine" , None)                           ,
            converters = kwargs.get("converters" , None)                   ,
            true_values = kwargs.get("true_values" , None)                 ,
            false_values = kwargs.get("false_values" , None)               ,
            skipinitialspace = kwargs.get("skipinitialspace" , False)      ,
            skiprows = kwargs.get("skiprows" , None)                       ,
            nrows = kwargs.get("nrows" , None)                             ,
            na_values = kwargs.get("na_values" , None)                     ,
            keep_default_na = kwargs.get("keep_default_na" , True)         ,
            na_filter = kwargs.get("na_filter" , True)                     ,
            verbose = kwargs.get("verbose" , False)                        ,
            skip_blank_lines = kwargs.get("skip_blank_lines" , True)       ,
            parse_dates = kwargs.get("parse_dates" , False)                ,
            infer_datetime_format = \
                            kwargs.get("infer_datetime_format" , False)    ,
            keep_date_col = kwargs.get("keep_date_col" , False)            ,
            date_parser = kwargs.get("date_parser" , None)                 ,
            dayfirst = kwargs.get("dayfirst" , False)                      ,
            iterator = kwargs.get("iterator" , False)                      ,
            chunksize = kwargs.get("chunksize" , None)                     ,
            compression = kwargs.get("compression" , 'infer')              ,
            thousands = kwargs.get("thousands" , None)                     ,
            decimal = kwargs.get("decimal" , '.')                          ,
            lineterminator = kwargs.get("lineterminator" , None)           ,
            quotechar = kwargs.get("quotechar" , '"')                      ,
            quoting = kwargs.get("quoting" , 0)                            ,
            escapechar = kwargs.get("escapechar" , None)                   ,
            comment = kwargs.get("comment" , None)                         ,
            dialect = kwargs.get("dialect" , None)                         ,
            tupleize_cols = kwargs.get("tupleize_cols" , None)             ,
            error_bad_lines = kwargs.get("error_bad_lines" , True)         ,
            warn_bad_lines = kwargs.get("warn_bad_lines" , True)           ,
            skipfooter = kwargs.get("skipfooter" , 0)                      ,
            doublequote = kwargs.get("doublequote" , True)                 ,
            delim_whitespace = kwargs.get("delim_whitespace" , False)      ,
            low_memory = kwargs.get("low_memory" , True)                   ,
            memory_map = kwargs.get("memory_map" , False)                  ,
            float_precision = kwargs.get("float_precision" , None))

            # name the specific file in the message
            logger.write_log('END: Read File{}'.format(df_name))
            # get df information
            self.df_info.set_value(df_name, 'df_size', file_size_convert(self, sum(block.values.nbytes for block in df.blocks.values())))
            self.df_info.set_value(df_name, 'row_count', len(df))
            self.df_info.set_value(df_name, 'time_to_getdata', \
                                str(datetime.datetime.now() - pre))
            return df
        except Exception:
            logger.write_dbg('{}'.format(capture_trace()))
            raise

    def save_df(self, df_name, df, **kwargs):
        """
        **Objective**
            It is called to save the individual file.
            It is called inside the class itself.

        :param df_name: name of the data frame
        :param df: data frame with the date
        :param file_name: output filename
        :return:
        """
        pre = datetime.datetime.now()

        """
        # If the kwargs contain the key, the following get method will
        # return its value, or else it assign the second argement of get method
        """

        df.to_csv(kwargs['path_or_buf']       ,
        sep = kwargs.get("sep" , '')                                    ,
        na_rep = kwargs.get("na_rep" , '')                              ,
        float_format = kwargs.get("float_format" , None)                ,
        columns = kwargs.get("columns" , None)                          ,
        header = kwargs.get("header" , True)                            ,
        index = kwargs.get("index" , True)                              ,
        index_label = kwargs.get("index_label" , None)                  ,
        mode = kwargs.get("mode" , 'w')                                 ,
        encoding = kwargs.get("encoding" , None)                        ,
        compression = kwargs.get("compression" , None)                  ,
        quoting = kwargs.get("quoting" , None)                          ,
        quotechar = kwargs.get("quotechar" , '"')                       ,
        line_terminator = kwargs.get("line_terminator" , '\n')          ,
        chunksize = kwargs.get("chunksize" , None)                      ,
        tupleize_cols = kwargs.get("tupleize_cols" , None)              ,
        date_format = kwargs.get("date_format" , None)                  ,
        doublequote = kwargs.get("doublequote" , True)                  ,
        escapechar = kwargs.get("escapechar" , None)                    ,
        decimal = kwargs.get("decimal" , '.'))

        self.df_info.set_value(df_name, 'time_to_save', \
                                    str(datetime.datetime.now() - pre))


    def run_etl(self):
        # Run Feed
        self.prepare_df_info()
        # self.transform_func = Transform(self.parameter_dict)

        if self.files_data:
            pre = datetime.datetime.now()
            for df_name, dct in self.files_data.items():
                setattr(self, df_name, self.read_file(df_name, **dct))
            self.exec_info.set_value(0, 'read_file', \
                                    str(datetime.datetime.now() - pre))

            # check if we have empty dataframe and raise an error
            #if the flag is set True
            if self.empty_df_flag:
                empty_df(self)

            # Transform Data
            try:
                pre = datetime.datetime.now()
                self.transform()
                self.exec_info.set_value(0, 'transform', \
                                    str(datetime.datetime.now() - pre))
            except Exception:
                log_df_info(self)
                logger.write_dbg('{}'.format(capture_trace()))
                raise

            # Save data to the file
            if any(self.results):
                try:
                    pre_save = datetime.datetime.now()
                    for df_name, dct in self.results.items():
                        df = getattr(self, df_name)
                        delattr(self, df_name)

                        pre = datetime.datetime.now()
                        logger.write_log('Begin save file{}: '.\
                                                            format(df_name))
                        self.save_df(df_name=df_name, df=df, **dct)
                        self.df_info.set_value(df_name, 'time_to_save', \
                                            str(datetime.datetime.now() - pre))
                        logger.write_log('End save file{}: '.\
                                            format(df_name))
                    self.exec_info.set_value(0, 'save_file', \
                                        str(datetime.datetime.now() - pre_save))

                except Exception:
                    log_df_info(self)
                    raise
        else:
            logger.write_dbg('No Files to read!')
            raise ValueError

        # log df information to log file
        log_df_info(self)


# class PyEtl(FilePyEtl, SqlPyEtl):
#     def __init__(self, config_file = False):
#         try :
#             if config_file:
#                 if os.path.isfile(config_file):
#                     print("in SQL pyetl")
#                     SqlPyEtl.__init__(self = self, config_file = config_file)
#                 else:
#                     raise FileNotFoundError(config_file + " does not exists!")
#             else:
#                 print("in File pyetl")
#                 FilePyEtl.__init__(self=self)
#         except Exception:
#             logger.write_dbg('{}'.format(capture_trace()))
#             raise
