# MANDATORY --------------------------------------------------------------------
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function
import os
import io
from lib_util import utilities
from lib_util import get_filename
from lib_util import lib_log
from batch_lib import *
import shutil
import string
from sys import argv
import glob
import configparser
import datetime
import os.path
import time
from datetime import timedelta, datetime
from socket import gethostname

# ------------------------------------------------------------------------------
job_name = str(argv[2])
job_name = job_name[job_name.find("-")+1:]

logger = lib_log.Logger()


@init
def section_init():
    """
    **Documentation**
    GenericFeedCode
    Feed Category: Generic Outgoing
    Feed Description: All Custom feeds run with this common python wrapper
    Content Set: N/A
    Archive Days: N/A
    Dependent Feed(s): None
    StakeHolder: 
    Procedure(s) to recover feed: If it fails, try re-running the feed from scratch.
    """
    remove('GenericFeedCode' + ".log")
    remove('GenericFeedCode' + ".dbg")
    log("------------------------------------------------------------------------------")
    logdate(job_name)
    log("------------------------------------------------------------------------------")
    ENV.define("J", today())
    ENV.define("root", "\\\\"+gethostname()+"\\D$\\")
    ENV.define("job_name", job_name)
    ENV.define("base", os.path.join(root, 'p3batch', job_name)+'\\')
    ENV.define("feedconfig", os.path.join(base, job_name + '.ini'))
    ENV.define("archive", os.path.join(root, 'archive', job_name)+'\\')
    ENV.define("archive_log", os.path.join(root, 'log\\', job_name + '\\'))
    ENV.define('netclient_dir', os.path.join(base, 'lib_util\\NetClient.pyz'))
    ENV.define("log", os.path.join(root, 'log', job_name)+'\\')
    ENV.define("out", os.path.join(root, 'out', job_name)+'\\')
    ENV.define("zip", os.path.join(root, 'zip', job_name)+'\\')
    ENV.define("dependency", os.path.join(root, 'dependency'))
    ENV.define("job_log", job_name + '.log')
    ENV.define("job_dbg", job_name + '.dbg')
    ENV.define("to", ["ccs.db.feed.notification@factset.com"])


@script
def feed_structure():
    try:
        parser = configparser.RawConfigParser(allow_no_value=True)
        parser.optionxform = str
        ENV.define('detail', parser)
        parser.read(feedconfig)

    except Exception:
        logger.write_dbg('{}'.format(utilities.capture_trace()))
        raise


@wait_success(feed_structure)
def check_dependency():
    try:
        if detail.has_section('dependency'):
            dependent_feeds = detail.options('dependency')
            ENV.define('dependent_feed', dependent_feeds)
            for feedname in dependent_feeds:
                dependent_times = detail.get('dependency', feedname).split(',')
                max_wait_time = str(dependent_times[0])[str(dependent_times[0]).find(':') + 1:]
                last_run_time = str(dependent_times[1])[str(dependent_times[1]).find(':') + 1:]
                utilities.check_dependency(dependency_dir=dependency, prerequisite_job_name=feedname,
                                           max_wait_time_min=int(max_wait_time), last_runtime_limit_min=int(last_run_time))
        else:
            pass

    except Exception:
        logger.write_dbg('{}'.format(utilities.capture_trace()))
        raise


@wait_success(check_dependency)
def clean():
    try:
        logdate("Clean the working folders")
        call("del /S /Q " + out + "*.*")
        call("del /S /Q " + zip + "*.*")
        days=detail.options('archivedays')[0]
        utilities.clean_archive_dir(days_limit=int(days), path=archive)

    except Exception:
        logger.write_dbg('{}'.format(utilities.capture_trace()))
        raise


@wait_success(clean)
def run_package():
    try:
        if detail.has_section('package'):
            packages=detail.options('package')
            for package in packages:
                packagepath = os.path.join(base, (str(package)))
                if str(package).endswith('.dtsx'):
                    packageconfigpath = os.path.join(base, (str(package)[:str(package).find('.')] + '.dtsConfig'))
                    utilities.run_ssis(packagepath, packageconfigpath)
                elif str(package).endswith('.dts'):
                    utilities.run_dts(package=packagepath)

        else:
            pass

    except Exception:
        logger.write_dbg('{}'.format(utilities.capture_trace()))
        raise


@wait_success(run_package)
def rename_files():
    try:
        if detail.has_section('renamefiles'):
            filenames=detail.options('renamefiles')
            if len(filenames)!=0:
                for filename in filenames:
                    timestamp = str(datetime.now().strftime('%Y%m%d'))
                    ENV.define("time_stamp_now", timestamp)
                    for files in os.listdir(out):
                        if files==filename:
                            filename_without_ext = os.path.splitext(files)[0]
                            extension_name= os.path.splitext(files)[1]
                            new_file_name_with_ext = filename_without_ext + '_' + time_stamp_now + extension_name
                            os.rename(os.path.join(out, files), os.path.join(out, new_file_name_with_ext))
            elif len(filenames)==0:
                timestamp = str(datetime.now().strftime('%Y%m%d'))
                ENV.define("time_stamp_now", timestamp)
                for files in os.listdir(out):
                    filename_without_ext = os.path.splitext(files)[0]
                    extension_name= os.path.splitext(files)[1]
                    new_file_name_with_ext = filename_without_ext + '_' + time_stamp_now + extension_name
                    os.rename(os.path.join(out, files), os.path.join(out, new_file_name_with_ext))
        else:
            pass


    except Exception:
        logger.write_dbg('{}'.format(utilities.capture_trace()))
        raise


@wait_success(rename_files)
def zip_files():
    try:
        if detail.has_section('zip'):
            get_file_name = get_filename.GetFileName()
            zip_filenames=detail.options('zip')
            if detail.has_section('dependency'):
                dependency_number = len(dependent_feed)
                for allfeeds in dependent_feed:
                    dependentfeedpath = 'dependentfeedpath' + str(dependency_number)
                    ENV.define(dependentfeedpath, os.path.join(root, 'Out', allfeeds))
                    dependency_number -= 1
            for zipname in zip_filenames:
                if "[yyyy][mm][dd]" in str(zipname):
                    zipname=str(zipname).replace('[yyyy][mm][dd]', '[YYYY][MM][DD]')
                zipname_timestamp = get_file_name.get_filename_timestamp(filename=str(zipname), timezone='utc')
                zip_contents = detail.get('zip',zipname).split(',')

                if detail.has_section('dependency'):
                    for filename in zip_contents:
                        if os.path.isfile(os.path.join(out, filename)):
                            utilities.zip_files(os.path.join(out, filename), zip_dir=zip,zip_filename=zipname_timestamp)
                        else:
                            dependency_loop = len(dependent_feed)
                            while dependency_loop>0:
                                dep_file_paths=os.path.join(globals()['dependentfeedpath'+str(dependency_loop)], filename)
                                if os.path.isfile(dep_file_paths):
                                    utilities.zip_files(dep_file_paths, zip_dir=zip, zip_filename=zipname_timestamp)
                                    break
                                dependency_loop -= 1

                else:
                    for filename in zip_contents:
                            utilities.zip_files(os.path.join(out, filename), zip_dir=zip, zip_filename=zipname_timestamp)
        else:
            pass

    except Exception:
        logger.write_dbg('{}'.format(utilities.capture_trace()))
        raise


@wait_success(zip_files)
def create_donefile():
    try:
        if detail.has_section('done'):
            if str(detail.get('done','format'))=='24hr':
                with open(os.path.join(zip, str(detail.options('done')[0])), "w") as done_file:
                    done_file.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S").lstrip('0'))
            elif str(detail.get('done','format'))=='12hr' :
                with open(os.path.join(zip, str(detail.options('done')[0])), "w") as done_file:
                    done_file.write(datetime.now().strftime("%#m/%#d/%#Y %#I:%M:%S %p").lstrip('0'))
        else:
            pass

    except Exception:
        logger.write_dbg('{}'.format(utilities.capture_trace()))
        raise


@wait_success(create_donefile)
def ftp_files():
    try:
        if detail.has_section('ftp'):
            ftpsites = detail.options('ftp')
            for ftps in ftpsites:
                ftpconf = detail.get('ftp', ftps).split(',')
                utilities.ftp_upload(netclient_dir, os.path.join(base, ftpconf[0]), os.path.join(base, ftpconf[1]))
        else:
            pass

    except Exception:
        logger.write_dbg('{}'.format(utilities.capture_trace()))
        raise


@wait_success(ftp_files)
def archive_files():
    if detail.has_section('archivefolders'):
        archivefolders=detail.options('archivefolders')
        for folder in archivefolders:
            utilities.archive_files(base,job_name,archive,globals()[str(folder)],log)	
    else:
        utilities.archive_files(base, job_name, archive, zip, log)


@wait_success(archive_files)
def archive_log_files():
    shutil.copy(os.path.join(base, 'GenericFeedCode.log'), os.path.join(base, job_log))
    utilities.archive_log_files(base, job_name, archive_log)


@wait_success(archive_log_files)
def create_dependency():
    utilities.create_dependency_file(dependency_dir=dependency, job_name=job_name)


@end
def notification():
    shutil.copy(os.path.join(base, 'GenericFeedCode.log'), os.path.join(base, job_log))
    if 'GenericFeedCode.dbg' in os.listdir(base):
        shutil.copy(os.path.join(base, 'GenericFeedCode.dbg'), os.path.join(base, job_dbg))
    if detail.getboolean('notification', 'success'):
        utilities.success_email(to, base, job_name)
    if detail.getboolean('notification', 'failure'):
        utilities.fail_email(send_to=to, base_directory=base, job_name=job_name, arch_log_dir=log)
    os.remove(base + job_name + '.log')
    if job_name + '.dbg' in os.listdir(base):
        os.remove(base + job_name + '.dbg')
    else:
        pass
