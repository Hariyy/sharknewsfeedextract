#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals  
from __future__ import print_function
import os
import configparser
from . import lib_log
import socket
import re
import glob

__version__='1.0'


class GetServerConfig(object):
    """
    Loads the values from settings.ini file in to variables, and verifies path


    example::

        self.server_config = get_server_config.GetServerConfig()
        self.server_config.is_primary_host_server("ccscalca01")
    """

    def __init__(self):
        self.host_name = socket.gethostname()
        self.host_name = '\\\\' + self.host_name + '\\D\\'
        self.config_file = "D:\\DataGroup1\\ServerConfiguration\\settings_2016.ini"
        #if not os.path.exists(self.config_file):
        #    self.config_file =os.path.join(self.host_name, 'batch','MasterEnvironmentConfiguration','settings_2016.ini')
        self.current_dir = os.path.dirname(__file__)
        self.logger = lib_log.Logger()
        # self.config = object
        self.read_config()
        self.load_parameter()

    def read_config(self):
        """
        Read config file and load parameters to the variables
        """
        self.config = configparser.ConfigParser()
        self.config.read(self.config_file)

    def load_parameter(self):
        """
        Verifies & loads all values passed in settings.ini file
        """
        # environment Parameter
        self.environment = self.config.get('settings', 'environment').strip()
        try:
            self.primary_host_list = self.config.get('settings', 'primary_host')
            self.primary_host_list = ['\\\\'+x.strip()+'\\' for x in self.primary_host_list.split(',')]
        except Exception as e:
           self.logger.write_dbg("Missing primary_host value")
           raise ValueError

        try:
            self.secondary_host_list = self.config.get('settings', 'secondary_host')
            self.secondary_host_list = ['\\\\'+x.strip()+'\\' for x in self.secondary_host_list.split(',')]
        except:
           self.logger.write_dbg("Missing secondary_host value")
           raise ValueError

        try:
            self.primary_ftp = self.config.get('settings', 'primary_ftp').strip()
        except:
            self.logger.write_dbg("Missing primary_ftp value in settings.ini file")
            raise ValueError     

        try:
            self.secondary_ftp = self.config.get('settings', 'secondary_ftp').strip()
        except:
            self.logger.write_dbg("Missing secondary_ftp value in settings.ini file")
            raise ValueError

        try:
            ftp_data = self.config.get('settings','ftp_redirection').strip().replace('{','').replace('}','').replace(' ','')
            self.ftp_redirection_dict = dict(x.split(':') for x in ftp_data.split(','))
        except:
            self.logger.write_dbg("ftp_redirection are wrongly configured in settings.ini file")
            raise ValueError

        try:
            redirection_data = self.config.get('settings','sql_server_redirection').strip().replace('{','').replace('}','').replace(' ','')
            self.sql_server_redirection_dict = dict(x.split(':') for x in redirection_data.split(','))
        except:
            self.logger.write_dbg("sql server redirection list is wrongly configured in settings.ini file")
            raise ValueError

        try:
            failover_data = self.config.get('settings','sql_failover_partner').strip().replace('{','').replace('}','').replace(' ','')
            self.sql_failover_partner_dict = dict(x.split(':') for x in failover_data.split(','))
        except:
            self.logger.write_dbg("sql failover partner list is wrongly configured in settings.ini file")
            raise ValueError

        try:
            self.sql_server_config_dict = {x.replace('sql_','').strip() : y for x, y in self.config.items('settings') if 'sql' in x and x not in ('sql_server_redirection','sql_failover_partner')}
        except:
            self.logger.write_dbg("sql server names are wrongly configured in settings.ini file")
            raise ValueError
            
        try:
            self.sql_listener_names_dict = {}
            listener_data = self.config.get('settings','sql_listener_names').strip().replace('{','').replace('}','').replace(' ','')
            self.sql_listener_names_dict = dict(x.split(':') for x in listener_data.split(','))
        except:
            pass
        try:
            lion_2016servers = self.config.get('settings', 'lion_2016_sqlservers').strip().replace('[','').replace(']','').replace(' ','')
            self.lion_2016servers = [x for x in lion_2016servers.split(',')]
        except:
            pass
            
    def is_primary_host_server(self):
        """
        Verify if the current host is listed as primary_host in settings.ini file
        """
        if any(self.host_name.lower() == primary.lower() for primary in self.primary_host_list):
            return True
        else:
            return False

    def is_secondary_host_server(self):
        """
        Verify if the current host is listed as secondary_host in settings.ini file
        """
        if any(self.host_name.lower() == primary.lower() for primary in self.secondary_host_list):
            return True
        else:
            return False

    def is_file_upload_enabled(self):
        """
        Verify if the ftp upload enabled in current host in settings.ini file
        """
        if (self.is_primary_host_server() and self.primary_ftp.lower() == 'on') or (self.is_secondary_host_server() and self.secondary_ftp.lower() == 'on') :
            return True
        else:
            return False

    def get_sql_server_name(self, server):
        """
        return the sql server for the provided server parameter in current host; if secondary host then server will be redirected.

        eg: sqlserver = get_sql_server_name('lionfeed-prod')
            print(sqlserver) # lionfeeda03 in primary hosting server--considering A as primary
                             # lionfeedb03 in secondary hosting server--In secondary lionfeed-prod redirected to lionfeed-failover & then resulted in lionfeedb03
        """
        try:
            modified = False
            sql_server_name = server
            for k in self.sql_server_config_dict.keys():
                if k.lower().split('.')[0] == server.lower().split('.')[0]:
                    sql_server_name = self.sql_server_config_dict[k]
                    modified = True
                    break
            
            for k,v in self.sql_listener_names_dict.items():
                if sql_server_name.lower().split('.')[0] == v.lower().split('.')[0] or self.get_sql_failover_partner(sql_server_name).lower().split('.')[0] == v.lower().split('.')[0]: 
                    sql_server_name = k
                    break
                
            if modified == True:
                sql_server_name = sql_server_name.lower().split('.')[0]
                self.logger.write_log("Redirected to sql server from {0} to {1}".format(server, sql_server_name))
        except:
            sql_server_name = server
        return sql_server_name

    def get_sql_failover_partner(self, server):
        """
        return the failover sql server for the provided server parameter;

        eg: sqlserver = get_sql_server_name_by_dns('lionsql-prod')
            print(sqlserver)# lionsqlb02
        """
        try:
            failover_server = ""
            for k, v in self.sql_failover_partner_dict.items():
                if server.lower().split('.')[0] == k.lower().split('.')[0]:
                    failover_server = self.sql_failover_partner_dict[k]
                    break
                elif server.lower().split('.')[0] == v.lower().split('.')[0]:
                    failover_server = k
                    break
        except:
            pass
        return failover_server

    def get_ftp_server_for_current_host(self, ftp_server):
        """
        return the ftp server for the provided server parameter in current host; if secondary host then server will be redirected.

        eg: redirect_ftp = get_ftp_server_for_current_host('adminftp-a.factset.com')
            print(redirect_ftp) #adminftp-b.factset.com
        """
        try:
            new_ftp_server = ftp_server
            if not self.is_primary_host_server():
                for k in self.ftp_redirection_dict.keys():
                    if ftp_server.lower() == k.lower():
                        new_ftp_server = self.ftp_redirection_dict[k]
                        self.logger.write_log("Redirected to ftp server {0}".format(new_ftp_server))
                        break
                    else:
                        new_ftp_server = None
        except:
            pass
        return new_ftp_server

    def get_dir_for_current_host(self, path, is_calc_path = True):
        """
        checks if path contains primary or secondary server in settings.ini file, if available then update else append the current host if path is not dfs.
        eg:
        ENV.define("out_dir", "out\\EntityFull\\")
        output_dir = get_dir_for_current_host(out_dir)
        print(output_dir) ## \\ccscalca01\out\EntityFull\
        """
        try:
            modified_path = path
            if self.host_name.lower() not in path.lower():
                if any(primary.lower() in path.lower() for primary in self.primary_host_list):
                    modified_path = re.compile([primary.lower() for primary in self.primary_host_list if primary in path.lower()][0].replace("\\",""), re.IGNORECASE).sub(self.host_name.replace("\\",""), modified_path)
                elif any(secondary.lower() in path.lower() for secondary in self.secondary_host_list):
                    modified_path = re.compile([secondary.lower() for secondary in self.secondary_host_list if secondary in path.lower()][0].replace("\\",""), re.IGNORECASE).sub(self.host_name.replace("\\",""), modified_path)
                elif path == os.path.basename(path):
                    modified_path = os.path.join(os.path.curdir, path)
                elif '\\dfs\\' not in path.lower() and '\\datagroup' not in path.lower() and is_calc_path:
                    modified_path = os.path.join(os.path.join('\\\\',self.host_name,'d$') if 'stg' in self.host_name else  os.path.join('\\\\',self.host_name), modified_path)

                if not len(glob.glob(modified_path)) > 0:
                    if len(glob.glob(path)) > 0:
                        modified_path = path
                    elif "." not in path:
                        raise Exception("Directory in current host is not available {0}".format(modified_path))
                    else:
                        raise Exception("File doesn't exist in current host {0}".format(modified_path))
            return modified_path
        except Exception as e:
            self.logger.write_dbg('{}'.format(str(e)))
            raise
    def get_sql_db_name(self, server, database):
        """
        return the database name for 2016 feed servers
        eg: dbname = get_sql_db_name('lionfeed-prod','lion_reporting')
            print(dbname)# LION
        """
        try:
            if database.lower() == "lion_reporting" and len(self.lion_2016servers)>0:
                if any(server.lower().split('.')[0] in server2016.lower() for server2016 in self.lion_2016servers):
                    database = "LION"
        except:
            pass
        return database