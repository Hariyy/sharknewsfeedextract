#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function
from __future__ import unicode_literals
import codecs
import glob
import json
import os
import shutil
import smtplib
import socket
import sys
import time
import traceback
import urllib
from datetime import timedelta, datetime
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate
from batch_lib import call
import pysftp
import ftputil
import ftplib
import re
from .get_server_config import GetServerConfig
import pandas as pd
import csv
import io
from . import lib_log
from .lib_cipher import Cipher

__version__ = '2.0'

time_stamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
crypt = 'l4crypt'
default_retry = 3
server_config = GetServerConfig()


def ftp_files(ftp_website, uid, pw, ftp_location, path, ignore_server_configuration = False, is_calc_path = True):
    """
    **Objective**
        It is used to upload output files to FTP server. you will have to pass parameters mentioned
        below in order to upload the files. The function will determine the whether the passed path is file or
        the directory. If it is a directory, it will upload all the files in it.

    :param ftp_website: FTP website (server name)
    :param uid: user id
    :param uid: user id
    :param pw: password
    :param ftp_location: directory inside the ftp website
    :param path: output directory location (you can pass directory path or file path)
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("ftp_website_0", "adminftp-dev.factset.com")
        ENV.define("uid_0", "ftp_ccs_admin")
        ENV.define("pw_0", "*******")
        ENV.define("ftp_location_0", "/ftp_ccs_dev/cie/edm")

        utilities.ftp_files(ftp_website_0, uid_0, pw_0, ftp_location_0, zip_dir)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('FTP files')
    logger.write_log('-' * 40)

    try:
        ftp_redirection = None
        if server_config.is_secondary_host_server():
            ftp_redirection = server_config.get_ftp_server_for_current_host(ftp_website)
        if server_config.is_file_upload_enabled() or ignore_server_configuration or ftp_redirection is not None:
            if ftp_redirection is not None:
                ftp_website = ftp_redirection#for secondary ftp redirection
                logger.write_log("FTP redirected to {}".format(ftp_redirection))
            session = ftplib.FTP(ftp_website, uid, pw, timeout=300)
            session.cwd(ftp_location)
            path = server_config.get_dir_for_current_host(path, is_calc_path)
            if os.path.isdir(path):
                count = os.listdir(path)
                if count:
                    # Walk the tree.
                    for root, directories, files in os.walk(path):
                        for filename in files:
                            # Join the two strings in order to form the full filepath.
                            file_path = os.path.join(root, filename)
                            fl = open(file_path, 'rb')
                            session.storbinary('STOR ' + filename, fl)
                            fl.close()
                else:
                    logger.write_log("Output file(s) doesn't exists: {}".format(path))
            else:
                if os.path.isfile(path):
                    file_path = path
                    fl = open(file_path, 'rb')
                    filename = os.path.basename(file_path)
                    session.storbinary('STOR ' + filename, fl)
                    fl.close()
                else:
                    logger.write_log("Output file(s) doesn't exists: {}".format(path))
            session.quit()
        else:
            logger.write_log("FTP upload functionality is not enabled in the current host: {}".format(server_config.host_name))
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def ftp_upload(netclient_pyz, netclient_config, put_file, ignore_server_configuration = False, is_calc_path = True):
    """
    **Objective**

        It is used to upload output files to FTP server. you will have to pass parameters mentioned
        you need to create *netclient.conf* and *file.put* file in *base_directory*

    :param netclient_pyz: path of netclient.pyz
    :param netclient_config: path of netclient.conf
    :param put_file: path of file.get
    :return:


    example::

        ENV.define("netclient_pyz", base_directory + 'lib_util\\netclient.pyz')
        ENV.define("netclient_config", base_directory + 'netclient.conf')
        ENV.define("put_file", base_directory + 'file.put')

        utilities.ftp_upload(netclient_pyz, netclient_config, put_file)


    netclient.conf::

        {
            "delete-remote": 0,
            "conf": {
                "retries": 3,
                "clients": 1
            },
            "put": {
                "servers": [{
                    "server_path": "/ftp_ccs_dev/cie/test/",
                    "server_name": "adminftp-dev.factset.com",
                    "server_port": "21",
                    "login": "ftp_ccs_admin",
                    "password": "******",
                    "type": "ftp"
                }]
            }
        }
    To encrypt a password in your netclient_config.conf file....

    step1 -- Create a file called netclient_config_0.conf with your ftp server information including the non-encrypted password...

    step2 -- Open a cmd.exe window and run the following commands at the DOS prompt...

    Command line::

        D:\> cd D:\Batch\job_name_dir
        D:\Batch\job_name_dir
        D:\Batch\job_name_dir> python D:\Batch\your_job_name_dir\lib_util\\netclient.pyz -c netclient_config_0.conf -e
        2016-05-13T17:47:08.481000;WARNING: Password for [put][servers][][password] is not encrypted ! (*it shows incorrect message*)
        D:\Batch\job_name_dir>

    step 3 -- run the more command on the netclient_config_0.conf and take a look...the password should now be encrypted in the file...
        D:\Batch\job_name_dir>more netclient_config_0.conf

    netclient_config_0.conf::

        {
            "delete-remote": 0,
            "conf": {
                "retries": 3,
                "clients": 1
            },
            "put": {
                "servers": [{
                    "server_path": "/ftp_ccs_dev/cie/test/",
                    "server_name": "adminftp-dev.factset.com",
                    "server_port": "21",
                    "login": "ftp_ccs_admin",
                    "password": "crypted:*******",
                    "type": "ftp"
                }]
            }
        }

    file.put::

        BOF;GETINC;1.0;
        PUTFTP;D:\zip\Batch_Job\\test_*.zip;test_*.zip
        EOF;
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Upload to FTP')
    logger.write_log('-' * 40)
    try:
        netclient_pyz = server_config.get_dir_for_current_host(netclient_pyz, is_calc_path)
        netclient_config = server_config.get_dir_for_current_host(netclient_config, is_calc_path)
        put_file = server_config.get_dir_for_current_host(put_file, is_calc_path)
        if not os.path.isfile(netclient_pyz):
            er_msg = "netclient_pyz is missing {}".format(netclient_pyz)
            IOError(er_msg)
        if not os.path.isfile(netclient_config):
            er_msg = "netclient_config is missing {}".format(netclient_config)
            IOError(er_msg)
        if not os.path.isfile(put_file):
            er_msg = "put_file is missing {}".format(put_file)
            IOError(er_msg)
        logger.write_log('-' * 40)
        logger.write_log('Clean up previous netclient.dbg')
        logger.write_log('-' * 40)
        if os.path.isfile(netclient_pyz.replace('.pyz', '.dbg')):
            os.remove(netclient_pyz.replace('.pyz', '.dbg'))
        redirect_config = redirect_ftp_netclient_config(netclient_config)
        if server_config.is_file_upload_enabled() or ignore_server_configuration or redirect_config is not None:
            new_put_file = correct_host_path_in_ftp_action_file(put_file, is_calc_path)
            netclient_config = redirect_config if redirect_config is not None else netclient_config
            exe = sys.executable
            cmd = exe + ' ' + netclient_pyz + ' -c ' + netclient_config + ' -f ' + (new_put_file if new_put_file is not None else put_file)
            logger.write_log(cmd)
            os.system(cmd)
        else:
            logger.write_log("FTP upload functionality is not enabled in the current host: {}".format(server_config.host_name))
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise
    split_path = netclient_config.split('\\')
    netclient_config_file = split_path[-1]
    job = split_path[-2]
    if os.path.isfile(netclient_pyz.replace('.pyz', '.dbg')):
        shutil.move(netclient_pyz.replace('.pyz', '.dbg'), netclient_config.replace(netclient_config_file, 'NetClient.dbg'))
    if os.path.isfile(netclient_config.replace(netclient_config_file, '') + job + ".dbg"):
        consolidate_log_dbg_files(netclient_config.replace(netclient_config_file, ''), job)
    elif os.path.isfile(netclient_config.replace(netclient_config_file, '') + "NetClient.dbg"):
        os.rename(netclient_config.replace(netclient_config_file, '') + "NetClient.dbg", netclient_config.replace(netclient_config_file, '') + job + ".dbg")


def ftp_download(netclient_pyz, netclient_config, get_file, wait_time_mins = 60, is_calc_path = True):
    """
    **Objective**
        It is used to download output files from FTP server. you will have to pass parameters mentioned
        you need to create *netclient.conf* and *file.get* file in *base_directory*

    :param netclient_pyz:  path of netclient.pyz
    :param netclient_config: path of netclient.conf
    :param get_file: path of file.get
    :param wait_time_mins: buffer time in minutes to wait till file becomes available. Default wait time is 60 Minutes
    :return:


    example::

        ENV.define("netclient_pyz", base_directory + 'lib_util\\netclient.pyz')
        ENV.define("netclient_config", base_directory + 'netclient.conf')
        ENV.define("get_file", base_directory + 'file.get')

        utilities.ftp_download(netclient_pyz, netclient_config, get_file)
		# or if buffer time has to be increased to 2 hours then in that case:
        utilities.ftp_download(netclient_pyz, netclient_config, get_file, wait_time_mins = 120)
    netclient.conf::

        {
            "delete-remote": 0,
            "conf": {
                "retries": 3,
                "clients": 1
            },
            "get": {
                "server": {
                    "server_path": "/ftp_ccs_dev/cie/test/",
                    "server_name": "adminftp-dev.factset.com",
                    "server_port": "21",
                    "login": "ftp_ccs_admin",
                    "password": "*****",
                    "type": "ftp"
                }
            }
        }

    file.get::

        BOF;GETINC;1.0;
        GETFILE;test_178.zip;D:\zip\Batch_Job\test_178.zip
        EOF;
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Download from FTP')
    logger.write_log('-' * 40)
    try:
        netclient_pyz = server_config.get_dir_for_current_host(netclient_pyz, is_calc_path)
        netclient_config = server_config.get_dir_for_current_host(netclient_config, is_calc_path)
        get_file = server_config.get_dir_for_current_host(get_file, is_calc_path)
        if not os.path.isfile(netclient_pyz):
            er_msg = "netclient_pyz is missing {}".format(netclient_pyz)
            IOError(er_msg)
        if not os.path.isfile(netclient_config):
            er_msg = "netclient_config is missing {}".format(netclient_config)
            IOError(er_msg)
        if not os.path.isfile(get_file):
            er_msg = "get_file is missing {}".format(get_file)
            IOError(er_msg)
        new_get_file = correct_host_path_in_ftp_action_file(get_file, is_calc_path)
        exe = sys.executable
        cmd = exe + ' ' + netclient_pyz + ' -c ' + netclient_config + ' -f ' +  (new_get_file if new_get_file is not None else get_file)
        logger.write_log(cmd)

        max_wait_time_sec = int(wait_time_mins)*60  # converting minutes to seconds
        current_wait = 0
        retry_flag = True
        
        #downloaded_result=os.system(cmd)
        while retry_flag:
            try:
                return_value = call(cmd=cmd, stop=True)
                return_code = return_value[0]
                out_data = return_value[1]
                err_data = return_value[2]
                if return_code != 0 or err_data != '':
                    if err_data != '':
                        raise Exception(err_data)
                    else:
                        raise Exception(out_data)

                logger.write_log("File downloading completed!!")
                retry_flag = False
                # wait for 15 minutes and check again (15*60)
            except:
                logger.write_log("ErrorMessage::"+str(err_data))
                if max_wait_time_sec > current_wait:
                    logger.write_log('Waiting..')
                    time.sleep(15*60)
                    current_wait += 15*60
                    logger.write_log('Retry..' + str(current_wait))
                else:                
                    retry_flag = False
                    er_msg = "Incoming file is not available in FTP. Please rerun the feed once file is available!!"
                    raise IOError(er_msg)

    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def sftp_upload(sftp_config, put_file, ignore_server_configuration = False, is_calc_path = True):
    """
    **Objective**
        Uploads files to SFTP server.

    :param sftp_config: path of sftp.conf
    :param put_file: path of file.put
    :return:


    example::

        ENV.define("sftp_config", base_directory + 'sftp.conf')
        ENV.define("put_file", base_directory + 'file.put')

        utilities.sftp_upload(sftp_config, put_file)

    sftp.conf::

        {
            "conf": {
                "retries": 3
            },
            "put": {
                "servers": [{
                    "server_path": "/test/",
                    "server_name": "sftp.factset.com",
                    "server_port": "22",
                    "login": "sftp_login",
                    "password": "*****",
                    "key_file" : "path_of_key_file",
                }]
            }
        }

    file.put::

        BOF;GETINC;1.0;
        PUTFTP;filename.txt;filename.txt;
        PUTFTP;D:\zip\Batch_Job\\filename.txt;filename.txt;
        PUTFTP;D:\zip\Batch_Job\\filename_*.txt;; (current directory)
        EOF;

    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Upload to SFTP')
    logger.write_log('-' * 40)

    try:
        sftp_config = server_config.get_dir_for_current_host(sftp_config, is_calc_path)
        put_file = server_config.get_dir_for_current_host(put_file, is_calc_path)
        if not os.path.isfile(sftp_config):
            er_msg = "sftp_config is missing {}".format(sftp_config)
            raise IOError(er_msg)
        if not os.path.isfile(put_file):
            er_msg = "put_file is missing {}".format(put_file)
            raise IOError(er_msg)
        if not put_file.endswith(".put"):
            er_msg = "incorrect file extension for put_file {}".format(put_file)
            raise IOError(er_msg)

        file_list = read_ftp_action_file(put_file)
        if len(file_list) == 0:
            raise Exception("no files to upload")

        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None

        with open(sftp_config) as data_file:
            data = json.load(data_file)
            servers = data["put"]["servers"]
            for server in servers:
                server_path = server["server_path"]
                if not server_path.startswith("/"):
                    server_path = "/" + server_path
                if not server_path.endswith("/"):
                    server_path += "/"
                server_name = server["server_name"]
                login = server["login"]
                server_port = int(server["server_port"])
                if server['password']:
                    password = decrypt_pw(server['password'], crypt_flag=None)
                else :
                    password = None
                if server['key_file']:
                    key_file = server['key_file']
                else :
                    key_file = None
                retries = int(data["conf"]["retries"])
                done_list = []
                sftp_redirection = None
                if server_config.is_secondary_host_server():
                    sftp_redirection = server_config.get_ftp_server_for_current_host(server_name)
                if server_config.is_file_upload_enabled() or ignore_server_configuration or sftp_redirection is not None:
                    if sftp_redirection is not None:
                        server_name = sftp_redirection
                        logger.write_log("SFTP redirected to {}".format(sftp_redirection))
                    while retries > 0:
                        try:
                            with pysftp.Connection(host=server_name, username=login, password=password,
                                                   private_key = key_file, cnopts=cnopts, port=server_port) as sftp:
                                for file in file_list:
                                    source = file[0]
                                    source = server_config.get_dir_for_current_host(source, is_calc_path)
                                    if source in done_list:
                                        continue
                                    destination = file[1]
                                    if "*" not in source:
                                        if not os.path.isfile(source):
                                            raise Exception("source file does not exist {}".format(source))
                                        if destination == '':
                                            destination = source
                                        logger.write_log("Uploading destination file {}".format(destination))
                                        sftp.put(localpath=source, remotepath=server_path + destination)
                                    else:
                                        source_dir = os.path.dirname(source)
                                        source_file = os.path.basename(source)
                                        if source_file == source:
                                            source_dir = os.path.curdir
                                        if not os.path.isdir(source_dir):
                                            raise Exception("source directory does not exist {}".format(source_dir))
                                        for file in os.listdir(source_dir):
                                            if re.match(source_file.replace(".", "\.").replace("*", "(.*)"), file):
                                                logger.write_log("Uploading file {}".format(file))
                                                sftp.put(localpath=os.path.join(source_dir, file), remotepath=server_path + file)
                            done_list.append(source)
                            retries = 0
                        except IOError:
                            time.sleep(10)
                            retries -= 1
                            if retries == 0:
                                raise
                else:
                    logger.write_log("SFTP upload functionality is not enabled in the current host: {}".format(server_config.host_name))
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def sftp_download(sftp_config, get_file, wait_time_mins = 60, is_calc_path= True):
    """
    **Objective**
        Downloads files from SFTP server.

    :param sftp_config: path of sftp.conf
    :param get_file: path of file.get
    :param wait_time_mins: buffer time in minutes to wait till file becomes available. Default wait time is 60 Minutes
    :return:


    example::

        ENV.define("sftp_config", base_directory + 'sftp.conf')
        ENV.define("get_file", base_directory + 'file.get')

        utilities.sftp_download(sftp_config, get_file)
        # or if buffer time has to be increased to 2 hours then in that case:
        utilities.sftp_download(sftp_config, get_file, wait_time_mins = 120)

    sftp.conf::

        {
            "conf": {
                "retries": 3,
            },
            "get": {
                "server": {
                    "server_path": "/test/",
                    "server_name": "sftp.factset.com",
                    "server_port": "22",
                    "login": "sftp_login",
                    "password": "*****",
                }
            }
        }

    file.get::

        BOF;GETINC;1.0;
        GETFILE;filename.txt;filename_downloaded.txt;
        GETFILE;filename_*.txt;D:\zip\Batch_Job\;
        GETFILE;filename_*.txt;; (current directory)
        EOF;
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Download from SFTP')
    logger.write_log('-' * 40)

    try:
        sftp_config = server_config.get_dir_for_current_host(sftp_config, is_calc_path)
        get_file = server_config.get_dir_for_current_host(get_file, is_calc_path)
        if not os.path.isfile(sftp_config):
            er_msg = "sftp_config is missing {}".format(sftp_config)
            raise IOError(er_msg)
        if not os.path.isfile(get_file):
            er_msg = "get_file is missing {}".format(get_file)
            raise IOError(er_msg)
        if not get_file.endswith(".get"):
            er_msg = "incorrect file extension for get_file {}".format(get_file)
            raise IOError(er_msg)

        file_list = read_ftp_action_file(get_file)
        if len(file_list) == 0:
            raise Exception("no files to download")

        max_wait_time_sec = int(wait_time_mins)*2  # converting minutes to seconds
        current_wait = 0
        retry_flag = True
        
        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None

        with open(sftp_config) as data_file:
            data = json.load(data_file)
            server = data["get"]["server"]
            server_path = server["server_path"]
            if not server_path.startswith("/"):
                server_path = "/" + server_path
            if not server_path.endswith("/"):
                server_path += "/"
            server_name = server["server_name"]
            login = server["login"]
            server_port = int(server["server_port"])
            password = decrypt_pw(server['password'], crypt_flag=None)
            # password = data(cipher.decrypt(server['password']))
            retries = int(data["conf"]["retries"])
            done_list = []
            while retries > 0:
                try:
                    with pysftp.Connection(host=server_name, username=login, password=password,
                                           cnopts=cnopts, port=server_port) as sftp:
                        for file in file_list:
                            source = file[0]
                            if source in done_list:
                                continue
                            destination = file[1]
                            print(destination)
                            if "*" not in source:
                                if destination == '':
                                    destination = os.path.join(os.path.curdir, source)
                                elif destination == os.path.basename(destination):
                                    destination = os.path.join(os.path.curdir, destination)
                                elif os.path.isdir(destination):
                                    destination = os.path.join(destination, source)
                                elif os.path.isdir(os.path.dirname(destination)):
                                    pass#continue as folder exists
                                else:
                                    raise Exception("incorrect destination file {}".format(destination))
                                destination = os.path.join(server_config.get_dir_for_current_host(os.path.dirname(destination), is_calc_path) , os.path.basename(destination))
                                sftp.get(remotepath="." + server_path + source, localpath=destination)
                            else:
                                for file in sftp.listdir(remotepath="." + server_path):
                                    if re.match(source.replace(".", "\.").replace("*", "(.*)"), file):
                                        destination = os.path.join(server_config.get_dir_for_current_host(os.path.dirname(destination), is_calc_path) , os.path.basename(destination))
                                        if not os.path.isdir(destination):
                                            raise Exception("incorrect destination directory {}".format(destination))
                                        sftp.get(remotepath="." + server_path + file, localpath=os.path.join(destination, file))
                            done_list.append(source)
                    retries = 0
                except IOError:
                    if retries > 0 or max_wait_time_sec > current_wait:
                        logger.write_log('Waiting..')
                        retries -= 1
                        time.sleep(15*60)
                        current_wait += 15*60
                        logger.write_log('Retry..' + str(current_wait))
                    else:
                        retry_flag = False
                        raise
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise

def read_ftp_action_file(file):
    logger = lib_log.Logger()
    output = []
    try:
        actions = ['PUTFTP', 'GETFILE']
        with open(file, 'r') as f:
            for line in f:
                data = line.split(";")
                tag = data[0]
                if tag not in actions:
                    continue
                else:
                    output.append((data[1], data[2]))
        print('\n'.join(str(p) for p in output) )
        return output
    except Exception as e:
        logger.write_log_and_dbg("Error while reading .put and .get files... {}".format(str(e)))
        raise

def https_download(netclient_config, get_file, wait_time_mins = 60, is_calc_path = True):
    """
    **Objective**
        Downloads files from https server.

    :param netclient_config: path of NetClient.conf
        parameters in NetClient:
            server_path
            server_name
            server_port
        Apart from these three parameters there maybe additional custom parameters that are to be added to the querystring, they can be given under the custom_param
    :param get_file: path of file.get
    :param wait_time_mins: buffer time in minutes to wait till file becomes available. Default wait time is 60 Minutes


    example::

        ENV.define("netclient_config", base_directory + 'NetClient.conf')
        ENV.define("get_file", base_directory + 'file.get')

        utilities.https_download(netclient_config, get_file)
        # or if buffer time has to be increased to 2 hours then in that case:
        utilities.https_download(netclient_config, get_file, wait_time_mins = 120)

    NetClient.conf::

        {
            "conf": {
                "retries": 3
            },
            "get": {
                "server": {
                    "server_path": "/LoansReport/",
                    "server_name": "loans.markit.com",
                    "server_port": "443",
                    "login": "factsetuser",
                    "PASSWORD": "goloanx",
                    "custom_param": {
                        "LEGALENTITY": "factset",
                        "ASOF": "10-26-16"
                    }
                }
            }
        }

    file.get::

        BOF;GETINC;1.0;
        GETFILE;filename.txt;D:\zip\Batch_Job\\filename.txt;
        EOF;
        ***OR***
        BOF;GETINC;1.0;
        GETFILE;filename1.txt;D:\zip\Batch_Job\\filename1.txt;
        GETFILE;filename2.txt;D:\zip\Batch_Job\\filename2.txt;
        EOF;
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Download from HTTPS')
    logger.write_log('-' * 40)

    try:
        netclient_config = server_config.get_dir_for_current_host(netclient_config, is_calc_path)
        get_file = server_config.get_dir_for_current_host(get_file, is_calc_path)
        if not os.path.isfile(netclient_config):
            er_msg = "NetClient is missing {}".format(netclient_config)
            IOError(er_msg)
        if not os.path.isfile(get_file):
            er_msg = "get_file is missing {}".format(get_file)
            IOError(er_msg)
        if not get_file.endswith(".get"):
            er_msg = "incorrect file extension for get_file {}".format(get_file)
            IOError(er_msg)

        max_wait_time_sec = int(wait_time_mins)*60  # converting minutes to seconds
        current_wait = 0
        retry_flag = True

        files_to_download = read_ftp_action_file(get_file)
        server_prop = {}
        with open(netclient_config) as data_file:
            data = json.load(data_file)
            retries = int(data["conf"]["retries"])
            server = data["get"]["server"]

            for prop in server:
                if prop != 'custom_param':
                    server_prop.update({prop: server[prop]})
                else:
                    custom_param = data["get"]["server"]["custom_param"]
                    for custom_prop in custom_param:
                        server_prop.update({custom_prop: custom_param[custom_prop]})
        if server_prop.has_key('password'):
            server_prop['password'] = decrypt_pw(server_prop['password'], crypt_flag=None)

        server_path = server_prop['server_path']
        server_name = server_prop['server_name']
        server_port = server_prop['server_port']
        type = server_prop['type']

        del server_prop['server_path']
        del server_prop['server_name']
        del server_prop['server_port']

        if not server_path.startswith("/"):
            server_path = "/" + server_path
        if not server_path.endswith("/"):
            server_path += "/"

        querystring_param = server_prop
        if(server_prop.has_key('login')):
            querystring_param['USERNAME'] = querystring_param.pop('login')
            params = urllib.urlencode(querystring_param)
        while retries > 0:
            try:
                for file in files_to_download:
                    if(server_prop.has_key('login')):
                        response = urllib.urlopen(type+'://' + server_name + server_path + file, params)
                    else:
                        response = urllib.urlopen(type+'://' + server_name + server_path + file)

                    content = response.read()
                    if 'not found' in content:
                        raise IOError('File Not Found')
                    destination = os.path.join(server_config.get_dir_for_current_host(os.path.dirname(files_to_download[file].rstrip()), is_calc_path),os.path.basename(files_to_download[file].rstrip()))
                    with open(destination, 'w') as f:
                        f.write(content)

                retries = 0
            except IOError:
                if retries > 0 or max_wait_time_sec > current_wait:
                        logger.write_log('Waiting..')
                        retries -= 1
                        time.sleep(15*60)
                        current_wait += 15*60
                        logger.write_log('Retry..' + str(current_wait))
                else:
                        retry_flag = False
                        raise
            except Exception:
                raise
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise

def clean_ftp_dir(ftp_website, uid, pw, ftp_location, days_limit, file_pattern=None, ignore_server_configuration = False):
    """
    **Objective**

        It cleans the ftp directory based on the parameter passed below. We can define how many days
        files that we would like to keep, it will remove files older than that.

    :param ftp_website: FTP website
    :param uid: user id
    :param pw: password
    :param ftp_location: directory inside the ftp website
    :param file_pattern: file pattern that needs to clean
    :param days_limit: days' files to keep
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("ftp_website_0", "adminftp-dev.factset.com")
        ENV.define("uid_0", "ftp_ccs_admin")
        ENV.define("pw_0", "*******")
        ENV.define("ftp_location_0", "/ftp_ccs_dev/cie/edm")

        utilities.clean_ftp_dir(ftp_website=ftp_website_0,uid=uid_0,pw=pw_0,ftp_location=ftp_location_0,days_limit=7,file_pattern='entity_v1_full_*.zip')
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('clean ftp directory')
    logger.write_log('-' * 40)

    try:
        ftp_redirection = None
        if server_config.is_secondary_host_server():
            ftp_redirection = server_config.get_ftp_server_for_current_host(ftp_website)
        if server_config.is_file_upload_enabled() or ignore_server_configuration or ftp_redirection is not None:
            if ftp_redirection is not None:
                ftp_website = ftp_redirection #for secondary ftp redirection
                logger.write_log("FTP redirected to {}".format(ftp_redirection))
            host = ftputil.FTPHost(ftp_website, uid, pw)
            now = time.time()
            host.chdir(ftp_location)
            names = host.listdir(host.curdir)
            for name in names:
                if host.path.getmtime(name) < (now - (int(days_limit) * 86400)):
                    if host.path.isfile(name):
                        if file_pattern is None:
                            host.remove(name)
                        else:
                            str1 = (os.path.splitext(os.path.basename(name))[0])
                            pattern = os.path.splitext(os.path.basename(file_pattern))[0]
                            if re.search(pattern, str1):
                                logger.write_log('{}'.format(name))
                                host.remove(name)
            host.close()
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def clean_ftp_dir_netclient(netclient_config, days_limit, file_pattern=None, ignore_server_configuration = False):
    """
    **Objective**

        It cleans the ftp directory based on the parameter passed below. We can define how many days
        files that we would like to keep, it will remove files older than that.

    :param netclient_config: FTP website
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("netclient_config", "adminftp-dev.factset.com")

        utilities.clean_ftp_dir_netclient(netclient_config,file_pattern):
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('clean ftp directory')
    logger.write_log('-' * 40)

    try:
        if server_config.is_file_upload_enabled() or ignore_server_configuration: 
            netclient_config = server_config.get_dir_for_current_host(netclient_config)
            if os.path.isfile(netclient_config):
                # cipher = Cipher()
                with open(netclient_config) as data_file:
                    data = json.load(data_file)
                    for server in data["put"]["servers"]:
                        ftp_location = server["server_path"]
                        ftp_website = server["server_name"]
                        uid = server["login"]
                        pw = decrypt_pw(server['password'], crypt_flag=None)
                        ftp_redirection = None
                        if server_config.is_secondary_host_server():
                            ftp_redirection = server_config.get_ftp_server_for_current_host(ftp_website)#for secondary ftp redirection
                        if server_config.is_file_upload_enabled() or ignore_server_configuration or ftp_redirection is not None:
                            if ftp_redirection is not None:
                                ftp_website = ftp_redirection
                                logger.write_log("FTP redirected to {}".format(ftp_redirection))
                            # pw = data(cipher.decrypt(server['password']))
                            host = ftputil.FTPHost(ftp_website, uid, pw)
                            now = time.time()
                            host.chdir(ftp_location)
                            names = host.listdir(host.curdir)
                            for name in names:
                                if host.path.getmtime(name) < (now - (int(days_limit) * 86400)):
                                    if host.path.isfile(name):
                                        if file_pattern is None:
                                            host.remove(name)
                                        else:
                                            str1 = (os.path.splitext(os.path.basename(name))[0])
                                            pattern = os.path.splitext(os.path.basename(file_pattern))[0]
                                            if re.search(pattern, str1):
                                                logger.write_log('{}'.format(name))
                                                host.remove(name)
                            host.close()
            else:
                raise IOError('netclient.conf file doesn''t')
        else:
            logger.write_log("FTP cleanup functionality is not enabled in the current host: {}".format(server_config.host_name))
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def archive_files(base_directory, job_name, archive_dir, zip_dir, archive_log_dir, is_calc_path = True):
    """
    **Objective**

        It archives the zip/output files created by the feed into the *archive_dir*.
        It first creates new folder inside archive_dir and named new directory EST timestamp.
        Then moves the files from path mentioned as *zip_dir* (it can be single file / *output_dir* / *zip_dir*
        depending on the archive requirement) to new directory. It also archives log files to
        *archive_log_dir*.


    :param job_name: name of the job
    :param archive_dir: archive directory
    :param zip_dir: zip files' dir
    :param archive_log_dir: path of log archive directory
    :param base_directory: path to the base directory
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("base_directory", "D:\\batch\\"+job_name+"\\")
        ENV.define("archive_dir", "D:\\archive\\"+job_name+"\\")
        ENV.define("job_name", "StandardDataFeed-EDMV1")
        ENV.define("zip_dir", "D:\\zip\\"+job_name+"\\")
        ENV.define("archive_log_dir", "D:\\Log\\"+job_name+"\\")

        utilities.archive_files(base_directory, job_name, archive_dir, zip_dir, archive_log_dir)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Archive output files')
    logger.write_log('-' * 40)
    try:
        base_directory = server_config.get_dir_for_current_host(base_directory, is_calc_path)
        archive_dir= server_config.get_dir_for_current_host(archive_dir, is_calc_path)
        zip_dir =  server_config.get_dir_for_current_host(zip_dir, is_calc_path)
        archive_log_dir = server_config.get_dir_for_current_host(archive_log_dir, is_calc_path)

        archive_log_files(base_directory, job_name, archive_log_dir)
        count = os.listdir(zip_dir)
        if count:
            if not os.path.exists(os.path.join(archive_dir, time_stamp)):
                os.makedirs(os.path.join(archive_dir, time_stamp))
            for root, directories, files in os.walk(zip_dir):
                for filename in files:
                    file_path = os.path.join(root, filename)
                    logger.write_log(file_path, os.path.join(archive_dir, time_stamp, filename))
                    shutil.copy(file_path, os.path.join(archive_dir, time_stamp, filename))
                    # shutil.copy(os.path.join(base_directory, job_name + '.log'),
                    #             os.path.join(archive_log_dir, job_name + '_' + time_stamp + '.log'))
                    # if os.path.isfile(os.path.join(base_directory, job_name + '.dbg')):
                    #     shutil.copy(os.path.join(base_directory, job_name + '.dbg'),
                    #                 os.path.join(archive_log_dir, job_name + '_' + time_stamp + '.dbg'))
        else:
            logger.write_log("There are no files to archive!")
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def archive_log_files(base_directory, job_name, arch_log_dir, is_calc_path = True):
    """
    **Objective**

        It archives Batch_job.log as well as Batch_job.dbg files to log folder.

    :param base_directory: path of base directory
    :param job_name: pass the job name
    :param arch_log_dir: path of arch_log_dir
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("base_directory", "D:\\batch\\"+job_name+"\\")
        ENV.define("job_name", "StandardDataFeed-EDMV1")
        ENV.define("archive_log_dir", "D:\\Log\\"+job_name+"\\")

        utilities.archive_log_files(base_directory, job_name, archive_log_dir)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Archive log files')
    logger.write_log('-' * 40)
    try:
        base_directory = server_config.get_dir_for_current_host(base_directory, is_calc_path)
        arch_log_dir = server_config.get_dir_for_current_host(arch_log_dir, is_calc_path)

        dbg_file = os.path.join(base_directory, job_name + '.dbg')
        log_file = os.path.join(base_directory, job_name + '.log')
        arch_dbg_file = os.path.join(arch_log_dir, job_name + '_' + time_stamp + '.dbg')
        arch_log_file = os.path.join(arch_log_dir, job_name + '_' + time_stamp + '.log')

        # Archive log and dbg files
        if os.path.isfile(log_file):
            shutil.copy(log_file, arch_log_file)
        if os.path.isfile(dbg_file):
            shutil.copy(dbg_file, arch_dbg_file)
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def send_mail(send_to, subject, message, file_path_list = None, is_calc_path = True):
    """
    **Objective**

        It sends the email over to the send_to List.

    :param send_to: to address (pass the list as [])
    :param subject: subject
    :param message: email body
    :param file_path_list: provide list of files to attach with email
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file
    """
    logger = lib_log.Logger()
    try:
        commaspace = ', '
        send_from = 'FeedAdmin@factset.com'
        server = 'mail.factset.com'
        msg = MIMEMultipart()
        msg['From'] = send_from
        msg['To'] = commaspace.join(send_to)  # send_to
        msg['Date'] = formatdate(localtime=True)
        msg['Subject'] = subject
        # Create html format file for the failure and success
        msg.attach(MIMEText(message, 'html', 'utf-8'))
        if file_path_list:
            for each_file_path in file_path_list:
                each_file_path = server_config.get_dir_for_current_host(each_file_path, is_calc_path)
                file_name = os.path.basename(each_file_path)
                if file_name.endswith('dbg'):
                    file_name = os.path.basename(each_file_path).replace('.dbg','_dbg.txt')
                if file_name.endswith('log'):
                    file_name = os.path.basename(each_file_path).replace('.log', '_log.txt')
                part = MIMEBase('application', "octet-stream")
                part.set_payload(open(each_file_path, "rb").read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 'attachment', filename=file_name)
                msg.attach(part)
        smtp = smtplib.SMTP(server)

        smtp.sendmail(send_from, send_to, msg.as_string())
        smtp.quit()
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def success_email(send_to, base_directory, job_name, is_calc_path = True):
    """
    **Objective**

        It generates the success email at the completion of the job.
        If the Batch_job.dbg exists, it will not generate the email.

    :param send_to: to address
    :param base_directory: base directory path to get the .log file
    :param job_name: job name
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("base_directory", "D:\\batch\\"+job_name+"\\")
        ENV.define("job_name", "StandardDataFeed-EDMV1")
        ENV.define("to", ["ccsdbunit@factset.com","ksurana@factset.com"])

        utilities.success_email(to, base_directory, job_name)
    """
    logger = lib_log.Logger()
    try:
        server_name = socket.gethostname()
        base_directory =  server_config.get_dir_for_current_host(base_directory, is_calc_path)
        subject = '' + server_name + ' Success: ' + job_name + ''
        dbg_file = os.path.join(base_directory, job_name + '.dbg')
        log_file = os.path.join(base_directory, job_name + '.log')

        if os.path.isfile(dbg_file):
            return
            # raise ValueError('The error file exists, The job failed')
        message = """
            <p>
                <br />
                    <strong><i>Feed:</i> Feed_Name <br />
                    <i>Status:</i> Success <br />
                    <i>Server:</i> Server_Name</strong>
            </p>
            <p>If you need to contact the support team urgently please email
                <em>
                    <a href="mailto:feed_support@factset.com">feed_support@factset.com</a>
                </em>
            </p>
        """
        message = message.replace('Feed_Name', job_name).replace('Server_Name', server_name)
        default_to = ['ccs.db.feed.notification@factset.com'] if server_config.environment.lower() == "production" else []
        if type(send_to) == str:
            default_to.append(send_to)
        if type(send_to) == list:
            default_to.extend(send_to)

        path_list = []
        path_list.append(log_file)

        send_mail(default_to, subject, message, path_list)
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def fail_email(send_to, base_directory, job_name, arch_log_dir, is_calc_path = True):
    """
    **Objective**
        It generates the failure email at the completion of the job.
        If the Batch_job.dbg exists, it will generate the email.
    :param send_to: to address
    :param base_directory:  base directory path to get the .log and .dbg file
    :param job_name: job name
    :param arch_log_dir: move .log and .dbg files
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg
            file.


    example::

        ENV.define("base_directory", "D:\\batch\\"+job_name+"\\")
        ENV.define("job_name", "StandardDataFeed-EDMV1")
        ENV.define("archive_log_dir", "D:\\Log\\"+job_name+"\\")
        ENV.define("to", ["ccsdbunit@factset.com","ksurana@factset.com"])

        utilities.fail_email(to, base_directory, job_name,arch_log_dir)
    """
    logger = lib_log.Logger()
    try:
        server_name = socket.gethostname()
        base_directory =  server_config.get_dir_for_current_host(base_directory, is_calc_path)
        arch_log_dir =  server_config.get_dir_for_current_host(arch_log_dir, is_calc_path)
        subject = '' + server_name + ' Failure: ' + job_name + ''
        dbg_file = os.path.join(base_directory, job_name + '.dbg')
        log_file = os.path.join(base_directory, job_name + '.log')
        # arch_dbg_file = os.path.join(arch_log_dir, job_name + '_' + time_stamp + '.dbg')
        # arch_log_file = os.path.join(arch_log_dir, job_name + '_' + time_stamp + '.log')

        if not os.path.isfile(dbg_file):
            return

        archive_log_files(base_directory, job_name, arch_log_dir)

        failure_message = ''
        with codecs.open(dbg_file, "r", "utf-8") as f:
            for line in f:
                if "sqlcmd" not in line:
                    cleanedLine = line.strip()
                    if cleanedLine:  # is not empty
                        # print(cleanedLine)
                        failure_message += "<pre>" + cleanedLine + "</pre> "

        message = """
        <p>
            This automated email indicates that a failure has occurred while running feed: <strong>Feed_Name. </strong><br />
            This is a <b>CCS DB Unit</b> managed feed - Please use the procedure outlined in the Twiki listed below:<u1:p></u1:p>
        </p>
        <p>
            <a href="http://infonet/view/ContentEngineering/ContentCollectionServicesDBSupportSchedule">http://infonet/view/ContentEngineering/ContentCollectionServicesDBSupportSchedule</a><u1:p></u1:p>
        </p>
        <p>
            <b>Additional Information:</b>
        </p>
        <p>
            <br /><i>Feed:</i> Feed_Name <br />
            <i>Status:</i> Failure <br />
            <i>Server:</i> Server_Name
        </p>
        <p>
            <i>Error Message:</i>Error_Message
        </p>
        <p>
            FactSet support has been notified. If you need to contact the support team urgently please email
            <em>
                <a href="mailto:feed_support@factset.com">feed_support@factset.com</a>
            </em>
        </p>
        """
        try:
            message = message.replace('Feed_Name', job_name).replace('Server_Name', server_name).replace(
                'Error_Message', failure_message)
        except:
            failure_message = "<pre>Please open the attached '*_dbg.txt' file (in notepad as a text file) to see the error message</pre> <br>\n"
            message = message.replace('Feed_Name', job_name).replace('Server_Name', server_name).replace(
                'Error_Message', str(failure_message))
        #default_to = ['ccs.db.feed.notification@factset.com'] if "prod" in server_config.environment.lower() else []
        default_to = []
        if type(send_to) == str:
            default_to.append(send_to)
        if type(send_to) == list:
            default_to.extend(send_to)
        path_list = []
        path_list.append(log_file)
        path_list.append(dbg_file)

        send_mail(default_to, subject, message, path_list)
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def deef_get_dirpath(arch_dir, is_calc_path = True):
    """
    **Objective**
        It will get list the sub-directories inside arch_dir and
        returns path of most recent two directories by creation date.
        It is used as part of the deef process to identify new and old directories.

    :param arch_dir: path to the archive directory to get the new and old path info
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("archive_dir", "D:\\archive\\"+job_name+"\\")

        utilities.deef_get_dirpath(arch_dir)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Get deef directories path for old and new files')
    logger.write_log('-' * 40)
    try:
        arch_dir =  server_config.get_dir_for_current_host(arch_dir, is_calc_path)
        sub_dirs = filter(os.path.isdir, [os.path.join(arch_dir, f) for f in os.listdir(arch_dir)])
        sub_dirs = sorted(sub_dirs, reverse=True)
        if len(sub_dirs) < 2:
            raise IOError(
                'Failed at deef_get_dirpath():\n Error: No old files for the deef!!! \n{}'.format(arch_dir))
        new_dir = sub_dirs[0]
        old_dir = sub_dirs[1]
        return new_dir, old_dir
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def deef_find_new_dir(pointer_file, arch_dir, is_calc_path = True):
    try:
        logger = lib_log.Logger()
        pointer_file =  server_config.get_dir_for_current_host(pointer_file, is_calc_path)
        arch_dir =  server_config.get_dir_for_current_host(arch_dir, is_calc_path)
        if not os.path.isfile(pointer_file):
            er_msg = "Dir doesn't exists {}".format(pointer_file)
            raise ValueError(er_msg)
        if not os.path.isdir(arch_dir):
            er_msg = "Dir doesn't exists {}".format(arch_dir)
            raise ValueError(er_msg)

        with open(pointer_file, 'r') as f:
            lines = f.readlines()
        sub_dirs = filter(os.path.isdir, [os.path.join(arch_dir, f) for f in os.listdir(arch_dir)])
        sub_dirs = sorted(sub_dirs, reverse=True)

        if len(sub_dirs) < 2:
            er_msg = 'Failed at deef_get_dirpath():\n Error: No old files for the deef!!! \n{}'.format(arch_dir)
            raise ValueError(er_msg)

        dir_list = []
        old = lines[0]
        for s_dir in sub_dirs:
            if s_dir.lower() > old.lower():
                dir_list.append(s_dir.lower())
        dir_list.reverse()
        dir_list_tuple = []

        for dir in dir_list:
            dir_list_tuple.append((dir.lower(), old.lower()))
            old = dir
        return dir_list_tuple
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def zip_files(output_dir, zip_dir, zip_filename, is_calc_path = True):
    """
    **Objective**

        Create a zip file.

    :param output_dir: pass the path of the file/directory
    :param zip_dir: destination path of zip file
    :param zip_filename: zip file name
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        # using the sequence number in the zip filename

        ENV.define("output_dir", "D:\\Out\\"+job_name+"\\")
        ENV.define("zip_dir", "D:\\zip\\"+job_name+"\\")
        ENV.define("zip_filename_0", "entity_v1_full_#.zip")
        ENV.define("sequence_number_file", base_directory + "sequence_number.ini")

        get_file_name = get_filename.GetFileName()
        zip_filename, sequence_number = get_file_name.get_filename_seqnumber(zip_filename_0, sequence_number_file)
        utilities.zip_files(zip_dir=zip_dir, output_dir=output_dir, zip_filename=zip_filename)
        f = open(sequence_number_file, 'w+')
        f.write('sequence_number = ' + str(sequence_number))
        f.close()

        # using timestamp in the zip filename

        ENV.define("output_dir", "D:\\Out\\"+job_name+"\\")
        ENV.define("zip_dir", "D:\\zip\\"+job_name+"\\")
        ENV.define("zip_filename", "inc_filermst_[YYYY][MM][DD].zip")

        get_file_name = get_filename.GetFileName()
        zip_filename_timestamp_0 = get_file_name.get_filename_timestamp(zip_filename, 'est')
        utilities.zip_files(zip_dir=zip_dir, output_dir=output_dir, zip_filename=zip_filename_timestamp_0)


    """
    logger = lib_log.Logger()
    # logger.write_log('-' * 40)
    # logger.write_log('Zip output files')
    # logger.write_log('-' * 40)
    try:
        output_dir =  server_config.get_dir_for_current_host(output_dir, is_calc_path)
        zip_dir =  server_config.get_dir_for_current_host(zip_dir, is_calc_path)
        if os.path.isdir(zip_dir):
            exe = sys.executable
            # Get the ziptool.pyz path
            dir_1 = os.path.abspath(os.path.dirname(os.path.realpath(__file__)))
            while 1:
                if os.path.isfile(os.path.join(dir_1, 'ziptool.pyz')):
                    pyz = os.path.join(dir_1, 'ziptool.pyz')
                    break
                else:
                    dir_1 = os.path.abspath(dir_1 + "/../")

            if os.path.isdir(output_dir):
                # If the dir_flag =1, it mean zip all the files in the dir
                count = os.listdir(output_dir)
                if count:
                    # logger.write_log('Begin Zip')
                    cmd = exe + ' ' + pyz + ' a --input-dir ' + output_dir + ' --output-dir ' + zip_dir + ' ' + zip_filename + ' files *.*'
                    # logger.write_log(cmd)
                    os.system(cmd)
                    # logger.write_log('End Zip')
                else:
                    logger.write_log("There are no files to zip")
            elif os.path.isfile(output_dir):
                # If the dir_flag = 0, it means, you need to zip zip output_file_name
                output_file_name = os.path.basename(output_dir)
                output_file_path = os.path.dirname(output_dir)
                # logger.write_log('Begin Zip')
                cmd = exe + ' ' + pyz + ' a --input-dir ' + output_file_path + ' --output-dir ' + zip_dir + ' ' + zip_filename + ' files ' + output_file_name
                # logger.write_log(cmd)
                os.system(cmd)
                # logger.write_log('End Zip')
            else:
                er_msg = 'Failed at zip_files():\nError: \n The File doesn''t exist: {}'.format(output_dir)
                raise IOError(er_msg)
        else:
            if not os.path.isdir(output_dir):
                er_msg = 'Failed at zip_files():\nError: \n The directory doesn''t exist: {}'.format(output_dir)
                raise IOError(er_msg)
            else:
                er_msg = 'Failed at zip_files():\nError: \n The directory doesn''t exist: {}'.format(zip_dir)
                raise IOError(er_msg)
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def unzip_files(unzip_file, unzip_dir, is_calc_path = True):
    """
    **Objective**

        Unzip   unzip_file to the unzip_dir)

    :param unzip_file: source zip file name
    :param unzip_dir: destination directory path
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("old", "D:\\In\\old\\"+job_name+"\\")
        ENV.define("new", "D:\\In\\new\\"+job_name+"\\")
        new_dir,old_dir = utilities.deef_get_dirpath(input_archive_dir)
        ENV.define("new_zip_dir", new_dir)
        ENV.define("old_zip_dir", old_dir )

        old_zip = glob.glob(old_zip_dir+'\\entity_v1_full*.zip')
        new_zip = glob.glob(new_zip_dir+'\\entity_v1_full*.zip')
        utilities.unzip_files(old_zip[0],old)
        utilities.unzip_files(new_zip[0],new)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Unzip files')
    logger.write_log('-' * 40)
    try:
        unzip_file =  server_config.get_dir_for_current_host(unzip_file, is_calc_path)
        unzip_dir =  server_config.get_dir_for_current_host(unzip_dir, is_calc_path)
        exe = sys.executable
        dir_1 = os.path.abspath(os.path.dirname(os.path.realpath(__file__)))
        while 1:
            if os.path.isfile(os.path.join(dir_1, 'ziptool.pyz')):
                pyz = os.path.join(dir_1, 'ziptool.pyz')
                break
            else:
                dir_1 = os.path.abspath(dir_1 + "/../")

        if os.path.isfile(unzip_file) and os.path.isdir(unzip_dir):
            cmd = exe + ' ' + pyz + ' e ' + unzip_file + ' ' + unzip_dir
            logger.write_log('Begin Unzip')
            logger.write_log(cmd)
            os.system(cmd)
            logger.write_log('End Unzip')
        else:
            if not os.path.isfile(unzip_file):
                er_msg = 'Failed at unzip_files():\nError: \n The File doesn''t exist: {}'.format(unzip_file)
                raise IOError(er_msg)
            if not os.path.isdir(unzip_dir):
                er_msg = 'Failed at unzip_files():\nError: \n The directory doesn''t exist: {}'.format(unzip_dir)
                raise IOError(er_msg)
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def clean_archive_dir(days_limit, path, is_calc_path = True):
    """
    **Objective**

    It will delete archived files older then limit mentioned except it will always keep last archive directory

    :param days_limit: Define the number of days history you want to keep
    :param path: Archive directory path
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("archive_dir", "D:\\archive\\"+job_name+"\\")

        utilities.clean_archive_dir(days_limit=7,path=archive_dir)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('clean archive directory')
    logger.write_log('-' * 40)
    try:
        path =  server_config.get_dir_for_current_host(path, is_calc_path)
        ctime = lambda f: os.stat(os.path.join(path, f)).st_ctime
        total_dir_list = list(sorted(os.listdir(path), key=ctime))

        del_list = []

        for l_dir in total_dir_list:
            if (l_dir.isdigit()):
                if datetime.strptime(l_dir, '%Y%m%d%H%M%S') < (datetime.utcnow() - timedelta(days=days_limit)):
                    del_list.append(l_dir)
        if del_list:
            if del_list == total_dir_list:
                del_list.pop()
        for del_dir in del_list:
            cmd = "RMDIR " + os.path.join(path, del_dir) + " /s /q "
            logger.write_log(cmd)
            os.system(cmd)

    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def capture_trace():
    """
    **Objective**

        the function returns the full stack of the error

    :return: full stack of the error


    example::

        except Exception,err:
            logger.write_dbg(utilities.capture_trace())
            raise

    """
    exc_type, exc_value, exc_traceback = sys.exc_info()
    trace_tuple = traceback.format_exception(exc_type, exc_value,
                                             exc_traceback)
    return '\n'.join(trace_tuple)


def move_forkingfile_data(base_directory, job, is_calc_path= True):
    """
    **Objective**

        It is used to move all the info of forking.log to batch_job.log file
        and forking.dbg to batch_job.dbg file

    :param base_directory: base directory path
    :param job: name of the job
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("job_name", "StandardDataFeed-EDMV1")
        ENV.define("base_directory", "D:\\batch\\"+job_name+"\\")

        utilities.move_forkingfile_data(base_directory=base_directory,job=job_name)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Move forking files data to job log/dbg files')
    logger.write_log('-' * 40)
    try:
        base_directory =  server_config.get_dir_for_current_host(base_directory, is_calc_path)
        f_log_file = os.path.join(base_directory, 'forking.log')
        f_dbg_file = os.path.join(base_directory, 'forking.dbg')

        if os.path.isfile(f_log_file):
            with open(f_log_file, 'r') as forking_log_file:
                info = forking_log_file.read()
                with open(os.path.join(base_directory, job + '.log'), 'a') as job_log_file:
                    job_log_file.writelines(info)
            os.remove(f_log_file)
        if os.path.isfile(os.path.join(f_dbg_file)):
            with open(f_dbg_file, 'r') as forking_dbg_file:
                info = forking_dbg_file.read()
                with open(os.path.join(base_directory, job + '.dbg'), 'w') as job_dbg_file:
                    job_dbg_file.writelines(info)
            os.remove(f_dbg_file)
            raise RuntimeError

    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def consolidate_log_dbg_files(base_directory, job, is_calc_path = True):
    """
    **Objective**

        It is used to move all the info of *.log to batch_job.log file
        and *.dbg to batch_job.dbg file

    :param base_directory: base directory path
    :param job: name of the job
    :return: It doesn't return value however, if the function fails,
            it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("job_name", "StandardDataFeed-EDMV1")
        ENV.define("base_directory", "D:\\batch\\"+job_name+"\\")

        utilities.consolidate_log_dbg_files(base_directory, job)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Move all files data to job log/dbg files')
    logger.write_log('-' * 40)
    try:
        base_directory =  server_config.get_dir_for_current_host(base_directory, is_calc_path)
        if os.path.isfile(os.path.join(base_directory,'GenericFeedCode.log')):
            log_file = os.path.join(base_directory,'GenericFeedCode.log')
            dbg_file = os.path.join(base_directory,'GenericFeedCode.dbg')
        else:
            log_file = os.path.join(base_directory, job + '.log')
            dbg_file = os.path.join(base_directory, job + '.dbg')
        log_files = glob.glob(base_directory + '*.log')
        dbg_files = glob.glob(base_directory + '*.dbg')

        if log_files:
            for lg_file in log_files:
                lg_file = os.path.join(base_directory, lg_file)
                if lg_file != log_file:
                    with open(lg_file, 'r') as process_log_file:
                        info = process_log_file.read()
                        with open(os.path.join(log_file), 'a') as job_log_file:
                            job_log_file.writelines(info)
                    os.remove(lg_file)
        if dbg_files:
            for dg_file in dbg_files:
                if dg_file != dbg_file:
                    dg_file = os.path.join(base_directory, dg_file)
                    with open(dg_file, 'r') as process_dbg_file:
                        info = process_dbg_file.read()
                        with open(os.path.join(dbg_file), 'a') as job_dbg_file:
                            job_dbg_file.writelines(info)
                    os.remove(dg_file)
                    raise RuntimeError
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def create_dependency_file(dependency_dir, job_name, is_calc_path = True):
    """
    **Objective**

        It creates the dependency file with timestamp init

    :param dependency_dir: dependency_dir path
    :param job_name: job name
    :return: It doesn't return value however, if the function fails,
                it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("dependency_dir", "D:\\dependency\\")
        ENV.define("job_name", "StandardDataFeed-EDMV1")

        utilities.create_dependency_file(dependency_dir, job_name)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Create dependency (job complete) file for dependent job')
    logger.write_log('-' * 40)
    try:
        dependency_dir =  server_config.get_dir_for_current_host(dependency_dir, is_calc_path)
        dep_file = open(os.path.join(dependency_dir, job_name + '.dep'), 'w')
        dep_file.write(datetime.now().strftime("%Y%m%d%H%M%S"))
        dep_file.close()
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def check_dependency(dependency_dir, prerequisite_job_name, max_wait_time_min=120, last_runtime_limit_min=120, is_calc_path = True):
    """
    **Objective**

        It will check whether the prerequisite job completed by checking the presence of
        prerequisite_job_name.dep file in  dependency_dir. if it completed, what was the last success run.

    :param max_wait_time_min: takes the value in minutes
    :param dependency_dir: dependency directory
    :param prerequisite_job_name: name of the job that needs to be check
    :param last_runtime_limit_min: prerequisite job should have been run with in previous success run time
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("dependency_dir", "D:\\dependency\\")
        ENV.define("prerequisite_job_name", "StandardDataFeed-EDMV1")

        utilities.check_dependency(dependency_dir, prerequisite_job_name, max_wait_time_min=120, last_runtime_limit_min=120)
    """

    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Check dependency file for the last run of the prerequisite job {}'.format(prerequisite_job_name))
    logger.write_log('-' * 40)
    try:
        dependency_dir =  server_config.get_dir_for_current_host(dependency_dir, is_calc_path)
        if not os.path.isdir(dependency_dir):
            er_msg = "dependency_dir doesn't exists {}".format(dependency_dir)
            raise IOError(er_msg)
        if not prerequisite_job_name:
            raise IOError("prerequisite_job_name is empty")

        max_wait_time_min *= 60  # converting minutes to seconds

        # convert hours (max_wait_time_min) to seconds
        # max_wait_time_min = max_wait_time_min * 3600
        current_wait = 0
        prerequisite_file = os.path.join(dependency_dir, prerequisite_job_name + '.dep')
        # print(prerequisite_file)
        exit_parameter = 0
        while max_wait_time_min > current_wait:
            if not os.path.isfile(prerequisite_file):
                # wait for 30 seconds and check again
                time.sleep(30)
                current_wait += 30
                exit_parameter = 1
            else:
                dep_file = open(prerequisite_file, 'r')
                timestamp = dep_file.readlines()[:1]
                if datetime.strptime(timestamp[0], '%Y%m%d%H%M%S') > (
                            datetime.now() - timedelta(minutes=last_runtime_limit_min)):
                    exit_parameter = 2
                    break
                else:
                    time.sleep(30)
                    current_wait += 30
                    exit_parameter = 3
        if exit_parameter == 1:
            er_msg = 'The dependency file doesn''t exist {}'.format(prerequisite_file)
            raise IOError(er_msg)
        elif exit_parameter == 2:
            logger.write_log("{} dependency job ran fine".format(prerequisite_job_name))
        elif exit_parameter == 3:
            er_msg = "The job didn't run in last {0} minutes, waiting for the {1} to finish".format(
                last_runtime_limit_min, prerequisite_job_name)
            raise IOError(er_msg)
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def remove_duplicate_lines(file_path, is_calc_path = True):
    """
    **Objective**

        The function is used to remove the duplicate lines from the files, it cane be used in deef feed before
        comparing the files. It can also be used after producing the feed files.

    :param file_path: file path
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        ENV.define("file_path", "D:\\out\\securities.txt")

        utilities.remove_duplicate_lines(file_path)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('remove duplicate line from the file to improve the efficiency')
    logger.write_log('-' * 40)
    try:
        file_path =  server_config.get_dir_for_current_host(file_path, is_calc_path)
        if os.path.isfile(file_path):
            lines = open(file_path, 'r').readlines()
            header = lines.pop(0)
            lines_set = set(lines)
            open(file_path, 'w').writelines(header)
            open(file_path, 'a').writelines(lines_set)
        else:
            er_msg = 'File doesn''t exist: {}'.format(file_path)
            raise IOError(er_msg)
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def consolidate_deef_split_files(files, output_dir, is_calc_path = True,encoding=None):
    """
    **Objective**

        Deef produces 10 output split files whenever the split option is set to YES for the given output file
        It consolidates those files to one file.

    :param files: pass the name of the files as list that you would like to consolidate
    :param output_dir: pass the path of the output directory where the split files are located
            and you want to create a single file
    :return: It doesn't return value however, if the function fails, it will log the error message to the Batch_job.dbg file


    example::

        # this will consolidate insert_secmas_0.dat, insert_secmas_1.dat insert_secmas_2.dat... to insert_secmas.dat

        files = ['insert_secmas.dat','delete_secmas.dat']
        output_dir = "\\\\lionbatchstga02\\d$\\Out\\CompanyLookupService-Intraday"

        utilities.consolidate_deef_files(files, output_dir)
    """
    logger = lib_log.Logger()
    logger.write_log('-' * 40)
    logger.write_log('Consolidate deef split files')
    logger.write_log('-' * 40)
    try:
        output_dir =  server_config.get_dir_for_current_host(output_dir, is_calc_path)
        for other_file in files:
            header=0
            for i in range(0,10):
                splite_file=os.path.join(output_dir,other_file.split('.')[0]+'_'+str(i)+'.'+other_file.split('.')[1])
                if os.path.isfile(splite_file):
                    if header==0:
                        with open(splite_file,mode='r',encoding=encoding) as open_file_header:
                            with open(os.path.join(output_dir, other_file),mode='w',encoding=encoding) as output_header:
                                output_header.writelines(open_file_header.readlines()[0])
                                header=1
                    with open(splite_file,mode='r',encoding=encoding) as open_file:
                        with open(os.path.join(output_dir, other_file),mode='a',encoding=encoding) as output_file:
                            output_file.writelines(open_file.readlines()[1:])
                    os.remove(splite_file)
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def decrypt_pw(pw, crypt_flag='default'):
    """
    **Objective**
                    Decrypt the password
    :param pw: provide the encrypted password
    :return: decrypted password


    example::

        decrypted_pw = decrypt_pw("crypted:XYZ-XYZ-XYZ")

    """
    logger = lib_log.Logger()
    try:
        if crypt_flag is None:
            return Cipher().decrypt(pw)
        else:
            global crypt
            return Cipher(crypt).decrypt(pw)

    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def encrypt_pw(pw):
    """
    **Objective**
                    Encrypt the password
    :param pw: provide the non-crypted password
    :return: encrypted password


    example::

        encrypted_pw = encrypt_pw("XYZ-XYZ-XYZ")

    """
    logger = lib_log.Logger()
    try:
        global crypt
        return Cipher(crypt).encrypt(pw)
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise

def run_ssis(package, config, version= '2008', retry_attempts=1, is_calc_path = True,filesize_change_cutoff=15,turn_off_check_date=None):
    """
    **Objective**
        This function runs a SSIS package.
    :param package: pass the path of the SSIS package (.dtsx) file or just the file name if its located in batch directory.
    :param config: pass the path of the SSIS package config (.dtsConfig) file or just the file name if its located in batch directory.
    :param filesize_change_cutoff: give cut off for file size check, by default is 15.
    :param turn_off_check_date: pass this parameter with 'yyyymmdd' format of date to skip fie size check on a particular day, the file size check resumes next day
    example::
        utilities.run_ssis('test.dtsx', 'test.dtsConfig')
        All feeds producing an output file in out directory have filesize_check implemented to it by default with cut off of 15 
        Create threshold.fsc file as given in filesize_check function to give the details of exceptional files where cutoff sensitivity should be increased or decreased
        utilities.run_ssis('test.dtsx', 'test.dtsConfig',filesize_change_cutoff=15,turn_off_check_date=None)
        
    """

    logger = lib_log.Logger()
    package_dir=os.path.abspath(os.path.curdir).lower()+'\\'
    job_out_directory=package_dir.replace('batch','out')
    if 'datagroup1' in job_out_directory.lower():
        job_out_directory=job_out_directory.replace('datagroup1','datagroup2')
    logger.write_log(job_out_directory)
    outgoing_job=False
    if(os.path.exists(job_out_directory)):
        outgoing_job=True
    try:
        package =  server_config.get_dir_for_current_host(package, is_calc_path)
        config =  server_config.get_dir_for_current_host(config, is_calc_path)
        logger.write_log('Begin: run_ssis')
        if not package.lower().endswith(".dtsx"):
            er_msg = "dtsx expected incorrect package file {}".format(package)
            raise IOError(er_msg)
        if not config.lower().endswith(".dtsconfig"):
            er_msg = "dtsConfig expected incorrect package config file {}".format(config)
            raise IOError(er_msg)
        if package == os.path.basename(package):
            package = os.path.join(os.path.curdir, package)
        if config == os.path.basename(config):
            config = os.path.join(os.path.curdir, config)
        if not os.path.isfile(package):
            er_msg = "SSIS package not found {}".format(package)
            raise IOError(er_msg)
        if not os.path.isfile(config):
            er_msg = "SSIS package config not found {}".format(config)
            raise IOError(er_msg)
        if os.path.exists("ExecPackage.dbg"):
            os.remove("ExecPackage.dbg")
        if os.path.exists("ExecPackage.log"):
            os.remove("ExecPackage.log")
        exe_path = r"C:\FeedLibraries\ExecPackage\ExecPackage.exe"
        cmd = exe_path + " PackagePath=" +package + " ConfigPath=" + config 
        logger.write_log('Running command: {}'.format(cmd))
        retry=1
        retry_flag = True
        while retry_flag:
            try:
                logger.write_log("try:" + str(retry))
                return_value = call(cmd=cmd, stop=True)
                return_code = return_value[0]
                out_data = return_value[1]
                err_data = return_value[2]
                if return_code != 0 or err_data != '' or 'ERROR' in out_data.upper():
                    if err_data != '':
                        raise Exception(err_data)
                    else:
                        raise Exception(out_data)
                retry_flag = False
                if os.path.exists("ExecPackage.dbg"):
                    os.remove("ExecPackage.dbg")
            except:
                    if retry < retry_attempts:
                        retry = retry + 1
                    else:
                        retry_flag = False
                        raise
        consolidate_log_dbg_files(os.getcwd()+"\\", os.path.basename(os.getcwd()))
        logger.write_log('End: run_ssis')
        if(outgoing_job):
            logger.write_log('Begin filesize_check')
            filesize_check(package_dir, job_out_directory, filesize_change_cutoff = int(filesize_change_cutoff), turn_off_check_date = turn_off_check_date)   
            logger.write_log('End filesize_check')
    except Exception:
        consolidate_log_dbg_files(os.getcwd()+"\\", os.path.basename(os.getcwd()))
        logger.write_dbg('{}'.format(capture_trace()))
        raise


def run_dts(package,retry_attempts=1, config = None, is_calc_path = True,filesize_change_cutoff=15,turn_off_check_date=None):
    """
    **Objective**
        This function runs a DTS package.
    :param package: pass the path of the DTS package (.dts) file or just the file name if its located in batch directory.
    :param retry_attempts: Number of executions allowed to run. If retry_attempts is set to 2 then package will be rerun once in case of failure. 
                          retry_attempts = 1 which means package will run just once and package will not be triggered upon failure.
    :param filesize_change_cutoff: Give the percentage cut off for file size change,default=15
    :param turn_off_check_date : give date in 'yyyymmdd' format to skip file size check for a particular date, file size check resumes the next day
    example::
        utilities.run_dts('test.dts')
        If a different cut off to be given to files as cut off other than the default 15 percent change
        utilities.run_dts('test.dts',filesize_change_cutoff=30)
        If filesize_check should be skipped on a certain day
        utilities.run_dts('test.dts',filesize_change_cutoff=30,turn_off_check_date=20180514)
        All feeds producing an output file in out directory have filesize_check implemented to it by default with cut off of 15 
        Create threshold.fsc file as given in filesize_check function to give the details of exceptional files where cutoff sensitivity should be increased or decreased
    """
    logger = lib_log.Logger()
    retry=1
    retry_flag = True
    try:
        logger.write_log('Begin: run_dts')
        package =  server_config.get_dir_for_current_host(package, is_calc_path)
        if not package.lower().endswith(".dts"):
            er_msg = "dts expected incorrect package file {}".format(package)
            raise IOError(er_msg)
        if package == os.path.basename(package):
            package = os.path.join(os.path.curdir, package)
        package_dir=os.path.abspath(os.path.curdir).lower()+'\\'
        job_out_directory=package_dir.replace("batch","out")
        if 'datagroup1' in job_out_directory.lower():
            job_out_directory=job_out_directory.replace('datagroup1','datagroup2')
        outgoing_job=False
        if(os.path.exists(job_out_directory)):
            outgoing_job=True

        if not os.path.isfile(package):
            er_msg = "DTS package not found {}".format(package)
            raise IOError(er_msg)
        if os.path.exists("ExecPackage.dbg"):
            os.remove("ExecPackage.dbg")
        if os.path.exists("ExecPackage.log"):
            os.remove("ExecPackage.log")
        exe_path = r"C:\FeedLibraries\ExecPackage\ExecPackage.exe"
        cmd = exe_path + " PackagePath=" +package + (" ConfigPath=" + config if config is not None else "" )
        logger.write_log('Running command: {}'.format(cmd))
        retry=1
        retry_flag = True
        while retry_flag:
            try:
                logger.write_log("try:" + str(retry))
                return_value = call(cmd=cmd, stop=True)
                return_code = return_value[0]
                out_data = return_value[1]
                err_data = return_value[2]
                if return_code != 0 or err_data != '' or 'ERROR' in out_data.upper():
                    if err_data != '':
                        raise Exception(err_data)
                    else:
                        raise Exception(out_data)
                retry_flag = False
                if os.path.exists("ExecPackage.dbg"):
                    os.remove("ExecPackage.dbg")
            except:
                    if retry < retry_attempts:
                        retry = retry + 1
                    else:
                        retry_flag = False
                        raise
        consolidate_log_dbg_files(os.getcwd()+"\\", os.path.basename(os.getcwd()))
        logger.write_log('End: run_dts')
        if(outgoing_job):
            logger.write_log('Begin filesize_check')
            filesize_check(package_dir, job_out_directory, filesize_change_cutoff = int(filesize_change_cutoff), turn_off_check_date = turn_off_check_date)
            logger.write_log('End filesize_check')
    except Exception:
        consolidate_log_dbg_files(os.getcwd()+"\\", os.path.basename(os.getcwd()))
        logger.write_dbg('{}'.format(capture_trace()))
        raise

def filesize_check(base_directory, output_dir, filesize_change_cutoff = 15, turn_off_check_date = None):
    """
    :param base_directory: provide the base directory path
    :param output_dir: provide the output directory path
    :param filesize_change_cutoff: default is 15, provide the cutoff otherwise
    :param turn_off_check_date: You can provide the date ('yyyymmdd') for the day you want to turn off file size check,
                                It will resume the file size check on the next day.
    :example:
          
          utilities.filesize_check(base_directory,output_dir,filesize_change_cutoff=20) 
          
          If in case we need to skip filesize_check for a particular day we pass the function with date as given below, filesize_check operation resumes from the next day
          utilities.filesize_check(base_directory,output_dir,filesize_change_cutoff=20,turn_off_check_date="20180517")
          
          
          Specific files in the feed example (abc.txt,def.txt) which have cut off different from the bulk cut off can be specified in the threshold.fsc file in the following manner
          
          -------------------
          threshold.fsc file format :
          
          filename|threshold
          abc.txt|50
          def.txt|30
          
          This means that out of all the files, abc.txt can have file change upto 50 percent and def.txt cam have file change upto 30 percent. Remaining all files will have cut off as passed through the function or by default of 15 percent if no value is passed.
    """
    logger = lib_log.Logger()
    try:
        filesize_file = os.path.join(base_directory,"filesize_hist.dat")
        cur_date = datetime.now()
        
        
        df_info = pd.DataFrame(columns=["df_name", "df_size", "date_modified","date_of_check"])
        

        # get the list of the files from output dir
        for fl in os.listdir(output_dir):
            filesize=os.path.getsize(os.path.join(output_dir, fl))
            filesize= 1 if filesize==0 else filesize
            date_modified=datetime.fromtimestamp(os.path.getctime(os.path.join(output_dir,fl))).strftime('%Y-%m-%d %H:%M:%S')
            df_info.loc[len(df_info)] = [fl, filesize, date_modified,cur_date]
        # in case we have multiple *_etl files running in parallel
        # we need to make sure the if the one process is writing the files
        # other process doesn't fail with the file access issue

        file_in_use = filesize_file + '.in_use'
        total_wait_time = 0
        while (os.path.isfile(file_in_use)):
            if total_wait_time>300:
                raise RuntimeError("{0} is hung! please rename the file to {1}".format(file_in_use,filesize_file))
            total_wait_time = total_wait_time + 5
            time.sleep(5)

        # check if the filesize_hist.dat exists
        if (os.path.isfile(filesize_file)):
            os.rename(filesize_file, file_in_use)
            file_size_df = pd.read_csv(file_in_use, sep = "|", quoting=csv.QUOTE_ALL, encoding="utf-8")
            process_df = file_size_df[file_size_df["df_name"].isin(df_info["df_name"])]
            other_files=file_size_df[-file_size_df["df_name"].isin(df_info["df_name"])]

            process_df = pd.concat([process_df,df_info],axis=0,ignore_index=True)
            process_df[["df_size"]] = process_df[["df_size"]].astype("int64")
            process_df[["date_modified"]] = process_df[["date_modified"]].astype("datetime64[ns]")
            process_df[["date_of_check"]] = process_df[["date_of_check"]].astype("datetime64[ns]")
            process_df[["df_name"]] = process_df[["df_name"]].astype("str")
            
            #dropping duplicates if file_size_check is being run multiple times in a single feed run
            process_df=process_df.drop_duplicates(subset=['df_name','date_modified'], keep='last')
            
            # get the percentage change among the previous and todays files
            process_df["pct_ch"] = abs(process_df.sort_values("date_of_check").groupby(["df_name"]).df_size.pct_change())*100
            #logger.write_log(str(process_df["pct_ch"]))
            process_df.sort_values(["date_of_check", "df_name"], inplace=True, ascending=[False, True])
            
            #specific files in the feed having a different sensitivity to file_change compared to other files should be mentioned in the file threshold.fsc
            threshold_file=os.path.join(base_directory,"threshold.fsc")
            #compare the previous file size
            if not os.path.isfile(threshold_file): 
                logger.write_log("No threshold file is present. Proceeding with threshold value of {}%.".format(filesize_change_cutoff))
                fail_df = process_df[(process_df["date_of_check"].isin([cur_date])) & (process_df["pct_ch"]>= filesize_change_cutoff)]
                if filesize_change_cutoff>=99999:
                    fail_df=fail_df[0:0]
                    logger.write_log("Skipping size check as threshold mentioned is more than 99999 at {}%".format(filesize_change_cutoff))
            else:
                #Checking for files with exceptions and doing size check according to given cut-off for those specific files
                threshold_df = pd.read_csv(threshold_file, sep = "|", quoting=csv.QUOTE_ALL, encoding="utf-8",header=None,skiprows=1,names=["file_name","Threshold"])
                defaults=process_df[-process_df['df_name'].isin(threshold_df['file_name']) & process_df["date_of_check"].isin([cur_date])]
                exceptions=process_df[process_df['df_name'].isin(threshold_df['file_name']) & process_df["date_of_check"].isin([cur_date])]
                fail_df = defaults[(defaults["date_of_check"].isin([cur_date])) & (defaults["pct_ch"]>= filesize_change_cutoff)]
                if filesize_change_cutoff>=99999:
                    fail_df = fail_df[0:0]
                fail_df_exceptions=fail_df[0:0]
                for index,row in exceptions.iterrows():
                    if(int(threshold_df.loc[threshold_df['file_name']==row["df_name"]]['Threshold'])>=99999):
                        pass
                    else:
                        if (row["date_of_check"]==cur_date) & (row["pct_ch"]>=float(threshold_df.loc[threshold_df['file_name']==row["df_name"]]['Threshold'])):
                            fail_df_exceptions.loc[len(fail_df_exceptions)]=row
                
                fail_df=fail_df.append([fail_df_exceptions],ignore_index=True)
            
            #All details of files crossing the cut off are filtered out.
            if len(fail_df)>0:
                df_buffer = io.StringIO()
                fail_df.to_csv(df_buffer, sep="|", header=True)
                if str(turn_off_check_date) == str(datetime.utcnow().strftime('%Y%m%d')):
                    logger.write_log("File size check skipped for date : " + str(turn_off_check_date))
                else:
                    os.rename(file_in_use, filesize_file)
                    raise RuntimeError("File size check failure: \n{}".format(fail_df))
            #Sync other files in output directory to filesize_hist.dat (for multiple DTSX packages)
            process_df=process_df.append(other_files,ignore_index=True)
            process_df["rank"]= process_df.groupby(["df_name"])["date_of_check"].rank(ascending=False)
            # Saving the history of last 30 runs per file
            create_df = process_df[process_df["rank"] <= 30]
            create_df.to_csv(file_in_use, sep="|", quoting=csv.QUOTE_ALL, encoding="utf-8",
                                        index=False, columns = ["df_name","df_size","date_modified","date_of_check"])
            os.rename(file_in_use, filesize_file)
        # if its a first run, create the filesize_hist.dat
        else:
            df_info.to_csv(filesize_file,sep = "|", quoting=csv.QUOTE_ALL, encoding="utf-8",index=False)
            
    except:
        logger.write_dbg("{}".format(capture_trace()))
        raise


def run_exe(cmd, stop = True,retry_attempts=1, is_calc_path = True):
    """
    **Objective**

        This function runs any executable.

    :param cmd: pass the executable full path with all necessary command line arguments
    :param retry_attempts: Number of executions allowed to run. If retry_attempts is set to 2 then package will be rerun once in case of failure. 
                          retry_attempts = 1 which means package will run just once and package will not be triggered upon failure.
    example::
        utilities.run_exe('C:\\CCS_Jobs\\FeedMonitor.bat', True)
        utilities.run_exe('C:\\CCS_Jobs\\FeedMonitor.exe', True)
        #if in case network failures are possible for this executable & can be allowed to run for a couple of times then setting retry_attempts = 3 will allow executable to rerun twice in case of failure.
        utilities.run_exe('C:\\CCS_Jobs\\FeedMonitor.exe', True, retry_attempts = 3)
    """
    logger = lib_log.Logger()
    retry=1
    retry_flag = True
    try:
        cmd_line = cmd.split()
        exe = cmd_line[0]
        cmd.replace(exe, server_config.get_dir_for_current_host(exe, is_calc_path))
        
        while retry_flag:
            try:
                logger.write_log("try:" + str(retry))
                logger.write_log('Begin: run_exe')
                return_value = call(cmd=cmd, stop=stop)
                return_code = return_value[0]
                out_data = return_value[1]
                err_data = return_value[2]
                if return_code != 0 or err_data != '' or 'ERROR' in out_data.upper():
                    if err_data != '':
                        raise Exception(err_data)
                    else:
                        raise Exception(out_data)
                retry_flag = False
            except:
                if retry < retry_attempts:
                    retry = retry + 1
                else:
                    retry_flag = False
                    raise
        logger.write_log('End: run_exe')
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise

def correct_host_path_in_ftp_action_file(file_path, is_calc_path = True):
    """
    **Objective**

        This function is to update the put/get file paths with current host path. This is for internal use within utilities function

    :param file_path: pass the put/get file full path
    """
    try:
        logger = lib_log.Logger()
        new_file_path = None
        with open(file_path, 'r') as content_file:
            content = content_file.read()
        modified_content = content
        extension = os.path.splitext(file_path)[1]
        file_list = read_ftp_action_file(file_path)
        print('\n'.join(str(p) for p in file_list) )
        if len(file_list) == 0:
            raise Exception("No files to upload/download")
        for file in file_list:
            if 'PUTFTP' in content:
                source = os.path.dirname(file[0])
            else:
                source = os.path.dirname(file[1])
            modified_source = server_config.get_dir_for_current_host(source, is_calc_path)
            if source != modified_source:
                modified_content= modified_content.replace(source, modified_source)

        if content != modified_content:   
            new_file_path = os.path.join(os.path.dirname(file_path), os.path.splitext(os.path.basename(file_path))[0] +'_temp'+extension)      
            with open(new_file_path, "w") as write_file:
                write_file.write(modified_content)
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise
    return new_file_path

def redirect_ftp_netclient_config(file_path):
    """
    **Objective**
        This function is to update the put/get file paths with current host path. This is for internal use within utilities function
    :param file_path: pass the netclient config file full path
    """
    try:
        logger = lib_log.Logger()
        new_file_path = None
        redirection_set = False
        if not server_config.is_primary_host_server():
            with open(file_path) as data_file:
                content = data_file.read()
                modified_content = content
            with open(file_path) as data_file:            
                data = json.load(data_file)
                servers = data["put"]["servers"]
                for server in servers:
                    server_name = server["server_name"]
                    redirected_server = server_config.get_ftp_server_for_current_host(server_name)
                    if redirected_server:
                        modified_content = modified_content.replace(server_name, redirected_server)
                        redirection_set = True
            if redirection_set:
                new_file_path = os.path.join(os.path.dirname(file_path), os.path.splitext(os.path.basename(file_path))[0] +'_temp.conf')
                with open(new_file_path, "w") as write_file:
                    write_file.write(modified_content) 
    except Exception:
        logger.write_dbg('{}'.format(capture_trace()))
        raise
    return new_file_path

def clean_dir_by_path(file_path, format, is_calc_path = True):
    """
    **Objective**

        This function is to delete the files in the provided file_path that matches with format.

    :param file_path: pass the folder path
    :param file_path: pass the filename format that are to be deleted.

    example::
        utilities.clean_dir_by_path('Out\\EntityFull\\', '*.*') #deletes all files in out\EntityFull
        utilities.clean_dir_by_path('Zip\\EntityFull\\', '*.zip')#deletes all zip files in Zip\EntityFull
    """
    if is_calc_path:
        file_path = server_config.get_dir_for_current_host(file_path, is_calc_path)
    call("del /S /Q " + file_path + format)