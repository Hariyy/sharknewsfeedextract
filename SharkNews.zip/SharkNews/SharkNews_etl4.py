#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function
import pandas as pd
from lib_util import pyetl
from lib_util import lib_log
from collections import OrderedDict
from lib_util import get_filename
from socket import gethostname
from lib_util import utilities
from lib_util import lib_log
# import re
# import codecs
from csv import QUOTE_ALL,QUOTE_MINIMAL,QUOTE_NONE,QUOTE_NONNUMERIC
import os,re
import codecs
# import numpy as np
from datetime import date, timedelta, datetime
import gc
# import math
# from decimal import Decimal, ROUND_HALF_UP, ROUND_FLOOR, ROUND_CEILING


logger = lib_log.Logger()


class LoadFile(pyetl.FilePyEtl):
    def __init__(self, base_directory, input_dir, output_dir):
        super(LoadFile, self).__init__()
        self.empty_df_flag = True
        self.base_directory = base_directory
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.files_data = OrderedDict([
            ('company', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "company.txt"),
                "sep": "|",
                "usecols": ['company_code','company_name','job_status','iconum','jurisdiction_incorporated'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),


            ('fight', {

                "path_or_buf": os.path.join(self.input_dir,
                                            "fight.txt"),
                "sep": "|",
                "usecols": ['company_code','id','announce_date','campaign_type_cd','proxy_fight_flg','title','marketcap','fight_synopsis'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('company_identifier', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "company_identifier.txt"),
                "sep": "|",
                "usecols": ['company_code','code','identifier'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('company_sic', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "company_sic.txt"),
                "sep": "|",
                "usecols": ['company_code','sic_code','seq'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('SR_LookupFightCampaignType', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "SR_LookupFightCampaignType.txt"),
                "sep": "|",
                "usecols": ['Code','Description'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('SR_LookupFilingType', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "SR_LookupFilingType.txt"),
                "sep": "|",
                "usecols": ['Code','Description'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('company_ticker', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "company_ticker.txt"),
                "sep": "|",
                "usecols": ['company_code','primary_listing','stock_exchange','ticker'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('filermst', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "filermst.txt"),
                "sep": "|",
                "usecols": ['iconum','sect_code','ind_code'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('sector', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "sector.txt"),
                "sep": "|",
                "usecols": ['sect_code','sector'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('industries', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "industries.txt"),
                "sep": "|",
                "usecols": ['ind_code','industry'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('fight_source', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "fight_source.txt"),
                "sep": "|",
                "usecols": ['dissident_filing_flg','seat_granted_to_dissident_flg', 'contentious_13d_item_flg','publish_flg', 'unsolicited_hostile_flg', 'description','special_exhibit_cd', 'source_type_cd','fight_id','filing_date','proxy_fight_formal_notice_flg'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('fight_participant', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "fight_participant.txt"),
                "sep": "|",
                "usecols": ['fight_id','participant_cd'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),

            ('proponent_lookup', {
                "path_or_buf": os.path.join(self.input_dir,
                                            "proponent_lookup.txt"),
                "sep": "|",
                "usecols": ['core_activist_flg','iconum','id'],
                "encoding": 'latin-1',
                "quoting": QUOTE_ALL,
                #"na_values": ["NaN", "", "N/A", "NULL", "n/a", "nan", "null"]
            }),
             ])

        # self.results = OrderedDict([

        #     ('temp_shark_news', {
        #         "path_or_buf":os.path.join(self.output_dir,
        #                                    "temp_shark_news.txt"),
        #         "sep":"|",
        #         "encoding": 'latin-1',
        #         "quoting":QUOTE_ALL,
        #         "index":False,
        #     }),
                                                                                 
        #  ])

         
    def transform(self):
        #merge all the left joines for one dataframe
        company = self.company.copy()
        fight = self.fight.copy()
        fight_source = self.fight_source.copy()
        SR_LookupFightCampaignType = self.SR_LookupFightCampaignType.copy()
        SR_LookupFilingType = self.SR_LookupFilingType.copy()
        company_identifier = self.company_identifier.copy()
        filermst = self.filermst.copy()
        sector = self.sector.copy()
        industries = self.industries.copy()
        company_sic = self.company_sic.copy()
        company_ticker = self.company_ticker.copy()
        fight_participant = self.fight_participant.copy()
        proponent_lookup = self.proponent_lookup.copy()

        #Strip all the LTRIM,RTRIM
        trim_values = lambda x: str(x).strip()
        company.job_status = company.job_status.apply(trim_values)
        fight.campaign_type_cd = fight.campaign_type_cd.apply(trim_values)
        fight_source.source_type_cd = fight_source.source_type_cd.apply(trim_values)
        fight_source.source_type_cd = fight_source.special_exhibit_cd.apply(trim_values)
        SR_LookupFightCampaignType.Code = SR_LookupFightCampaignType.Code.apply(trim_values)
        SR_LookupFilingType.code = SR_LookupFilingType.Code.apply(trim_values)
        company_identifier.identifier = company_identifier.identifier.apply(trim_values)
        sector.sector = sector.sector.apply(trim_values)
        industries.industry = industries.industry.apply(trim_values)

        #res4 will create 4th df(four) = 13D/A
        res4 = company.merge(fight, how ='left',on=["company_code"]) 
        res4 = res4.merge(fight_source, how ='left',left_on=["id"], right_on=["fight_id"]) 
        res4= res4.merge(SR_LookupFightCampaignType, how ='left', left_on=["campaign_type_cd"], right_on=["Code"])
        res4= res4.merge(SR_LookupFilingType, how ='left', left_on=["source_type_cd"], right_on=["Code"])
        company_identifier2 = company_identifier[company_identifier.identifier == 'CUSIP']
        res4= res4.merge(company_identifier2,how ='left', on=["company_code"])
        res4= res4.merge(filermst, how ='left', on=["iconum"])
        res4= res4.merge(sector, how ='left', on=["sect_code"])
        res4= res4.merge(industries, how ='left', on=["ind_code"])
        company_sic2 = company_sic[company_sic.seq==1]
        res4= res4.merge(company_sic2,how ='left', on=["company_code"])
        company_ticker1 = company_ticker[company_ticker.primary_listing==-1]
        res4= res4.merge(company_ticker1, how ='left', on=["company_code"])
        res4= res4.merge(fight_participant, how ='left', left_on=["id"], right_on=["fight_id"])
        res4= res4.merge(proponent_lookup, how ='left', left_on=["participant_cd"], right_on=["id"])
        print(len(res4))
        
        res4.job_status = res4.job_status.fillna('WIP')
        res4 = res4[res4['job_status'].isin(["APR" ,"CHIP"])]  
        res4.campaign_type_cd = res4.campaign_type_cd.fillna('XXX')
        res4 = res4[~res4['campaign_type_cd'].isin(['13DFILER'])] 
        res4 = res4[~res4['announce_date'].isin(res4['filing_date'])]
        res4 = res4[res4.announce_date > '2006-01-01 00:00:00.000']
        res4 = res4[pd.to_datetime(res4.filing_date) >= (datetime.now() - timedelta(days=10))]
       
        res4['fight_id'] = res4.id_x.astype('int')
        res4.drop(['fight_id_x','id_x','fight_id_y'], axis=1, inplace=True)
        date=pd.to_datetime(res4['announce_date']).dt.strftime('%Y%m%d').astype('str')
        fid=res4['fight_id'].astype('str')
        res4['story_id'] = date+fid
        res4['type'] = 'new'

        
        f = lambda x: 1 if x==True else 0
        # res4.unsolicited_hostile_flg = res4.unsolicited_hostile_flg.apply(f)
        # res4.proxy_fight_formal_notice_flg = res4.proxy_fight_formal_notice_flg.apply(f)
        # res4.proxy_fight_flg = res4.proxy_fight_flg.apply(f)
        # res4.publish_flg = res4.publish_flg.apply(f)
        # res4.seat_granted_to_dissident_flg = res4.seat_granted_to_dissident_flg.apply(f)
        res4.dissident_filing_flg = res4.dissident_filing_flg.apply(f)
        #res4.contentious_13d_item_flg = res4.contentious_13d_item_flg.apply(f)

        # headline = case
		# 			when (IsNull(c.dissident_filing_flg,0) in (1, -1) and IsNull(LTRIM(RTRIM(c.source_type_cd)),'XXX') = '13D/A'  
		# 			and LTRIM(RTRIM(c.special_exhibit_cd)) is null) 
		# 				then concat('Update to ' , b.title , ' Activist Campaign - 13D/A Filed')
		# 			end
        
        def headline4(dissident_filing_flg,source_type_cd,special_exhibit_cd,title ):                       
            #dissident_filing_flg = dissident_filing_flg.fillna(0)
            source_type_cd_ = 'XXX' if pd.null(source_type_cd) else source_type_cd
            #source_type_cd = source_type_cd.fillna('XXX')
            #contentious_13d_item_flg = contentious_13d_item_flg.fillna(0)
            if dissident_filing_flg in (1,-1) and source_type_cd == '13D/A' and special_exhibit_cd.isna() :
                return 'Update to '+title+' Activist Campaign - 13D/A Filed'    

        res4['headline']=res4[['dissident_filing_flg','source_type_cd','special_exhibit_cd','title']].apply(lambda x:headline4(x['dissident_filing_flg'] ,\
                        x['source_type_cd'],x['special_exhibit_cd'],x['title']) ,axis=1) 
                                                                                                                                                                                                                                                                      
        res4['headline_rank'] = 1                  
        res4['publication_date']= pd.to_datetime(res4.filing_date)
        x= datetime.now().strftime('%H%M%S')
        res4.loc[res4['filing_date']==pd.datetime.now(),'publication_time']=x
        res4.loc[res4['filing_date']!=pd.datetime.now(),'publication_time']='180000'  
        res4['language'] = 'en'
        res4['cusip'] = res4.code
        res4['factset_id'] = res4['iconum_x'].astype('int')
        res4['event_type'] = '13D/A'
        res4['fds_sector'] = res4['sect_code'].astype('int')
        res4['fds_sector_name'] = res4['sector']
        res4['fds_industry'] = res4['ind_code'].astype('int')
        res4['fds_industry_name'] = res4['industry']
        res4['jurisdiction_incorporated'] = res4['jurisdiction_incorporated'].fillna('United States')
        res4['market_cap'] = res4.marketcap
        res4['sic_code'] = res4['sic_code']#.astype('int')
        res4['campaign_type'] = res4['Description']
        res4['campaign_summary'] = res4['fight_synopsis']
        res4['delivery_timestamp'] = datetime.now().strftime('%Y%m%d%H%M%S')
        res4['company_name'] = res4['company_name']
        res4['company_ticker'] = res4['ticker']
        res4['company_stock_exchange'] = res4['stock_exchange']
        res4['company_parent_name'] = res4['company_name']
        res4['company_parent_ticker'] = res4['ticker']
        res4['company_parent_stock_exchange'] = res4['stock_exchange']
        res4['company_parent_cusip'] = res4['code']
        res4['company_parent_factset_id'] = res4['iconum_x'].astype('int')
        res4['sharkwatch_50_member'] = res4['core_activist_flg'].apply(f)
        res4['proponent_iconum'] = res4['iconum_y']#.astype('int')

        res4.sort_values(by=['fight_id'], inplace=True)
        #res4 = res4.loc[res4['headline'].notnull()]

        res4['headline'] = res4['headline'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res4['fds_sector_name'] = res4['fds_sector_name'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res4['fds_industry_name'] = res4['fds_industry_name'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res4['jurisdiction_incorporated'] = res4['jurisdiction_incorporated'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res4['market_cap'] = res4['market_cap'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res4['campaign_type'] = res4['campaign_type'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res4['latest_development'] = res4['headline'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res4['campaign_summary'] = res4['campaign_summary'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res4['company_name'] = res4['company_name'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')
        res4['company_parent_name'] = res4['company_parent_name'].apply(lambda x: '<![CDATA[' + str(x) + ']]>')

        res4 = res4[['fight_id','story_id','type','headline' ,'publication_date','publication_time','language','cusip','factset_id','event_type'
            ,'fds_sector','fds_sector_name','fds_industry','fds_industry_name','jurisdiction_incorporated','market_cap','sic_code','campaign_type'
            ,'latest_development','campaign_summary','delivery_timestamp','company_name','company_ticker','company_stock_exchange'
            ,'company_parent_name','company_parent_ticker','company_parent_stock_exchange','company_parent_cusip','company_parent_factset_id'
            ,'sharkwatch_50_member','proponent_iconum','headline_rank']]

        res4.to_csv("D:/User/hjanagam/out/SharkNews/df4vscode.csv")
            


        #self.temp_shark_news = res4.copy()
        

