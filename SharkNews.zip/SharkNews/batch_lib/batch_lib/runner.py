import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "batch_lib.pyz"))
from batch_lib.batch_lib import *
if __name__ == '__main__':
    main()
