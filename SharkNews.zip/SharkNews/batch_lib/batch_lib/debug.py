# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

import os
import sys
import zipimport
import subprocess


def main():
    print('Running with Python {}.{}'.format(sys.version_info[0], sys.version_info[1]))
    # Define where to build pyz (in same folder as source folder or in C:\a_appli\...)
    outdir = os.path.dirname(os.path.dirname(__file__))
    #outdir = os.path.dirname(__file__)
    pyz_package = os.path.join(outdir, 'batch_lib.pyz')
    # Delete previous pyz before pyzzing if we pyz in source folder 
    # otherwise each new pyz will include the previous one
    if os.path.exists(pyz_package):
        os.remove(pyz_package)

    # Make sure the working directory is the correct one for pyzzing
    
    prev_wdir = os.getcwd()
    os.chdir("..")
    
    pyzzer = os.path.join(os.path.dirname(sys.executable), 'Scripts', 'pyzzer.pyz')
    subprocess.call(' '.join([sys.executable, pyzzer, 'src\\batch_lib.py', '--outdir', outdir]))

    # Revert working directory
    os.chdir(prev_wdir)

    if not os.path.exists(pyz_package):
        print("Failed to generate '{}'".format(pyz_package))
        return

    importer = zipimport.zipimporter(pyz_package)
    importer.load_module('batch_lib')

    from batch_lib import batch_lib
    batch_lib.main()

if __name__ == '__main__':
    main()