# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Jun 17 2015)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc

###########################################################################
## Class PanelRecoveryBase
###########################################################################

class PanelRecoveryBase ( wx.Panel ):
    
    def __init__( self, parent ):
        wx.Panel.__init__ ( self, parent, id = wx.ID_ANY, pos = wx.DefaultPosition, size = wx.Size( 763,522 ), style = wx.TAB_TRAVERSAL )
        
        sbSizer1 = wx.StaticBoxSizer( wx.StaticBox( self, wx.ID_ANY, u"Job Recovery Creation" ), wx.VERTICAL )
        
        self.m_staticTextScriptPath = wx.StaticText( sbSizer1.GetStaticBox(), wx.ID_ANY, u"d:\\job\\soft\\job.cmd", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticTextScriptPath.Wrap( -1 )
        sbSizer1.Add( self.m_staticTextScriptPath, 0, wx.ALL, 5 )
        
        self.m_staticSectionsToRun = wx.StaticText( sbSizer1.GetStaticBox(), wx.ID_ANY, u"Sections to run again:", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticSectionsToRun.Wrap( -1 )
        sbSizer1.Add( self.m_staticSectionsToRun, 0, wx.ALL, 5 )
        
        bSizer8 = wx.BoxSizer( wx.HORIZONTAL )
        
        m_checkListStepsChoices = []
        self.m_checkListSteps = wx.CheckListBox( sbSizer1.GetStaticBox(), wx.ID_ANY, wx.DefaultPosition, wx.Size( 600,400 ), m_checkListStepsChoices, 0 )
        bSizer8.Add( self.m_checkListSteps, 0, wx.ALL, 5 )
        
        bSizer10 = wx.BoxSizer( wx.VERTICAL )
        
        bSizer11 = wx.BoxSizer( wx.VERTICAL )
        
        self.m_buttonExecute = wx.Button( sbSizer1.GetStaticBox(), wx.ID_ANY, u"Execute", wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer11.Add( self.m_buttonExecute, 0, wx.ALIGN_RIGHT|wx.ALIGN_TOP|wx.ALL, 5 )
        
        self.m_buttonCancel = wx.Button( sbSizer1.GetStaticBox(), wx.ID_ANY, u"Cancel", wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer11.Add( self.m_buttonCancel, 0, wx.ALIGN_RIGHT|wx.ALL, 5 )
        
        
        bSizer10.Add( bSizer11, 1, wx.EXPAND, 5 )
        
        
        bSizer8.Add( bSizer10, 1, wx.EXPAND, 5 )
        
        
        sbSizer1.Add( bSizer8, 1, wx.EXPAND, 5 )
        
        bSizer12 = wx.BoxSizer( wx.HORIZONTAL )
        
        self.m_staticDescription = wx.StaticText( sbSizer1.GetStaticBox(), wx.ID_ANY, u"Description : ", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticDescription.Wrap( -1 )
        bSizer12.Add( self.m_staticDescription, 0, wx.ALL, 5 )
        
        
        sbSizer1.Add( bSizer12, 1, wx.EXPAND, 5 )
        
        
        self.SetSizer( sbSizer1 )
        self.Layout()
    
    def __del__( self ):
        pass
    

