"""
    Command line::

        python batch.py [gui]

    Launch a graphical interface wich is normally able to do everything that is possible on command line and even more.

"""
from __future__ import unicode_literals, absolute_import
from .main import Gui
__all__ = ['Gui']