from __future__ import print_function
try:
    import wx
    from wx.lib.wordwrap import wordwrap
    import wx.lib.anchors as anchors
    import wx.lib.newevent
    import  wx.lib.buttons  as  buttons
except ImportError:
    # create fake module and class
    # To accept file loading
    class wx:
        class Panel:
            pass
        class Frame:
            pass
    print("WARNING: wxPython is not installed. gui cannot works !")
    
from .job_recovery_base import PanelRecoveryBase

import os
import sys

from ...batch_lib import __version__
from ...script import *
from ...execute import get_scripts, manager
from ..graph import Graph

    
class PanelRecovery(PanelRecoveryBase):
    def __init__(self, parent, script_name):
        PanelRecoveryBase.__init__(self, parent)

        self.m_staticTextScriptPath.SetLabelText(script_name)
        # self.m_staticTextScriptPath.Layout()

        # load the module in memory without executing it
        # unload our script from the manager as well as python VM
        manager.clear()
        dirname = os.path.abspath(os.path.dirname(script_name))
        sys.path.insert(0, dirname)
        module, _ = os.path.splitext(os.path.basename(script_name))
        __import__(module)
        sys.path.remove(dirname)

        # event bindings
        self.m_buttonExecute.Bind(wx.EVT_BUTTON, self.OnExecute)
        self.m_buttonCancel.Bind(wx.EVT_BUTTON, self.OnCancel)
        self.m_checkListSteps.Bind(wx.EVT_LISTBOX, self.OnSelect)
        self.m_checkListSteps.Bind(wx.EVT_CHECKLISTBOX, self.OnCheckOrUncheck)

        # raw names of the steps
        self.raw_steps = []

        # makes the graph/lists of steps of the script
        graph = Graph()
        graph.auto_load()

        (init_scripts, scripts, end_scripts) = get_scripts()
        currentIndex = -1
        checkedIndex = []
        for script in init_scripts:
            if script.status == NOT_A_SCRIPT:
                continue
            #python 2 : self.m_checkListSteps.AppendAndEnsureVisible("[init] " + script.name)
            item = self.m_checkListSteps.Append("[init] " + script.name)
            self.m_checkListSteps.EnsureVisible(item)
            self.raw_steps.append(script.name)
            currentIndex += 1
            # default : select init script
            checkedIndex.append(currentIndex)
            

        for script in scripts:
            if script.status == NOT_A_SCRIPT:
                continue
            if script not in init_scripts and script not in end_scripts:
                #python 2 : self.m_checkListSteps.AppendAndEnsureVisible(script.name)
                item = self.m_checkListSteps.Append(script.name)
                self.m_checkListSteps.EnsureVisible(item)
                currentIndex += 1
                self.raw_steps.append(script.name)

        for script in end_scripts:
            if script.status == NOT_A_SCRIPT:
                continue
            # python 2 : self.m_checkListSteps.AppendAndEnsureVisible("[end] " + script.name)
            item = self.m_checkListSteps.Append("[end] " + script.name)
            self.m_checkListSteps.EnsureVisible(item)
            currentIndex += 1
            self.raw_steps.append(script.name)
            # default : select init script
            checkedIndex.append(currentIndex)            
        
        self.m_checkListSteps.SetCheckedItems(checkedIndex)
        self.unload_script_from_python_stack(module)
        self.Layout()
    

    def unload_script_from_python_stack(self, script_name):
        for k in [x for x in sys.modules.keys() if x.startswith("{}.".format(script_name))]:
            del sys.modules[k]
        del sys.modules[script_name]
        del script_name


    def OnExecute(self, evt):
        """
        Executes selected scripts
        """
        # set the selected_scripts_steps of the BasicPanel from the main gui
        selected_steps = self.m_checkListSteps.GetCheckedStrings()
        cleaned_names = []
        # remove forced [init] and [end] from step names
        for step in selected_steps:
            if "[init] " in step or "[end] " in step:
                cleaned_names.append(step.split(' ')[1])
            else:
                cleaned_names.append(step)
        # log to alternate file [DATE]_script.log when using recovery mode
        self.Parent.Parent.log_alternate_file = True
        self.Parent.Parent.selected_scripts_steps = cleaned_names
        # then emulate a click on the button "Execute"
        self.Parent.execute()


    def OnCancel(self, evt):
        manager.clear()
        self.Close()
        pass


    def SetDocString(self, step):
        if "[init] " in step or "[end] " in step:
            step = step.split(' ')[1]

        (init_scripts, scripts, end_scripts) = get_scripts()
        for script in scripts:
            if script.name == step:
                self.m_staticDescription.SetLabelText(script.doc)
                return
        

    def OnCheckOrUncheck(self, event):
        """
        Goes through the scripts to determine what script is the children of our step
        Then check it.
        """
        # item that was checked or unchecked
        index = event.GetInt()
        # we don't calculate dependencies on Uncheck events
        if not self.m_checkListSteps.IsChecked(index):
            return

        step = self.raw_steps[index]
        
        # goes through all scripts NxN unfortunately to see the children
        # but skip init and end scripts (particularely end scripts, since they depend on all the previous ones !)
        (init_scripts, scripts, end_scripts) = get_scripts()
        enabled_steps = []
        enabled_steps.append(step)
        while True:
            had_changed_state = False
            for script in scripts:
                if script.status == NOT_A_SCRIPT:
                    continue
                # init or end script ? skip it
                skip = False
                for initscript in init_scripts:
                    if initscript.name == script.name:
                        skip = True
                        break
                for endscript in end_scripts:
                    if endscript.name == script.name:
                        skip = True
                        break

                if skip:
                    continue

                # index of our script in the listbox
                indexLb = self.raw_steps.index(script.name)
                if indexLb is None:
                    continue

                for fn in script.wait:
                    if fn.__self__.name in enabled_steps and self.m_checkListSteps.IsChecked(indexLb) == False : #a script waits for us ? check it
                        checkedItems = self.m_checkListSteps.GetCheckedItems()
                        checkedItems = list(checkedItems)
                        checkedItems.append(indexLb)
                        self.m_checkListSteps.SetCheckedItems(checkedItems)
                        had_changed_state = True
                        enabled_steps.append(script.name)
            if had_changed_state == False:
                break


    def OnSelect(self, event):
        step = self.m_checkListSteps.GetStringSelection()
        self.SetDocString(step)
        self.Layout()
        

class FrameRecovery(wx.Frame):
    def __init__(self, parent, scripts):
        wx.Frame.__init__(self, parent, -1, 'Batch Recovery {}'.format(__version__),
                            style=wx.DEFAULT_FRAME_STYLE | wx.CLIP_CHILDREN, size=(800,600))
        self.panel = PanelRecovery(self, scripts[0])
        self.panel.Bind(wx.EVT_CLOSE, self.OnClose)
        self.CreateStatusBar()

    def execute(self):
        self.Parent.execute(None)
        self.panel.Destroy()
        self.Destroy()

    def OnClose(self, event):
        self.panel.Destroy()
        self.Destroy()
