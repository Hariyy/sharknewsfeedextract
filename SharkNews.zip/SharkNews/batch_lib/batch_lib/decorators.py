"""
    Decorators
    ==========

    Decorators are functions that apply on other functions.


    How to use them
    ***************

    You only need to have imported them inside your script::

        from batch_lib.decorators import *

    .. note ::

        They are also available with::

            from batch_lib import *

        This line doesn't only import :mod:`batch_lib.decorators`, it also import :mod:`batch_lib.functions` and some other usefull tools when working with batch.


    Example
    *******

    Little example::

        @script
        def script_init():
            log("I'am the init script")

        @wait(script_init)
        def s1():
            log("I'm script s1 after the script_init one")

        @wait(script_init)
        def s2():
            log("I'm script s2 also after the script_init one")

        @wait(s1, s2)
        def s3():
            log("I'm script s3, after s1 and s2")

    Decorators could be summed, this example is the same as the previous one::

        @script
        def script_init():
            log("I'am the init script")

        @script
        @wait(script_init)
        def s1():
            log("I'm script s1 after the script_init one")

        @script
        @wait(script_init)
        def s2():
            log("I'm script s2 also after the script_init one")

        @script
        @wait(s1)
        @wait(s2)
        def s3():
            log("I'm script s3, after s1 and s2")

    Decorators
    **********

"""
from __future__ import absolute_import

import textwrap
import os
import sys
import types
import time

from .script import Script
from .functions import batch_function, logtime, logdate
from .execute import manager
from .environment import ENV

__all__ = ["script", "init", "wait", "wait_success", "wait_error", "end",
            "wait_any", "wait_any_success", "wait_any_error", "nb_processes", "batch_function"]


# DEFAULT CALLBACK -------------------------------------------------------------

def logstart(obj_script):
    """
        Log the start of a Script
    """
    if obj_script.func.__doc__:
        # We want only show the first line
        doc = obj_script.func.__doc__
        start = doc.find('\n') + 1
        end = doc.find('\n', start)
        if end == -1:
            doc = doc[start:]
        else:
            doc = doc[start:end]
        doc = textwrap.dedent(doc)
        logtime("BEGIN", obj_script.name, doc)
    else:
        logtime("BEGIN", obj_script.name)

def logend(obj_script):
    """
        Log the end of a Script
    """
    logtime("END", obj_script.name)

def logstartdate(obj_script):
    """
        Used before the @init scripts
        log the date at top of logfile
    """
    script_title = os.path.basename(sys.modules[obj_script.func.__module__].__file__)
    script_title = script_title.replace("_", " ").replace(".pyc", "").replace(".py","")
    logdate(script_title)

# END OF DEFAULT CALLBACKS -----------------------------------------------------


def script(s):
    """
        Decorate a function to convert it into a Script

        If only this decorator is used, this script will be a top level one.

        Then it will be executed in first.

        Example::

            @script
            def test_script1():
                log("This is a test")
    """
    if isinstance(s, Script):
        return s
    else:
        obj = Script(func = s)
        obj.callbacks["before"].append((logstart, [], {}))
        obj.callbacks["after"].append((logend, [], {}))
        return obj

def init(s):
    """
        Decorate a function to convert it into a Script.

        But this Script is particular because it will be executed first.

        These two examples are equivalent

        Example 1 (without @init)::

            @script
            def configure():
                log("I'am the init script")

            @wait_success(configure)
            def first_task():
                log("I'am the first task")

        Example 2 (with @init)::

            @init
            def configure():
                log("I'am the init script")

            @script(configure)
            def first_task():
                log("I'am the first task")
    """
    obj = script(s)
    obj.callbacks["before"].insert(0, (logstartdate, [], {}))
    manager.scripts.remove(obj)
    manager.init_scripts.append(obj)
    return obj


def wait(*args):
    """
        Decorate a function to wait complete of scripts passed in args.

        .. note::
            A script is complete when it return, either it's a success or an error.

        Example::

            @wait(s1)
                Will wait that s1 is complete to allow this script to be launched

            @wait(s1, s2)
                Will wait that s1 and s2 are complete to allow this script to be launched
    """
    def decorate(s):
        if isinstance(s, list):
            l = []
            for f in s:
                obj = script(f)
                obj.wait_complete(*args)
                l.append(obj)
            return l
        else:
            obj = script(s)
            obj.wait_complete(*args)
            return obj
    return decorate



def wait_error(*args):
    """
        Decorate a function to wait error of scripts passed in args.

        .. note::
            A script is in error when it return False or when something bad happen
            during it's execution.

            If a function, or even your script raised an exception, or if :func:`batch_lib.functions.call` detect output on stderr
            for example.

        Example::

            @wait_error(s1)
                Will wait that s1 make an error to allow this script to be launched

            @wait_error(s1, s2)
                Will wait that s1 and s2 make error to allow this script to be launched

    """
    def decorate(s):
        if isinstance(s, list):
            l = []
            for f in s:
                obj = script(f)
                obj.wait_error(*args)
                l.append(obj)
            return l
        else:
            obj = script(s)
            obj.wait_error(*args)
            return obj
    return decorate

def wait_success(*args):
    """
        Decorate a function to wait success of scripts passed in args.

        .. note::
            A script is in success when it return True or when nothig bad happen
            during it's execution.

        Example::

            @wait_success(s1)
                Will wait that s1 end successfully

            @wait_success(s1, s2)
                Will wait that s1 and s2 end successfully

    """
    def decorate(s):
        if isinstance(s, list):
            l = []
            for f in s:
                obj = script(f)
                obj.wait_success(*args)
                l.append(obj)
            return l
        else:
            obj = script(s)
            obj.wait_success(*args)
            return obj
    return decorate


def wait_any(*args):
    """
        Decorate a function to wait one of scripts passed in args to be complete.

        .. note::
            A script is complete when it return, either it's a success or an error.

        Example::

            @wait_any(s1)
                Will wait that s1 is complete to allow this script to be launched
                Same as @wait with a single args

            @wait_any(s1, s2)
                Will wait s1 or s2 to be complete to allow this script to be launched
    """
    def decorate(s):
        if isinstance(s, list):
            l = []
            for f in s:
                obj = script(f)
                obj.wait_any_complete(*args)
                l.append(obj)
            return l
        else:
            obj = script(s)
            obj.wait_any_complete(*args)
            return obj
    return decorate



def wait_any_error(*args):
    """
        Decorate a function to wait one error of scripts passed in args.

        .. note::
            A script is in error when it return False or when something bad happen
            during it's execution.

            If a function, or even your script raised an exception, or if :func:`batch_lib.functions.call` detect output on stderr
            for example.

        Example::

            @wait_any_error(s1)
                Will wait that s1 make an error to allow this script to be launched
                Same as @wait_error with a singla args

            @wait_any_error(s1, s2)
                Will wait s1 or s2 to be error to allow this script to be launched

    """
    def decorate(s):
        if isinstance(s, list):
            l = []
            for f in s:
                obj = script(f)
                obj.wait_any_error(*args)
                l.append(obj)
            return l
        else:
            obj = script(s)
            obj.wait_any_error(*args)
            return obj
    return decorate

def wait_any_success(*args):
    """
        Decorate a function to wait one success of scripts passed in args.

        .. note::
            A script is in success when it return True or when nothig bad happen
            during it's execution.

        Example::

            @wait_any_success(s1)
                Will wait that s1 end successfully
                Same as @wait_success(s1)

            @wait_ant_success(s1, s2)
                Will wait that s1 or s2 end successfully

    """
    def decorate(s):
        if isinstance(s, list):
            l = []
            for f in s:
                obj = script(f)
                obj.wait_any_success(*args)
                l.append(obj)
            return l
        else:
            obj = script(s)
            obj.wait_any_success(*args)
            return obj
    return decorate

def end(s):
    """
        Decorate a function to convert it into a script that will be executed at end.

        Whatever the previous script are sucessfull or not (event the ``@init`` one), scripts decorated
        with ``@end`` will be executed after all the other and before batch terminate.

        If there is many ``@end`` script, they will be executed in parrallel (always limited to the max number of workers you have set)
    """
    obj = script(s)
    manager.scripts.remove(obj)
    manager.end_scripts.append(obj)
    return obj

def nb_processes(nb, wait=1):
    """
        Decorate a subscript to execute-it n times.

        Example::

            @nb_processes(10)
            def my_action(nb, total):
                log("action {}/{}".format(nb, total)

        Will create 10 scripts, and each one will log "action x/10" with x from 0 to 9

        .. warning::

            ``@nb_processes(n)`` have to be the last decorator.

            ``@nb_processes(n)`` is not stackable with @init and @end.

            This is forbidden::

                @nb_processes(4)
                @wait(other_scripts)
                def my_script(n, t):
                    ...

            You have to do this::

                @wait(my_other_script)
                @nb_processes(4)
                def my_script(n, t):
                    ...

        .. note::

            There is an optional parameters ``wait``, it allow to differ the execution of each scripts.

            By default it is set to "1" (it is in seconds) each scripts will wait nb * wait seconds.

            With nb increasing on each process, to ensure for example that all the process are not going to open a dll at same time.

            This functionnality is the port of the ``wait``parameters in runmthdll.

            It should be used like this::

                @nb_processes(4, wait=2)
                def my_function(nb, total):
                    ...
    """
    def decorate(s):
        if(not isinstance(s, types.FunctionType)):
            raise Exception("@nb_processes only decorates function.")
        l = []
        glob = sys.modules[s.__module__]
        name = s.__name__
        for i in range(nb):
            new_name = name + "_{}".format(i)
            def obj(n, total):
                time.sleep(wait * n)
                return s(n, total)
            obj.__name__ = new_name
            obj.__module__ = s.__module__
            obj.__doc__ = s.__doc__
            obj = script(obj)
            obj.args.append(i)
            obj.args.append(nb)
            setattr(glob, new_name, obj)
            l.append(obj)
        return l
    return decorate

