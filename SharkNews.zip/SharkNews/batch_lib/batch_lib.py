from __future__ import unicode_literals, absolute_import

import argparse
import sys
import os
import signal
import subprocess

__all__ = ["__version__", "main"]

__version__ = "6.1.1.0"


def main():
    """
        Expose some batch tools
    """
    # useless to import modules when we are not calling the main (when pyzzer load the version number)
    from .tools import init, translate, graph, exe, gui

    parser = argparse.ArgumentParser(description="batch  " +  __version__)

    subparsers = parser.add_subparsers(title='Batch tools',
                    description='Use -h option on each options to know more about them. ("gui" and "exe" are default options, "gui" when there is nothing, and "exe" when there is args)',
                    help='',
                    dest='tool')
    tools = [
            ("exe", exe.Exe()),
            ("gui", gui.Gui()),
            ("init", init.Init()),
            ("translate", translate.Translate()),
            ("graph", graph.Graph())]

    for tool_name, tool in tools:
        tool.parser(subparsers, tool_name)

    # HACK because default subparsers is not implemented
    # see http://bugs.python.org/issue9253 maybe one day the hack could be removed
    # As of 22/04/2013, it seams that fix is planned for python 3.3 (and today we are with python 2.7)
    if len(sys.argv) > 1 and sys.argv[1] not in ['-h', '--help']:
        hack = True
        for tool_name, tool in tools:
            if sys.argv[1] == tool_name:
                hack = False
                break
        if hack:
            sys.argv.insert(1, "exe")

    # If there is no args, launch the GUI
    if len(sys.argv) == 1:
        sys.argv.insert(1, "gui")

    args = parser.parse_args()

    for tool_name, tool in tools:
        if args.tool == tool_name:
            tool.execute(args)

def kill_handler(signal, _frame):
    """
        Ensure that all our children are killed when we are killed

        Onlywork with basic signal (ctrl+C / soft signal from task scheduler...)
        But hard signal from taskmanager are not catchable (taskill also)
    """
    p = subprocess.call(['taskkill', '/F', '/T', '/PID', str(os.getpid())], stderr=subprocess.PIPE, stdout=subprocess.PIPE)
    p.communicate()
    p.wait()
    sys.exit(1)

signal.signal(signal.SIGTERM, kill_handler)
signal.signal(signal.SIGINT, kill_handler)
signal.signal(signal.SIGBREAK, kill_handler)

if __name__ == "__main__":
    main()