#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function
import pandas as pd
from lib_util import pyetl
from lib_util import lib_log
from collections import OrderedDict
import pandas as pd
import re
import codecs

logger = lib_log.Logger()


class Sql(pyetl.PyEtl):
    def __init__(self, config):
        super(Sql, self).__init__(config)
        self.encoding = 'utf-8'
        self.coerce_float = True
        self.convert_float_to_str_flag= False
        self.empty_df_flag = True
        self.float_format = '%.15f'

    def transform(self):
        pass
