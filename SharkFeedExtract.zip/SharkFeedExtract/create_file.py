#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import pandas as pd
from sqlalchemy import create_engine
from csv import QUOTE_ALL 
import pyodbc
from lib_util import lib_log
from lib_util import utilities
from batch_lib import *
logger = lib_log.Logger()
import urllib
import sqlalchemy as sa

class CreateFile:
    def __init__(self, query_str, file_name, chunksize, output_dir, connection_string):
        self.query_str = query_str
        self.chunksize = chunksize
        self.filepath = os.path.join(output_dir, file_name)
        self.connection_string = connection_string
        self.file_name = file_name

    def create_file(self):
        try:
            my_conn = urllib.parse.quote_plus(self.connection_string)                    
            engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(my_conn))
            metadata = sa.MetaData(bind=None)
            connection = engine.connect()
            count = 1
            # fetch all data in chuncks and write to files.
            for chunk in pd.read_sql(self.query_str, connection, chunksize=self.chunksize, coerce_float=False ):
                if(count == 1):
                    chunk.to_csv(self.filepath, sep='|', index=False,
                    quoting=QUOTE_ALL, chunksize=self.chunksize)
                    count = count + 1
                else:
                    chunk.to_csv(self.filepath, sep='|', index=False,
                    quoting=QUOTE_ALL, chunksize=self.chunksize, mode='a', header=None)

            #Special case when df results has Zero recrods.
            if(count == 1):
                result_df = pd.read_sql(self.query_str, connection)
                result_df.to_csv(self.filepath, sep='|', index=False, quoting=QUOTE_ALL)

        except Exception:
                dbg('{0} : {1} file geneartion failed'.format(utilities.capture_trace(), self.file_name))
                raise

    def create_file_custome(self):
        try:
            my_conn = urllib.parse.quote_plus(self.connection_string)                    
            engine = sa.create_engine("mssql+pyodbc:///?odbc_connect={}".format(my_conn))
            metadata = sa.MetaData(bind=None)
            connection = engine.connect()
            count = 1
            # fetch all data in chuncks and write to files.
            for chunk in pd.read_sql(self.query_str, connection, chunksize=self.chunksize, coerce_float=False ):
                if(count == 1):
                    chunk.to_csv(self.filepath, sep='|', index=False,
                    quoting=QUOTE_ALL, chunksize=self.chunksize,na_rep="<<NULL>>")
                    count = count + 1
                else:
                    chunk.to_csv(self.filepath, sep='|', index=False,
                    quoting=QUOTE_ALL, chunksize=self.chunksize, mode='a', header=None)

            #Special case when df results has Zero recrods.
            if(count == 1):
                result_df = pd.read_sql(self.query_str, connection)
                result_df.to_csv(self.filepath, sep='|', index=False, quoting=QUOTE_ALL)

        except Exception:
                dbg('{0} : {1} file geneartion failed'.format(utilities.capture_trace(), self.file_name))
                raise







    