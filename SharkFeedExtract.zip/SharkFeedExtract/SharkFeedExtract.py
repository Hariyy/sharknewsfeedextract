# MANDATORY --------------------------------------------------------------------
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from __future__ import print_function
from lib_util import lib_log
from lib_util import utilities
import os
from batch_lib import *
import sql_etl
import urllib.parse
from sqlalchemy import create_engine
import pandas as pd
import csv , glob
import create_file
from socket import gethostname
import shutil
import datetime
from datetime import timedelta, datetime
import subprocess
logger = lib_log.Logger()
# ------------------------------------------------------------------------------

@init
def section_init():
    log("-----------------------------------------------------------------------------")
    logdate("SharkFeedExtract")
    log("-----------------------------------------------------------------------------")
    remove("SharkFeedExtract.log")
    remove("SharkFeedExtract.dbg")
    ENV.define("J", today())
    ENV.define("job_name", "SharkFeedExtract")
    ENV.define("root", "\\\\"+gethostname())
    ENV.define("base_directory", os.path.join(root, 'batch', 'SharkFeedExtract') + '\\') 
    ENV.define("output_dir", os.path.join(root,  'in\\incoming\\SharkFeedExtract') + '\\') 
    ENV.define("dependency_dir", os.path.join(root,  'dependency'))
    ENV.define("archive_dir", os.path.join(root, 'archive', job_name) + '\\')
    ENV.define("zip_dir", os.path.join(root, 'zip', job_name) + "\\")
    ENV.define("zip_file_name", "SharkFeedExtract.zip") 
    ENV.define("archive_log_dir", os.path.join(root,  'log\\SharkFeedExtract'))
    ENV.define("config_file_truecourse", base_directory + "software.ini")
    ENV.define("config_file_truecourse_lion", base_directory + "software_lion.ini")  
    ENV.define("chunksize", 1000000)
    # ENV.define("to", ["ccs.db.feed.notification@factset.com" , "CE.Automation.Team.Hyd@factset.com"])

@script
def clean():
    logdate("Clean the output_dir folders")
    log("-----------------------------------------------------------------------------")
    call("del /S /Q " + output_dir + "*.*")
    call("del /S /Q " + zip_dir + "*.*")
    log("-----------------------------------------------------------------------------")

@wait_success(clean)
def get_connection_string():
    #load sql to fetch the connection string base values
    ##;Trusted_Connection=yes;
    try:
        run = sql_etl.Sql(config_file_truecourse)
        cstring =   'DRIVER=' + run.driver + ';SERVER=' + run.server + ';DATABASE=' + run.database + ';UID=' + run.sql_user + ';PWD=' + run.sql_password +  ';APP= CCSDBFeed-' + job_name + run.add_connection_property
        ENV.define("connection_string", cstring)
    except Exception as e:
        dbg('{} : get_connection_string formation failed'.format(utilities.capture_trace()))
        raise

@wait_success(get_connection_string)
def get_connection_string_lion():
    #load sql to fetch the connection string base values
    ##;Trusted_Connection=yes;
    try:
        run = sql_etl.Sql(config_file_truecourse_lion)
        cstring =   'DRIVER=' + run.driver + ';SERVER=' + run.server + ';DATABASE=' + run.database + ';UID=' + run.sql_user + ';PWD=' + run.sql_password +  ';APP= CCSDBFeed-' + job_name + run.add_connection_property
        ENV.define("connection_string", cstring)
    except Exception as e:
        dbg('{} : get_connection_string formation failed'.format(utilities.capture_trace()))
        raise

@wait_success(get_connection_string_lion)
def run_sql_company():
    try:
        sql_query =     ''' select company_code,current_company_code,iconum,state_incorporated,job_status,jurisdiction_incorporated,pill_policy,pill_policy_txt,elect_standard_cd,elect_standard_source_cd,resignation_policy_carveout_flg,director_elect_notes,timing_co_proxy_date,timing_co_proxy_text,timing_fight_date,timing_fight_text,next_annual_meeting,maj_standard_date,maj_standard_carveout_flg,resignation_policy_flg,resignation_policy_source_cd,resignation_policy_date,filings_only_flg,corp_gov_web_site,proxy_fight_flg,point_in_time_record_flg,status_cd,status_date,status_text,company_name,state,country from truecourse.dbo.company (nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='company.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_company)
def run_sql_filermst():
    try:
        sql_query = ''' SELECT iconum,sect_code,ind_code FROM truecourse_lion.dbo.filermst(nolock)'''        
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='filermst.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(get_connection_string_lion)
def run_sql_company_ticker():
    try:
        sql_query =   ''' SELECT primary_listing,company_code,ticker,stock_exchange from truecourse.dbo.company_ticker (nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='company_ticker.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_company_ticker)
def run_sql_charter():
    try:
        sql_query = ''' SELECT charter_id,company_code,classified_board,classified_board_cd,sm_classified_board,sm_classified_board_cd,sm_classified_board_pt,sm_classified_board_text, 
        fixed_number_board_seats,fixed_number_board_seats_cd,director_remove_for_cause,director_remove_cause_cd,board_can_change_board_size,board_can_change_board_size_cd,sm_board_size,
        sm_board_size_cd,sm_board_size_pt,board_size_text,sm_remove_directors,sm_remove_directors_pt,sm_remove_directors_cd,sm_vote_remove_with,sm_vote_remove_with_pt,sm_vote_remove_with_cd,
        sm_vote_remove_without,sm_vote_remove_without_pt,sm_vote_remove_without_cd,sm_amend_removal,sm_amend_removal_cd,sm_amend_removal_pt,removal_text,board_fills_vacant_seats,board_fills_vacant_seats_cd,
        board_fills_vacant_seats_text,sm_board_fills_vacant_seats,sm_board_fills_vacant_seats_pt,sm_board_fills_vacant_seats_cd,cumulative_voting,cumulative_voting_cd,sm_cumulative_voting,sm_cumulative_voting_pt ,
        sm_cumulative_voting_cd,conting_cumulative_voting,conting_cumulative_voting_pt,conting_cumulative_voting_cd,cumulative_voting_text,anr_proposals_min_days,anr_proposals_max_days,anr_proposals_cd,
        anr_sh_nomination_min_days,anr_sh_nomination_max_days,anr_sh_nomination_cd,advance_notice_text,fair_price_provision,fair_price_pt,fair_price_pt_cd,sm_amend_provision_fair_price,sm_amend_provision_pt,
        sm_amend_provision_cd,director_qualification,director_qualification_cd,sm_requirement,sm_requirement_pt,fair_price_mechanism_cd,fair_price_text,sm_vote_for_merger,sm_vote_for_merger_pt,sm_vote_for_merger_cd,
        escape_for_board_approve,amend_merger_requirement,amend_merger_requirement_cd,amend_merger_requirement_pt,amend_merger_text,sm_vote_amend_all,sm_vote_amend_charter,sm_vote_amend_charter_pt,sm_vote_amend_charter_cd,
        sm_vote_amend_bylaw_all,sm_vote_amend_bylaw,sm_vote_amend_bylaw_pt,sm_vote_amend_bylaw_cd,sm_bylaw_charter_text,action_writ_consent,action_writ_consent_cd,action_writ_consent_pt,unanimous_writ_consent,
        unanimous_writ_consent_cd,sm_amend_written_consent,sm_amend_written_consent_cd,sm_amend_written_consent_pt,written_consent_text,blank_check_pref_stock,blank_check_pref_stock_cd,sh_can_call_spec_meet,
        sh_can_call_spec_meet_cd,sh_limit_right_spec_meet,sh_limit_right_spec_meet_pt,sh_limit_right_spec_meet_cd,sm_amend_special_meetings,sm_amend_special_meetings_cd,sm_amend_special_meetings_pt,
        special_meetings_text,bc_bylaws_without_sh_vote,bc_bylaws_without_sh_vote_cd,bc_bylaws_without_sh_vote_text,sm_bc_bylaws_without_sh_vote,sm_bc_bylaws_without_sh_vote_pt,sm_bc_bylaws_without_sh_vote_cd,
        bind_poison_pill_bylaw,bind_poison_pill_bylaw_cd,bind_poison_pill_bylaw_text,anti_greenmail_provision,anti_greenmail_provision_cd,anti_greenmail_provision_text,expanded_const_prov,expanded_const_prov_cd,
        expanded_const_prov_text,unequal_voting,unequal_voting_cd,unequal_voting_text,charter_bylaw_text,inaccurate_filing,other_defense_text,board_size_max,anr_der,anr_der_cd,sm_anr,sm_anr_pt,sm_anr_cd,sm_sm_vote_amend_charter,
        sm_sm_vote_amend_charter_cd,sm_sm_vote_amend_charter_pt,sm_sm_vote_amend_bylaw,sm_sm_vote_amend_bylaw_cd,sm_sm_vote_amend_bylaw_pt,sm_blank_check_pref_stock,sm_blank_check_pref_stock_pt,sm_blank_check_pref_stock_cd,
        sm_expanded_const_prov,sm_expanded_const_prov_pt,sm_expanded_const_prov_cd,sm_anti_greenmail_provision,sm_anti_greenmail_provision_cd,sm_anti_greenmail_provision_pt,sm_bind_poison_pill_bylaw,sm_bind_poison_pill_bylaw_pt,
        sm_bind_poison_pill_bylaw_cd,sm_unequal_voting,sm_unequal_voting_pt,sm_unequal_voting_cd,cb_own_limit,cb_own_limit_cd,proxy_access,proxy_access_pt,proxy_access_cd,sm_proxy_access,sm_proxy_access_cd,sm_proxy_access_pt,
        proxy_access_text,anr_event,exclusive_forum,sm_exclusive_forum_cd,sm_exclusive_forum,exclusive_forum_cd,sm_exclusive_forum_pt,exclusive_forum_text,cb_own_limit_pt,supermajority_own_limit,supermajority_own_limit_cd,
        supermajority_own_limit_text,supermajority_own_limit_pt FROM truecourse.dbo.charter(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='charter.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(get_connection_string)
def run_sql_proposals_proposals():
    try:
        sql_query = ''' SELECT id,proposals_meeting_id ,proposal ,proposal_type ,binding ,vote_requirement ,number_votes_for ,number_votes_against ,number_votes_abstain ,number_broker_non_votes ,pass ,footnote ,company_response ,proposal_exclude ,no_action_sought ,no_action_granted ,charter_amend ,bylaw_amend ,proposal_text ,type_14a8_flg,resigned_flg,contested_flg,proposal_exclude_notinproxy ,proposal_exclude_nonus ,oneyear_votes ,twoyear_votes ,threeyear_votes ,frequency_abstain ,frequency_broker_non_votes ,frequency_recommend ,mgmt_recommended ,alternate_votes_out ,proponent_statement ,statement_in_opposition ,notvoted_type ,people_iconum,company_code,proponent FROM truecourse.dbo.proposals_proposals(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='proposals_proposals.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(get_connection_string)
def run_sql_proposals_meeting():
    try:
        sql_query = ''' SELECT id ,company_code ,meeting_date ,pill_in_force ,internal_notes ,update_date,proxy_url ,special_meeting ,written_consent ,proposals_record_date ,withhold_text ,proxy_id ,meeting_cancelled_flg ,meeting_agenda ,fds_url,doc_id FROM truecourse.dbo.proposals_meeting(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='proposals_meeting.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(get_connection_string)
def run_sql_company_identifier():
    try:
        sql_query =   ''' SELECT company_code , code , identifier FROM truecourse.dbo.company_identifier(nolock) '''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='company_identifier.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_company_identifier)
def run_sql_proponent_lookup():
    try:
        sql_query = ''' SELECT id,parent_id,proponent_name,type_cd,address1,address2,city,state,zip,country,phone,fax,web_site,profile,iconum,core_activist_flg,ranking,resume_flg,internal_notes,update_date,update_user,create_date,create_user,equity_assets,ls_parent_iconum,activist_flg,activist_type_cd FROM truecourse.dbo.proponent_lookup (nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='proponent_lookup.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_proponent_lookup)
def run_sql_proponent_lookup_custome():
    try:
        sql_query = ''' SELECT id,parent_id,proponent_name,type_cd,address1,address2,city,state,zip,country,phone,fax,web_site,profile,iconum,core_activist_flg,ranking,resume_flg,internal_notes,update_date,update_user,create_date,create_user,equity_assets,ls_parent_iconum,activist_flg,activist_type_cd FROM truecourse.dbo.proponent_lookup (nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='proponent_lookup_custome.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file_custome()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_proponent_lookup_custome)
def run_sql_fight():
    try:
        sql_query = ''' SELECT id,company_code,meeting_date,announce_date,last_date_activity_text,last_date_activity,winner_cd,seats_up,dissident_nominees,total_seats,do_pct,do_note,fight_synopsis,special_meeting_flg,written_consent_flg,proxy_fight_flg,exempt_solicitation_flg,other_stockholder_campaign_flg,seek_reimbursement_flg,ms_deal_id,campaign_type_cd,est_meeting_date,end_date,title,outcome,dissident_pct,seats_won,campaign_type_secondary_cd,marketcap,pill_inforce_flg,pill_response_flg,classified_board_flg,cumulative_voting_flg,votenomerger_exclude_flg,votenomerger_announce_date,dissident_announce_pct,votenomerger_soliciting_proxies_flg,votenomerger_competing_offer_flg,votenomerger_sweetened_flg,votenomerger_doc_id,iss_recommend_cd,glass_recommend_cd,fight_record_date,instn_pct,est_pf_cost,short_position_flg,est_dissident_pf_costs,company_solicitor_fee,dissident_solicitor_fee,company_fee_text,dissident_fee_text,engagement_type_cd,rumor_date FROM truecourse.dbo.fight (nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight)
def run_sql_fight_advisor():
    try:
        sql_query = ''' SELECT fight_id , advisor_cd,  type_cd, client_cd   FROM truecourse.dbo.fight_advisor(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight_advisor.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight_advisor)
def run_sql_advisor():
    try:
        sql_query = ''' SELECT advisor_code, iconum, company_code   FROM truecourse.dbo.advisor(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='advisor.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_advisor)
def run_sql_SR_GovernanceChangeInControl():
    try:
        sql_query = ''' SELECT * FROM truecourse.dbo.SR_GovernanceChangeInControl(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_GovernanceChangeInControl.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_GovernanceChangeInControl)
def run_sql_SR_GovernanceExecutiveCompensation():
    try:
        sql_query = ''' SELECT Id,governance_id,compensation_policy,is_policy,multiple,basis,source_type,Window,Executive_Comp_Notes FROM truecourse.dbo.SR_GovernanceExecutiveCompensation (nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_GovernanceExecutiveCompensation.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_GovernanceExecutiveCompensation)
def run_sql_SR_GovernanceSource():
    try:
        sql_query = ''' SELECT Id,governance_id,source_type,filing_type,url,fdsurl,is_active,doc_id,news_doc_GUID,source_doc,html_format_flg FROM truecourse.dbo.SR_GovernanceSource(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_GovernanceSource.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_GovernanceSource)
def run_sql_SR_GovernanceBoardComposition():
    try:
        sql_query = ''' SELECT Id,governance_id,director_requirement_code,is_policy,is_waivable,limit_value,source,Composition_Internal_Notes FROM truecourse.dbo.SR_GovernanceBoardComposition (nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_GovernanceBoardComposition.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_GovernanceBoardComposition)
def run_sql_SR_Governance():
    try:
        sql_query = ''' SELECT Id,company_code,is_director_attendence75,say_on_pay_frequency,Proposal_Id,effective_date FROM truecourse.dbo.SR_Governance(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_Governance.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_Governance)
#LookUp Tables
def run_sql_SR_LookupCompanyStatuses():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupCompanyStatuses(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupCompanyStatuses.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupCompanyStatuses)
def run_sql_SR_LookupCompanyTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupCompanyTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupCompanyTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupCompanyTypes)
def run_sql_SR_LookupCountries():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupCountries(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupCountries.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupCountries)
def run_sql_SR_LookupJobStatuses():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupJobStatuses(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupJobStatuses.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupJobStatuses)
def run_sql_SR_LookupJurisdictions():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupJurisdictions(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupJurisdictions.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupJurisdictions)
def run_sql_SR_LookupPillStatus():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupPillStatus(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupPillStatus.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupPillStatus)
def run_sql_SR_LookupPillTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupPillTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupPillTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupPillTypes)
def run_sql_SR_LookupPillVersion():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupPillVersion(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupPillVersion.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupPillVersion)
def run_sql_SR_LookupProponentTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupProponentTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupProponentTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupProponentTypes)
def run_sql_SR_LookupProposals():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupProposals(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupProposals.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupProposals)
def run_sql_SR_LookupProposalTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupProposalTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupProposalTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupProposalTypes)
def run_sql_SR_LookupProvinceTerritories():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupProvinceTerritories(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupProvinceTerritories.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupProvinceTerritories)
def run_sql_SR_LookupProvisionLocation():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupProvisionLocation(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupProvisionLocation.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupProvisionLocation)
def run_sql_SR_LookupSecurityTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupSecurityTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupSecurityTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupSecurityTypes)
def run_sql_SR_LookupShareClasses():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupShareClasses(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupShareClasses.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupShareClasses)
def run_sql_SR_LookupStates():
    try:
        sql_query = ''' SELECT Code, Description FROM truecourse.dbo.SR_LookupStates(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupStates.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupStates)
def run_sql_SR_LookupSupportTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupSupportTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupSupportTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupSupportTypes)
def run_sql_SR_LookupValueObjective():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupValueObjective(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupValueObjective.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupValueObjective)
def run_sql_SR_LookupVotePass():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupVotePass(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupVotePass.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupVotePass)
def run_sql_SR_LookupVoteRequirementTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupVoteRequirementTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupVoteRequirementTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupVoteRequirementTypes)
def run_sql_SR_LookupVoteStandardToElectSources():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupVoteStandardToElectSources(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupVoteStandardToElectSources.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupVoteStandardToElectSources)
def run_sql_SR_LookupVoteStandardToElectTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupVoteStandardToElectTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupVoteStandardToElectTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupVoteStandardToElectTypes)
def run_sql_SR_LookupAdvisorType():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupAdvisorType(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupAdvisorType.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupAdvisorType)
def run_sql_SR_LookupAmendmentTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupAmendmentTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupAmendmentTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupAmendmentTypes)
def run_sql_SR_LookupApprovalType():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupApprovalType(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupApprovalType.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupApprovalType)
def run_sql_SR_LookupCharterBylawType():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupCharterBylawType(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupCharterBylawType.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupCharterBylawType)
def run_sql_SR_LookupCharterHistory():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupCharterHistory(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupCharterHistory.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupCharterHistory)
def run_sql_SR_LookupClassifiedChange():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupClassifiedChange(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupClassifiedChange.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupClassifiedChange)
def run_sql_SR_LookupDirectorTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupDirectorTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupDirectorTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupDirectorTypes)
def run_sql_SR_LookupExemptionLimits():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupExemptionLimits(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupExemptionLimits.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupExemptionLimits)
def run_sql_SR_LookupFightAdvisorClient():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupFightAdvisorClient(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupFightAdvisorClient.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupFightAdvisorClient)
def run_sql_SR_LookupFightCampaignType():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupFightCampaignType(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupFightCampaignType.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupFightCampaignType)
def run_sql_SR_LookupFightDissidentTactics():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupFightDissidentTactics(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupFightDissidentTactics.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupFightDissidentTactics)
def run_sql_SR_LookupFightParticipant():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupFightParticipant(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupFightParticipant.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupFightParticipant)
def run_sql_SR_LookupFightSpecialExhibit():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupFightSpecialExhibit(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupFightSpecialExhibit.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupFightSpecialExhibit)
def run_sql_SR_LookupFightTactics():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupFightTactics(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupFightTactics.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupFightTactics)
def run_sql_SR_LookupFightWinner():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupFightWinner(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupFightWinner.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupFightWinner)
def run_sql_SR_LookupFilingType():
    try:
        sql_query = '''select Code,Description,Web_description from truecourse.dbo.SR_LookupFilingType'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupFilingType.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupFilingType)
def run_sql_SR_LookupFrequencyRecommend():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupFrequencyRecommend(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupFrequencyRecommend.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupFrequencyRecommend)
def run_sql_SR_LookupGovernanceObjective():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupGovernanceObjective(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupGovernanceObjective.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupGovernanceObjective)
def run_sql_SR_LookupGrandProvisions():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupGrandProvisions(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupGrandProvisions.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupGrandProvisions)
def run_sql_SR_LookupActivistType():
    try:
        sql_query = ''' SELECT Code, Description FROM truecourse.dbo.SR_LookupActivistType(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupActivistType.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupActivistType)
def run_sql_SR_LookupPillInPlayCategory():
    try:
        sql_query = ''' SELECT Code, Description FROM truecourse.dbo.SR_LookupPillInPlayCategory(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupPillInPlayCategory.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupPillInPlayCategory)
def run_sql_SR_LookupStatute():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupStatute(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupStatute.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupStatute)
def run_sql_SR_LookupIndex():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupIndex(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupIndex.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupIndex)
def run_sql_SR_LookupStockExchanges():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupStockExchanges(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupStockExchanges.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupStockExchanges)
def run_sql_SR_LookupEngagementTypes():
    try:
        sql_query = ''' SELECT Code, Web_description FROM truecourse.dbo.SR_LookupEngagementTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupEngagementTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupEngagementTypes)
def run_sql_SR_LookupAdvanceNoticeEventReference():
    try:
        sql_query = ''' SELECT Code, Description FROM truecourse.dbo.SR_LookupAdvanceNoticeEventReference(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupAdvanceNoticeEventReference.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupAdvanceNoticeEventReference)
def run_sql_SR_LookupGovernanceDirectorRequirements():
    try:
        sql_query = ''' SELECT Code, Description FROM truecourse.dbo.SR_LookupGovernanceDirectorRequirements(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupGovernanceDirectorRequirements.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupGovernanceDirectorRequirements)
def run_sql_SR_LookupGovernanceCompensationPolicies():
    try:
        sql_query = ''' SELECT Code, Description FROM truecourse.dbo.SR_LookupGovernanceCompensationPolicies(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupGovernanceCompensationPolicies.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupGovernanceCompensationPolicies)
def run_sql_SR_LookupGovernanceSourceTypes():
    try:
        sql_query = ''' SELECT Code, Description FROM truecourse.dbo.SR_LookupGovernanceSourceTypes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='SR_LookupGovernanceSourceTypes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_SR_LookupGovernanceSourceTypes)
def run_sql_company_sic():
    try:
        sql_query = ''' SELECT company_code,sic_code,seq,sic_group FROM truecourse.dbo.company_sic (nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='company_sic.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_company_sic)
def run_sql_company_index():
    try:
        sql_query = ''' SELECT company_code,index_no,rank FROM truecourse.dbo.company_index(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='company_index.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_company_index)
def run_sql_company_state_takeover():
    try:
        sql_query = ''' SELECT company_code,statute,statute_cd FROM truecourse.dbo.company_state_takeover(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='company_state_takeover.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_company_state_takeover)
def run_sql_charter_history():
    try:
        sql_query = ''' SELECT ID,charter_id,change_date ,change_code ,change_desc	 FROM truecourse.dbo.charter_history(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='charter_history.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_charter_history)
def run_sql_fight_dissident_tactic():
    try:
        sql_query = ''' SELECT fight_id,tactic_cd FROM truecourse.dbo.fight_dissident_tactic(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight_dissident_tactic.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight_dissident_tactic)
def run_sql_fight_governance_objective():
    try:
        sql_query = ''' SELECT objective_type_cd,success_flg, fight_id FROM truecourse.dbo.fight_governance_objective(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight_governance_objective.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight_governance_objective)
def run_sql_fight_participant():
    try:
        sql_query = ''' SELECT fight_id,participant_cd,type_cd,pct,note  FROM truecourse.dbo.fight_participant(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight_participant.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight_participant)
def run_sql_fight_proposal():
    try:
        sql_query = ''' SELECT id ,fight_id ,proposal_type_cd,binding_flg,mgmt_recommended_flg ,charter_amend_flg  ,contested_flg,iss_flg ,glass_lewis_flg ,vote_requirement_cd ,pass_cd ,footnote ,number_votes_for ,number_votes_against,number_votes_abstain ,number_broker_non_votes ,company_response ,proposal_text,dissident_recommended_flg,candidate_name_de,related_proposal_id,proponent_cd,candidate_cd,bylaw_amend_flg FROM truecourse.dbo.fight_proposal(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight_proposal.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight_proposal)
def run_sql_fight_proposal_type():
    try:
        sql_query = ''' SELECT fight_proposal_id,proposal_cd FROM truecourse.dbo.fight_proposal_type(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight_proposal_type.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight_proposal_type)
def run_sql_fight_source():
    try:
        sql_query = ''' SELECT id,fight_id,doc_id,news_doc_guid,filing_date,publish_flg,description,source_type_cd,source_url,special_exhibit_cd,dissident_filing_flg,proxy_fight_formal_notice_flg,unsolicited_hostile_flg,seat_granted_to_dissident_flg,contentious_13d_item_flg,source_doc,doc_path,withhold_doc FROM truecourse.dbo.fight_source(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight_source.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight_source)
def run_sql_fight_shares_outstanding():
    try:
        sql_query = ''' SELECT fight_proposal_id,share_class_cd,share_number,share_votes FROM truecourse.dbo.fight_shares_outstanding(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight_shares_outstanding.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight_shares_outstanding)
def run_sql_fight_value_objective():
    try:
        sql_query = ''' SELECT fight_id ,objective_type_cd ,success_flg FROM truecourse.dbo.fight_value_objective(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight_value_objective.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight_value_objective)
def run_sql_pill():
    try:
        sql_query = ''' SELECT pill_id ,company_code ,adoption_date ,press_release_date ,last_amendment_date ,rights_agree_date ,record_date ,expiration_date ,current_pill_position ,sunset_flag ,sunset_review_years ,tide_provision,withdrawn_date ,pill_type ,plan_status ,exercise_price ,exercise_price_unsplit ,exercise_price_original ,stock_price_adoption ,stock_price_day_before ,in_play_text ,cash_or_com  ,sec_purchaseable_per_right ,num_shares_purchase_per_right ,desc_entitle_to_buy ,ap_pt ,person_pt ,person_days ,tender_pt ,tender_days ,reclass ,white_squire ,inadvert,grandfather,status_flipin ,bargain ,flip_over_pt ,adverse ,adverse_pt ,self_deal,self_deal_pt,recap,recap_pt,div_fail,div_fail_pt,permitted_bid,permitted_bid_text,shareholder_referendum  ,chewable, minimum_amend_trigger                                      ,minimum_amend_trigger_pt ,director_qualification ,redemption_price,redemption_window,redemption_requirement ,white_knight_redemption,yo_yo,yo_yo_pt,drp,drp_days,exchange,inplay_adopt,tide_provision_date,ap_text,canadian_dollar,competing_permitted_bid ,status,permitted_lockup_agreements,permitted_bid_min_days,permitted_bid_max_ownership_pt,permitted_bid_min_tender_pt,board_redeem_without_sh_approval,board_amend_without_sh_approval,value_enhancement,binding_vote,orig_expiration_date,redemption_announce_date ,derivative_trigger_flg ,derivative_trigger_date FROM truecourse.dbo.pill(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='pill.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_pill)
def run_sql_pill_advisor():
    try:
        sql_query = ''' SELECT pill_id,amendment_advisor,advisor_type,advisor_code,company_code FROM truecourse.dbo.pill_advisor(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='pill_advisor.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_pill_advisor)
def run_sql_pill_amend_history():
    try:
        sql_query = ''' SELECT id ,pill_id ,amendment ,amendment_date ,amendment_desc FROM truecourse.dbo.pill_amend_history(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='pill_amend_history.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_pill_amend_history)
def run_sql_pill_exemptions():
    try:
        sql_query = ''' SELECT pill_id ,code ,limit_code FROM truecourse.dbo.pill_exemptions(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='pill_exemptions.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_pill_exemptions)
def run_sql_pill_expiration_analysis():
    try:
        sql_query = ''' SELECT company_code,current_pill_status ,scheduled_expiration ,company_response FROM truecourse.dbo.pill_expiration_analysis(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='pill_expiration_analysis.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_pill_expiration_analysis)
def run_sql_pill_source():
    try:
        sql_query = ''' SELECT id ,pill_id ,doc_id ,news_doc_guid,pill_type ,effective_date ,filing_date ,source_url ,source_type ,description ,summary , pill_volume_exclude,dead_date ,activity_report_date ,dead_type_cd ,ratify_flg,ratify_proposals_proposals_id ,nol,ap_pt_trend,in_play, expiration_date ,exercise_price_original ,stock_price_adoption ,stock_price_day_before ,derivative_trigger_flg,acting_in_concert_flg, chewable_flg,exempt_13g_flg,in_play_text ,in_play_category ,source_doc  FROM truecourse.dbo.pill_source(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='pill_source.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_pill_source)
def run_sql_pill_vote_results():
    try:
        sql_query = ''' SELECT pill_id ,meeting_date ,approval_type ,number_votes_for ,number_votes_against ,pass ,voting_shares_out_record_date FROM truecourse.dbo.pill_vote_results(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='pill_vote_results.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_pill_vote_results)
def run_sql_proposal_categories():
    try:
        sql_query = ''' SELECT id,code,description,sub_category,category,defense_related_flg,increase_defense_flg,reduce_defense_flg,update_date FROM truecourse.dbo.proposal_categories(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='proposal_categories.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_proposal_categories)
def run_sql_proposals_meeting_custome():
    try:
        sql_query = ''' SELECT id ,company_code ,meeting_date ,pill_in_force ,internal_notes ,update_date,proxy_url ,special_meeting ,written_consent ,proposals_record_date ,withhold_text ,proxy_id ,meeting_cancelled_flg ,meeting_agenda ,fds_url,doc_id FROM truecourse.dbo.proposals_meeting(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='proposals_meeting_cust.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file_custome()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_proposals_meeting_custome)
def run_sql_proposals_proponents():
    try:
        sql_query = ''' SELECT proposals_proposals_id,proponent,proponent_name,id FROM truecourse.dbo.proposals_proponents(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='proposals_proponents.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_proposals_proponents)
def run_sql_proposals_secondary():
    try:
        sql_query = ''' SELECT proposals_proposals_id,proposal FROM truecourse.dbo.proposals_secondary(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='proposals_secondary.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_proposals_secondary)
def run_sql_proposals_shares_outstanding():
    try:
        sql_query = ''' SELECT proposals_meeting_id,share_class ,share_number ,share_votes FROM truecourse.dbo.proposals_shares_outstanding(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='proposals_shares_outstanding.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_proposals_shares_outstanding)
def run_sql_state_statutes():
    try:
        sql_query = ''' SELECT state_cd ,statutes_cd ,mandatory ,law_name ,detail_in ,detail_out FROM truecourse.dbo.state_statutes(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='state_statutes.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_state_statutes)
def run_sql_sr50_membership():
    try:
        sql_query = ''' SELECT id,start_date,end_date,proponent_lookup_id FROM truecourse.dbo.sr50_membership(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='sr50_membership.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_sr50_membership)
def run_sql_marquee_sent_log():
    try:
        sql_query = ''' SELECT fight_id,publication_date,run_date FROM truecourse.dbo.marquee_sent_log(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='sql_marquee_sent_log.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_marquee_sent_log)
def run_sql_fight_defense_tactic():
    try:
        sql_query = ''' SELECT id,fight_id ,defense_change_cd ,change_date ,defense_change_desc ,source_type_cd ,filing_date ,source_url ,charter_amend_flg ,bylaw_amend_flg ,pill_amend_flg  FROM truecourse.dbo.fight_defense_tactic(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='fight_defense_tactic.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_fight_defense_tactic)
def run_sql_charter_source():
    try:
        sql_query = ''' SELECT id,charter_id,doc_id,news_doc_GUID,source_cd ,filing_date ,description ,source_type ,effective_date ,source_url ,active,source_doc,doc_path FROM truecourse.dbo.charter_source(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='charter_source.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_charter_source)
def run_sql_sector():
    try:
        sql_query = ''' SELECT sect_code,sector FROM truecourse_lion.dbo.sector(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='sector.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_sector)
def run_sql_industries():
    try:
        sql_query = ''' SELECT ind_code,industry FROM truecourse_lion.dbo.industries(nolock)'''
        cr_file = create_file.CreateFile(query_str = sql_query, file_name='industries.txt', chunksize = chunksize, output_dir = output_dir, connection_string = connection_string)
        cr_file.create_file()
    except Exception:
        dbg('{}'.format(utilities.capture_trace()))
        raise

@wait_success(run_sql_industries,run_sql_filermst,run_sql_charter,run_sql_proposals_proposals,run_sql_proposals_meeting) 
def create_dependency():
    utilities.create_dependency_file(dependency_dir=dependency_dir, job_name=job_name)

###zip files
@wait_success(create_dependency)
def zip_files():

    utilities.zip_files(output_dir=output_dir, zip_dir=zip_dir,
						zip_filename=zip_file_name)
		
###archiving
@wait_success(zip_files)
def copy_archive_folder():
    #copying archive files to s3
    try:
        subprocess.run(r'S3copy.bat')	
    except Exception as e: 
        dbg('{}'.format(utilities.capture_trace()))
        raise

        ### deleting the zip file
        call("del /S /Q " + zip_dir + "*.*")

@wait_success(copy_archive_folder)
# def archive_files():
#     utilities.archive_files(base_directory, job_name, archive_dir, zip_dir, archive_log_dir)

#     ##deleting the zip file
#     call("del /S /Q " + zip_dir + "*.*")

@end
def notification():
    # utilities.fail_email(to, base_directory, job_name, archive_log_dir)
    pass