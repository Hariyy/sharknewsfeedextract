﻿import fileinput

for line in fileinput.FileInput("yop.json", inplace=1):
    line=line.replace("\"","")
    line=line.replace("{","")
    line=line.replace("}","")
    line=line.replace("awsAccessKey:","aws_access_key_id        = ")
    line=line.replace("awsSecretKey:","aws_secret_access_key    = ")
    line=line.replace("awsSessionToken:","aws_session_token        = ")
    line=line.replace("awsPrincipalArn:","x_principal_arn          = ")
    line=line.replace("awsExpires:","x_security_token_expires = ")
    line=line.replace(",","\n")
    print(line)
