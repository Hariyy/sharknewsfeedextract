﻿$source = "D:\DataGroup2\in\incoming\TNCFeedExtract\"
$destdir1 = "\\ccscalca01\in\incoming\TNCFeedExtract\"


$path1 =  "$destdir1"

echo $path1

Write-Host "Copying to $path1"

robocopy "$source" "$path1" /e /purge /COPY:DAT /DCOPY:T /MT:25

