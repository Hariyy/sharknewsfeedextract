from lib_cipher import Cipher

password = "mypassword2019"

crypt = 'l4crypt'
value = Cipher(crypt).encrypt(password)
print(value)