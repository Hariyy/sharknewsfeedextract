#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function
from __future__ import unicode_literals
import os
from codecs import open as cd_open
import datetime
import urllib.parse
from sqlalchemy import create_engine, text

from . import utilities
from . import lib_log

class FeedUiInsert():
    """
    **Objective**
        The module is created to ingest log and dbg file data to FD ui. In order to use the

    :param base_directory: pass the base directory location
    :param job_name: pass the job name
    :param feed_name: pass the exact feed name that you created on feed ui
    :param environment: 'prod-prime' (production feed), 'prod-failover' (production fail-over feed), 'uat' (uat feed), 'staging' (staging feed)
    :return:

    **In Feed UI**

        Step 1: Go to Feed UI page

        Step 2: Go to Menu on the left side of the screen, Click on -->  Create Feed

        Step 3: Enter the Mandatory information for the following fields:

                **Feed Name** Enter your JobName from Python 	; POC_Sharkfile

                **Enabled**  check box			; True

                **Feed Type** Pick one: Internal or External	; Internal

                **Category** Drop Down List (Choose Entry)	; Outgoing

                **ContentSet** Drop Down List (Choose Entry)	; CCS-DB Internal

                **Working Folder** Enter Path for Python JobName 	; base_directory path

                **Source Folder** Enter Path for Python JobName 	; base_directory path

                **Output Folder** Enter Path for Python Output files; output_dir path

        Example::

            from lib_util import feed_ui_insert
            feed_ui_insert.FeedUiInsert(base_directory, job_name, feed_name, environment)
    """
    def __init__(self,base_directory, job_name, feed_name, environment):
        self.environment = environment
        self.database ='lionfeedA'
        self.sql_user = 'FeedAdminLogin'
        self.sql_password = decrypt_pw("crypted:ptfLrrPwSb8AHnebZAlG-brA8ijg4AebrgQAm0zg1AT7YgtAiG3SgA")
        self.dbg_lines = ''
        self.log_lines = ''
        self.start_date = ''
        self.end_date = ''
        self.log_msg = ''
        self.dbg_msg = ''
        self.status=''
        self.base_directory=base_directory
        self.job_name = job_name
        self.feed_name = feed_name

        # run the functions and add the data
        # self.get_sql_credential()
        self.determine_server()
        self.readfile()
        self.get_parameters()
        self.insert_into_sql()

    def determine_server(self):
        logger = lib_log.Logger()
        try:
            if self.environment.lower() == 'prod-prime':
                self.server = 'lionfeedstga03'
            if self.environment.lower() == 'prod-failover':
                self.server = 'lionfeed-prod'
            if self.environment.lower() == 'uat':
                self.server = 'lionfeed-uat'
            if self.environment.lower() == 'staging':
                self.server = 'lion-staging'
        except Exception:
            logger.write_dbg(utilities.capture_trace())
            raise

    def readfile(self):
        logger = lib_log.Logger()
        try:
            # check for the failure
            if os.path.isfile(os.path.join(self.base_directory, self.job_name + ".dbg")):
                # Failure information goes to dbo.dha_FeedHistory
                dbg_file = cd_open(os.path.join(self.base_directory, self.job_name + ".dbg"), encoding='utf-8')
                self.dbg_lines = dbg_file.readlines()
                self.status = "F"
            else:
                if os.path.isfile(os.path.join(self.base_directory, self.job_name + ".log")):
                    # Log information goes to dha_Log
                    log_file = cd_open(os.path.join(self.base_directory, self.job_name + ".log"), encoding='utf-8')
                    self.log_lines = log_file.readlines()
                    self.status = "S"
                else:
                    # nolog file, nothing to log into  sql server
                    exit()
        except Exception:
            logger.write_dbg(utilities.capture_trace())
            raise

    def get_parameters(self):
        logger = lib_log.Logger()
        try:
            file_name = os.path.join(self.base_directory, self.job_name + ".log")
            if os.path.isfile(file_name):
                self.start_date = datetime.datetime.fromtimestamp(os.path.getctime(file_name))
                self.end_date = datetime.datetime.fromtimestamp(os.path.getmtime(file_name))
            # convert the list to string
            self.log_msg = ("".join(self.log_lines)).encode('ascii', 'ignore')[:5000].replace("'","''")
            self.dbg_msg = ("".join(self.dbg_lines)).encode('ascii', 'ignore')[:5000].replace("'","''")
        except Exception:
            logger.write_dbg(utilities.capture_trace())
            raise

    def insert_into_sql(self):
        logger = lib_log.Logger()
        try:
            sql = "EXECUTE dbo.dha_loghistory_insert_batchdata " \
                  "@start_date='{0}'," \
                  "@end_date='{1}'," \
                  "@log_msg='{2}', " \
                  "@dbg_msg = '{3}' , " \
                  "@status = '{4}'," \
                  "@feed_name = '{5}'" .format(self.start_date, self.end_date, self.log_msg, self.dbg_msg, self.status, self.feed_name)
            connection_string = urllib.parse.quote_plus(
                'DRIVER={SQL Server Native Client 10.0}' +
                ';SERVER=' + self.server +
                ';DATABASE=' + self.database +
                ';UID=' + self.sql_user +
                ';PWD=' + self.sql_password)
            engine = create_engine(
                'mssql+pyodbc:///?odbc_connect=%s' % connection_string)  # sqlalchemy ,convert_unicode=False
            engine.connect()

            t = text(sql).execution_options(autocommit=True)
            engine.execute(t)
        except Exception:
            logger.write_dbg(utilities.capture_trace())
            raise
