#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    SQL.py
    ======
    
    **Naming Convention for "sql.py"**
    
    Please change the name of sql.py file specific to your sql objective.
    
    When generating multiple people queries rename sql.py accordingly i.e. "people_etl.py"
    
    In Batch_Job.py change the import from "import sql" to "import people_etl"
    
    Example::
    
        # import sql
        import people_etl

        # run = sql.Sql(config_file)
        run = people_etl.Sql(config_file)
    
    .. note ::

        Config_file is a path of software.ini file which provides database connection string.
    
    **Common configuration options**

    Example::
    
        class Sql(pyetl.PyEtl):
            def __init__(self, config):
                super(Sql, self).__init__(config)
                # save file parameters
                self.delimeter = b';'                     # default is '|', this changes the delimeter to semicolon
                self.header = int(0)                      # default is int(1) which means include the header in output files
                self.doublequote = False                  # default is True, which means replace the " with ""
                self.coerce_float = False                 # default is False, which means convert sql numeric to python
                                                            float, set it to False if you need exact value from sql server
                self.quoting = csv.QUOTE_ALL              # default is csv.QUOTE_ALL which means quote all values in columns, many feeds
                                                            feeds only quote specific columns. In these cases, use csv.QUOTE_NONE
                self.quote_header = False                 # When "self.quoting = csv.QUOTE_NONE" and you only need the header to be quoted,
                                                            set this flag to True

                self.encoding = 'cp1252'                  # default is 'utf-8-sig' (unicode) this is a file encoding,
                                                            this changes the encoding to 'cp1252' (ASCII LATIN1)

                
                self.empty_df_flag = False                # default is True, It raises an error if any of the dataframes are empty.
                                                            to avoid the failure and create an empty data file, set the flag to False 
                self.convert_float_to_str_flag = False    # default is True, It converts the float to a string and removes trailing 
                                                            zeros, for example 0.76000000 becomes 0.76. Set the flag to False to 
                                                            avoid the conversion 
"""
from __future__ import unicode_literals
from __future__ import print_function

import csv

from . import pyetl
from . import lib_log

logger = lib_log.Logger()


class Sql():
    def __init__(self, config):
        super(Sql, self).__init__(config)
        self.encoding = 'cp1252'
        self.quoting = csv.QUOTE_NONE
        self.header = int(2)
        self.quote_header = True

    def transform(self):
        """

        **Objective**
            This function is used to address the specific needs of the feed which can't address in the pyetl. Each sql.py
            file has this function inherited. Within this function you can implement trim, upper, lower, split, etc. functions
            on any column in the data frame.

        :return:

        Example
        *******

        Example::

            # Upper case conversion
            self.df_name.column_name = self.df_name.column_name.str.upper()

            # Lower case conversion
            self.df_name.column_name = self.df_name.column_name.str.lower()

            # Ltrim + Rtrim
            self.df_name.column_name = self.df_name.column_name.str.strip()

            # remove leading zero from decimal or numeric
            self.df_name.column_name = self.df_name.column_name.apply(self.transform_func.remove_leading_decimal_zero)

            # quote column
            self.df_name.column_name = self.df_name.column_name.apply(self.transform_func.quote_column)
            
            # remove ASCII control chars
            self.df_name.column_name = self.df_name.column_name.apply(self.transform_func.remove_ascii_control_chars)

            # replace unicode with ASCII
            self.df_name.column_name = self.df_name.column_name.apply(self.transform_func.replace_unicode_with_ascii)

            # remove non ASCII (non ASCII unicodes)
            self.df_name.column_name = self.df_name.column_name.apply(self.transform_func.remove_non_ascii)

            # ltrim + rtrim  ASCII control char
            self.df_name.column_name = self.df_name.column_name.apply(self.transform_func.strip_controlchar)
            
        ..More information on pandas functions can be found at
            http://pandas.pydata.org/pandas-docs/stable/text.html    
        """
        pass
