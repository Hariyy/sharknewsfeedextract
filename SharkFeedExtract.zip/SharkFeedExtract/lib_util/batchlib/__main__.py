
import sys
import os
import traceback

def write_dbg(data):
    main_py_file = None
    for filename, line, function, code in traceback.extract_stack():
        # However, for the specific case of PyScrypter, the main becomes remserver.py
        # so we investigate the stack and keep the first unamed module which will be ours
        # because of this, we cannot directly use inspect.stack()[-1][1]
        if os.path.split(filename)[1].lower()=='remserver.py':
            continue
        if function.lower()=='<module>':
            if filename == "<string>":
                continue
        main_py_file = filename
        break
    # Could not get the file???? Console print and default to current file
    if main_py_file is None:
        main_py_file = __file__
    # manage the .pyz case
    if ".pyz" in main_py_file:
        main_py_file = main_py_file.split(".pyz")[0]
    dbg_filename = main_py_file.replace('.py','')+'.dbg'
    with open(dbg_filename, 'a') as logfile:
        logfile.write(data)

try:
    from batch_lib import batch_lib
except ImportError as e:
    write_dbg('Import error has been raised: ' + str(e))
    raise e
if __name__ == '__main__':
    if len(sys.argv) == 2 and sys.argv[1] == "--version":
        print("batch_lib " + batch_lib.__version__)
    else:
        batch_lib.main()
    