"""
    Functions
    =========

    All these functions are protected from any error.

    In case of any error functions will return False and informations about error

    will be printed inside the dbg file.

    How to use them
    ***************

    You only need to have imported them inside your script::

        from batch_lib.functions import *

    .. note ::

        They are also available with::

            from batch_lib import *

        This line doesn't only import :mod:`batch_lib.functions`, it also import :mod:`batch_lib.decorators` and some other usefull tools when working with batch.

    Functions
    *********

"""

from __future__ import division, print_function, unicode_literals, absolute_import

import os
import shutil
from datetime import datetime, date
import tempfile
import subprocess
import shlex
import inspect
import threading

from functools import wraps

from .environment import ENV
from .script import ERROR

try:
    from dateutil.relativedelta import relativedelta
    from dateutil.parser import parse as timeparse
except ImportError:
    ENV._mutex.acquire()
    print("WARNING: dateutil is not installed. waittime cannot works !")
    ENV._mutex.release()

try:
    # Import win32api modules needed to interconnect with windows.
    import win32file
    import win32event
    import win32con
except ImportError:
    ENV._mutex.acquire()
    print("WARNING: win32api is not installed. waitflag cannot works !")
    ENV._mutex.release()

import time
import sys


# all the functions listed here will be importable by job with
# from batch import * (or from batch.functions import *)

__all__ = [
    # Logging functions
    "log", "dbg", "logdate", "logtime", "logdatetime",
    # Execution
    "call",
    # file related
    "remove", "delete", "copy", "makedirs", "mkdir", "removedirs", "rmtree", "rmdir", "exists",
    "delete_before", "delete_empty_folder", "pathjoin",
    # Date related,
    "today","launch_datetime","launch_day",
    # Misc
    "waittime", "waitms", "openfile", "createflag", "waitflag"
    ]


def __basename():
    """
        Internal function to get the basename for standart log and dbg files
    """
    base, _ = os.path.splitext(sys.modules[ENV._script.func.__module__].__file__)
    return base

def __get_alternate_name():
    if ENV._log_alternate_file:
        filename = __basename()
        basename = os.path.split(filename)[1]
        dirname = os.path.split(filename)[0]
        date_str = time.strftime("%Y%m%d")
        return os.path.join(dirname, "{}_{}".format(date_str, basename))
    else:
        return __basename()

def __log(msg):
    """
        Internal functions to write base log
    """
    ENV._mutex.acquire()
    filename = __get_alternate_name() + ".log"
    with open(filename, 'a') as output:
        output.write(msg)
        output.write("\n")
    print(msg)
    sys.stdout.flush()
    ENV._mutex.release()
    return msg

def __dbg(msg):
    """
        Internal functions to write base dbg
    """
    ENV._mutex.acquire()
    filename = __get_alternate_name() + ".dbg"
    with open(filename, 'a') as output:
        output.write(msg)
        output.write("\n")
    sys.stdout.flush()
    ENV._mutex.release()
    return msg

def __format_log_or_dbg(*args, **kwargs):
    """
        Internal function to format msg contained in log and dbg
        Handle (%time%, %date%, %datetime%, transform args list,
        and transform kwargs.
    """
    time = datetime.time(datetime.now()).isoformat()[:8]
    str_date = date.today().strftime("%d/%m/%Y")
    date_time = datetime.now().isoformat()
    msg = []
    for item in args:
        msg.append(str(item))
    for key, value in kwargs.items():
        msg.append("{}={}".format(key, value))
    msg = "\t".join(msg)
    msg = msg.replace("%time%", time)
    msg = msg.replace("%date%", str_date)
    msg = msg.replace("%datetime%", date_time)
    return msg


# This is a decorator for batch functions
def batch_function(func):
    """
        .. warning::
            This decorator is for devellopers ! All function exposed to be a batch one, should be decorated with this decorator.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            # Inspect in order to give correct args to functions
            accept = inspect.getargspec(func)
            if accept.varargs and accept.keywords:
                result = func(*args, **kwargs)
            elif not accept.varargs and accept.keywords:
                result = func(*args, **kwargs)
            elif accept.varargs and not accept.keywords:
                result = func(*args)
            elif not accept.args:
                result = func()
            elif len(args) == len(accept.args):
                result = func(*args)
            else:
                data = {}
                for key in accept.args[len(args):]:
                    if key in kwargs:
                        data.update({key: kwargs[key]})
                result = func(*args, **data)
            return result
        except Exception as exception:
            # If an Exception occures
            # make a clean dbg saying wich function have make the error
            msg = "%datetime%\nExeption on {}(*{}, **{})\n{}:\n{}\n".format(func.__name__,
                                                         args, kwargs,
                                                         type(exception), exception)
            __dbg(__format_log_or_dbg(msg))
            raise exception
    return wrapper

@batch_function
def log(*args, **kwargs):
    """
        log(msg, [othermsg, ...])

        Example::

            log("my log message")
            will write "my log message" inside filename.log (launched from script filename.py)

            log("my message1", "my message2")
            will write "my message1    my message2" in logfile

            log("%date% message")
            will write date (in DD/MM/YYYY format) + message in logfile

        Shortcut::

            %date% => will give current date in DD/MM/YYYY format
            %datetime% => will be converted to datetime in isoformat
            %time% => will be converted to time in isoformat (without milliseconds)
    """
    return __log(__format_log_or_dbg(*args, **kwargs))

@batch_function
def dbg(*args, **kwargs):
    """
        dbg(msg, [othermsg [, ...]])

        Same as log but write in filename.dbg

        And automatically %datetime% and go to next line before writing dbg.
    """
    args = list(args)
    args.insert(0, "%datetime%")
    args[1] ="\n" + args[1]
    msg = __format_log_or_dbg(*args, **kwargs)
    return __dbg(msg)

@batch_function
def logdate(*args, **kwargs):
    """
        logdate(msg1, [,msg2 [,...]])

        logdate("my message") is same as log("%date%", "my message").
    """
    l = list(args)
    l.insert(0,"%date%")
    l = tuple(l)
    return __log(__format_log_or_dbg(*l, **kwargs))

@batch_function
def logtime(*args, **kwargs):
    """
        logtime(msg [,msg2 [,...]])

        logtime("my message") is same as log("%time%", "my message").
    """
    l = list(args)
    l.insert(0,"%time%")
    l = tuple(l)
    return __log(__format_log_or_dbg(*l, **kwargs))

@batch_function
def logdatetime(*args, **kwargs):
    """
        logdatetime(msg1 [, msg2 ...])

        logdatetime("my message") is same as log("%datetime%", "my message").
    """
    l = list(args)
    l.insert(0,"%datetime%")
    l = tuple(l)
    return __log(__format_log_or_dbg(*l, **kwargs))

@batch_function
def call(cmd, stop=False, success_codes=[0], success_if_no_stderr=[1]):
    """
        call(cmd, stop=False, success_codes=[0], success_if_no_stderr=[1])

        Call launch a cmd in a subprocess using the shell (same as `cmd /C`).
        Wait the subprocess to terminate before returning.

        if ``stop=True``, the script will end in error state, when reaching an error.

        else if ``stop=False`` (default) the script will continue even if there is an error with the call.

        In case of exception, (critical problem) the script will end in error state
        whatever stop is True or False.

        .. note::

            About ``sucess_codes`` and ``sucess_if_no_stderr``

            ``sucess_codes`` is a list of return code, that are considered like successful results,
            whatever is the content of stderr output, it will be considered as a success.

            ``sucess_if_no_stderr`` is a list of return code, that are considered like successful results, only if the
            stderr output is empty.

        .. note::

            If return_code != 0 or stderr is not empty,

            => Will be interpreted as an error.

            Then if stop=True, the script will end there, and result in an error status.

            If stop=False, the script will continue, BUT we consider that the script at end
            will be in a error state. And we print the error information in DBG, because erros should not exist
            and we need to show them to the world.

        Example::

            call("xcopy myfile_src my_file_dest")

            call("rundll32.exe ....")

        The function will return a tuple::

            (return_code, stdout, stderr)

    """
    # Two file object to temporarly save stdout and stderr
    # Do not open in binary mode otherwise we have to write bytes (encoded string) in python 3
    out = tempfile.SpooledTemporaryFile(mode='w')
    err = tempfile.SpooledTemporaryFile(mode='w')

    # Spawn the subprocess (and PIPE stdout and stderr)
    result = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

    def duplicate_stream(fd, std, tmp):
        """
            This function will be spawned in thread.
            The stream will go to a first output 'std' (which is sys.stdout or sys.stderr)
                In this first case we prefix it with the script name (to be more user friendly)
            And we duplicate the stream to a tmp file object, which give us the power to give back to user
            what was the result of the call.
        """
        # Avoid infinite loop when reading and writing in stdout with python3 as we iter on readline
        for data in fd.readlines():
            try:
                # In python 3, we can't perform str operations on bytes
                # so convert data to unicode before replacing unicode strings
                data = data.decode().replace(os.linesep, '\n')
                ENV._mutex.acquire()
                std.write("{} + {}".format(ENV._script.name, data))
                print(data, end='', file=tmp)
                # to avoid wxWidgets to buffer.
                std.flush()
                ENV._mutex.release()
            except Exception as e:
                print(str(e))
                raise
            

    # Launch the Thread to duplicate the stream
    stdout = threading.Thread(target=duplicate_stream, args=(result.stdout, sys.stdout, out))
    stderr = threading.Thread(target=duplicate_stream, args=(result.stderr, sys.stderr, err))
    stdout.start()
    stderr.start()

    # Blocking, we wait the end of the call (and of the threads)
    result.wait()
    stdout.join()
    stderr.join()

    # Retrieving data from the two temporary file object
    out.seek(0)
    err.seek(0)
    out_data = "".join(out.read())
    err_data = "".join(err.read())

    returncode = result.returncode
    if not returncode in success_codes and (not returncode in success_if_no_stderr or err_data != ""):
        ENV._status = ERROR
        msg = "CALL {}\nRESULT:{}\nSTDERR:\n{}\n".format(cmd, returncode, err_data)
        dbg(msg)
        if stop:
            raise Exception(msg)
    return (returncode, out_data, err_data)

"""
    File related functions
"""
# Remove
@batch_function
def remove(filename):
    """
        remove(filename)

        Example::

            remove("filename.log")

            remove file if it exists. (Won't output anything if file is not present)
            You ask to ensure filename doesn't exists, then removing a file that doesn't exists
            is not an error.
    """
    if os.path.exists(filename):
        os.remove(filename)

# delete (alias for remove, delete was the name, in the old batch...)
delete = remove

@batch_function
def delete_empty_folder(path):
    """
        delete_empty_folder(path)

        This function walk through all the ``path`` tree, and remove all the empty folder it can found.

        Deleting a non existing path, will not fails.
    """
    if not os.path.isdir(path):
        return

    # remove empty subfolders
    files = os.listdir(path)
    if len(files):
        for f in files:
            fullpath = os.path.join(path, f)
            if os.path.isdir(fullpath):
                delete_empty_folder(fullpath)

    # If folder empty, delete it
    files = os.listdir(path)
    if len(files) == 0:
        print("Removing empty folder:", path)
        rmdir(path)

@batch_function
def delete_before(folder, **kwargs):
    """
        delete_before(folder, [year, years, month, months, weeks, day, days, hour, hours, minute, minutes, second, seconds])

        .. note::

            Arguments work similarly as the :mod:`batch_lib.functions.waittime` function.

        Examples::

            delete_before("temp", days=-1) # Will also remove files, older than one days.
            delete_before("temp", months=-1) # Will remove files, older than one month.
            delete_before("temp", day=1) # Will remove all the files older than the 1st day of the current month.
            delete_before("temp", seconds=1) # Will remove all the files older than one seconds in the future (then it will remove all the files)

        .. note::

            ``delete_before`` don't remove the empty folder, it only cares about files.
            If you want to clean the empty folders, take a look on :mod:`batch_lib.functions.delete_empty_folder`
    """
    max_date = launch_datetime + relativedelta(**kwargs)
    for (root, dirs, files) in os.walk(folder):
        for file in files:
            filepath = os.path.join(root, file)
            filedate = datetime.fromtimestamp(os.path.getmtime(filepath))
            if filedate < max_date:
                delete(filepath)

@batch_function
def copy(src, dest):
    """
        copy(src, dest)

        Example::

            copy("my_file_src.txt", "my_file_dest.txt")

        .. note::

            copy("my_file_src.txt", "my_directory")

            same as copy("my_file_src.txt", "my_directory/my_file_src.txt")
    """
    return shutil.copyfile(src, dest)

@batch_function
def copytree(src, dest):
    """
        copytree(src, dest)

        Copy a folder and it's content to a new folder "dest".

        If the destination directory already exist, operation cannot result successfully.

        Function will return False, and dbg will receive informations.
    """
    return shutil.copytree(src, dest)

@batch_function
def makedirs(path):
    """
        makedirs(path)

        Recursive directory creation function.

        Like mkdir(), but makes all intermediate-level directories needed to contain the leaf directory.

        If directory already exist, script will fails.
    """
    return os.makedirs(path)

@batch_function
def mkdir(path):
    """
        mkdir(path)

        Create a directory named path.

        If directory already exist, it won't fails.
    """
    if not exists(path):
        return os.mkdir(path)

@batch_function
def removedirs(path):
    """
        removedirs(path)

        Remove directories recursively.
        Works like :mod:`batch_lib.functions.rmdir` except that, if the leaf directory is successfully removed,
        :mod:`batch_lib.functions.removedirs` tries to successively remove every parent directory mentioned in path
        until an error is raised (which is ignored, because it generally means that a parent directory is not empty).
        For example, removedirs('foo/bar/baz') will first remove the directory 'foo/bar/baz', and then remove 'foo/bar' and
        'foo' if they are empty. Raises `OSError` if the leaf directory could not be successfully removed.
    """
    return os.removedirs(path)

@batch_function
def rmtree(path, ignore_errors=False):
    """
        rmtree(path[, ignore_errors])

        Delete an entire directory tree; ``path`` must point to a directory (but not a symbolic link to a directory).
        If ``ignore_errors`` is true, errors resulting from failed removals will be ignored;
        if false or omitted, they raise an exception.
    """
    return shutil.rmtree(path, ignore_errors)

@batch_function
def rmdir(path):
    """
        rmdir(path)

        Remove a single dir.

        If directory is not empty, script will fails.
    """
    return os.rmdir(path)

@batch_function
def exists(path):
    """
        exists(path)

        return True if path exists, False if not
    """
    return os.path.exists(path)


@batch_function
def pathjoin(*args):
    """
        pathjoin(part1[, part2[, part3 [,...]]])

        Transform the args into a correct pathname.

        Example::

            pathjoin("C:\\\\a_source", "my", "path")

        will return "C:\\a_source\\my\\path"

        .. note::

            This function is os independent.

            (Under windows '\\' will be used and under linux or mac os '/' will be used)
    """
    return os.path.join(*args)

"""
    MISC
"""

def today():
    """
        return today date in string format YYYYMMDD
    """
    return date.today().strftime("%Y%m%d")

# Store the launch time of the script
launch_datetime = datetime.now()
launch_day = date.today()

@batch_function
def waittime(wait="", **kwargs):
    """
        waittime(wait="", [year, years, month, months, weeks, day, days, hour, hours, minute, minutes, second, seconds])

        Wait for a relative time from launch

        hour=12 => Wait for 12h the day of launch

        hours=1 => Wait for 1h after the launch

        minutes=10 => Wait for 10minutes after the launch

        EXAMPLE::

            If the script is launched at 6:00

            waittime(hours=1) => wait 7:00

            waittime(hour=1) => wait 1:00 (Already passed! => DBG)

            waittime(days=1, hour=1) => wait tommorrow at 1:00

            waittime(minutes=10) => wait 6:10

            waittime(hours=1, minutes=10) => wait 7:10

        Second ways to use this functions::

            waittime("18:01") => wait 18h01

            waittime("18h01m34s") => 18:01:34

            waittime("03m42s", hours=1) => Wait one hour after the launch at 3m42s
            <=>
            waittime(hours=1, minute=3, second=42)

        This function return `False` if you ask to wait a time in the past.

        In all other case, after having wait, it return `True`

        .. warning::
            This function need ``dateutil`` to be installed.
    """
    if wait:
        launch = timeparse(wait)
    else:
        launch = launch_datetime
    wait_date = launch + relativedelta(**kwargs)
    time_to_wait = wait_date - datetime.now()
    if(time_to_wait.total_seconds() < 0):
        dbg("waittime", "You asked me to wait", wait_date, "but it is already", datetime.now())
        return False
    else:
        time.sleep(time_to_wait.total_seconds())
        return True

@batch_function
def waitms(ms):
    """
        waitms(ms)

        Wait the number of milliseconds passed in args

        Example::

            wait(1000) => Wait 1sec.
    """
    time.sleep(ms / 1000)

@batch_function
def openfile(file):
    """
        openfile(file)

        Open a file with notepad.

        .. warning::

            This function is blocking until notepad is closed !

        Same as `call("notepad filename.txt")`
    """
    return call("notepad {}".format(file))

@batch_function
def createflag(filename, content):
    """
        createflag(filename, content)

        Create a file named filename.

        And write content inside it

        Example::

                createflag("test.flag", "This is a test")

                Will create a new file, "test.flag", containing the content "This is a test".
    """
    with open(filename, 'w') as f:
        f.write(content)

@batch_function
def waitflag(filename, time_limit=None, **kwargs):
    """
        waitflag(filename, time_limit=None, [year, years, month, months, weeks, day, days, hour, hours, minute, minutes, second, seconds])

        Wait that a file "filename" exists.

        This function is CPU safe. (It's not going to put it at 100%)


        .. note::

            Arguments work similarly as the :mod:`batch_lib.functions.waittime` function.

        Timeout examples::

            waitflag("my_file.flag", seconds=300) # Wait the file my_file.flag or 5minutes at max
            waitflag("my_file.flag", seconds=3600) # Wait the file or one hour.
            waitflag("my_file.flag", hours=1) # Wait also the file or one hour
            waitflag("my_file.flag", time_limit="15:30") # wait the file or 15:30
            waitflag("my_file.flag", time_limit="3m42s", hours=1) # Wait the file or one hour after the launch, at 3min42sec precisely

        .. note::

            When waitflag, will timeout, an information will be logged into the .dbg file.

        .. note::

            This function return ``True`` when the file is present, and return ``False`` when the script continue
            because of timeout or time_limit

        .. warning::

            Require ``win32api`` and ``dateutil``
    """
    start = datetime.now()

    if time_limit:
        launch = timeparse(time_limit)
    else:
        launch = start
    wait_date = launch + relativedelta(**kwargs)

    if os.path.exists(filename):
        # No need to wait, file is already here
        return
    # We should monitor the folder where file will be created
    path_to_watch = os.path.abspath(os.path.dirname(filename))
    # for more information about this code
    # see: http://stackoverflow.com/questions/6710676/python-waiting-for-a-file-to-reach-a-size-limit-in-a-cpu-friendly-manner
    change_handle = win32file.FindFirstChangeNotification(
        path_to_watch,
        0,
        win32con.FILE_NOTIFY_CHANGE_FILE_NAME
    )
    try:
        while True:
            result = win32event.WaitForSingleObject(change_handle, 1000)
            if os.path.exists(filename):
                return True
            if time_limit or kwargs:
                if datetime.now() > wait_date:
                    dbg("waitflag {} reached timeout".format(filename))
                    return False
            win32file.FindNextChangeNotification(change_handle)
    finally:
        win32file.FindCloseChangeNotification(change_handle)

