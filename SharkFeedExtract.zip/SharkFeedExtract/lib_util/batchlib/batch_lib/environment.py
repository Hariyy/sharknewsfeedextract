"""
    Environment
    ===========

    When you do this::

        from batch_lib import *

    You are importing a special object ``ENV``.

    This object is usefull when you need to set vars and propagate them from one script to another.

    Like example are better than words, please take a look at these examples.

    Example 1 (define vars)::

        from batch_lib import *

        @init
        def configure():
            ENV.define("soft", "C:\\\\my\\\\path\\\\to\\\\soft\\\\folder")
            ENV.define("backup", "C:\\\\my\\\\path\\\\to\\\\backup")

        @script
        def first_job():
            log(backup)
            # will log "C:\\my\\path\\to\\backup"

            createflag(pathjoin(backup, "test.flag"), "test")
            # will create a file ``test.flag`` at path ``C:\\my\\path\\to\\backup\\test.flag`` containing ``test``

    .. warning::

        It's forbidden to redefine a value already set!

        It will outcome into an Exception (=> Script will end there, and status will be "error")
        => The following scripts with @wait or @wait_error will be triggered but not the one with @wait_success


    .. warning::

        Defining vars in parallel scripts, make the values for following scripts unpredictable.

        The ``example 2``, should make you understand.


    Example 2 ::

        from batch_lib import *

        @init
        def configure():
            log("start")

        @script
        def first_job():
            ENV.define("last", "first_job")
            my_long_operation()

        @script
        def second_job():
            ENV.define("last", "second_job")
            my_other_long_operation()

        @wait(first_job, second_job)
        def finish_line():
            log(last) # will output wich script at end in last


    .. note ::

        ENV is also used, by plugins and some core functions. If you are a developper
        and want to start a new plugins. Please see ``src\environment.py`` which will
        be more documented for your purpose.

    ``ENV.max_workers_numbers``
    ***************************

    By default Batch spawn as many process as needed (one process by script that is ready to be launched).
    But Batch had been designed with the possibility to limit this numbers of process.
    That's mean ever if they are 10 scripts ready to run, you can limit this to 5.

    This is really easy to use, you just have to set ``ENV.max_workers_numbers``

    0 and negative values, implies unlimited number.

    .. warning ::

        This feature could be great but is also very dangerous !

        If you have scripts that are waiting something with function like waitflag, (it implies the process is still their)
        And this flag is generated outside, but won't be generated if a parallel scripts is not executed.
        If you have given only one max workers, you could be blocked for life here.

"""

from __future__ import absolute_import

import sys
if sys.version_info[0] == 2:
    import cPickle as pickle
if sys.version_info[0] == 3:
    import pickle
import multiprocessing

__all__ = ["ENV"]

class Environment(object):
    """
        Do NOT import this class, it's intended to only have one
        instance "ENV"
        This object should contains all environment variables for batch.

        When the script manager spawn a new process, it use the method ``dumps``,
        and then pass the result to ``loads`` on the children process.

        When script end, ENV is also dumped and loaded in order to store ENV modification
        for other children.

        .. note::

            ENV is dumped into queue with the script, when script is allowed to be executed.

        .. warning::

            If you have two script running at same time, updating the same value in ENV,
            this is the values from the script which end at last, that will be keeped
            for children.
    """
    def __init__(self):
        # mutex for stdout.
        self._mutex = multiprocessing.Lock()
        # The current script running (exported in workers)
        self._script = None
        # Vars defined by user with define()
        self._user_vars = {}
        # The scripts status, used to propagate from script manager to workers
        # all the script status
        self._scripts_status = {}

        # This methods is set there from execute.py
        self._get_scripts = None

        # max number of workers (<=0 => Unlimited)
        self.max_workers_numbers = 0

        # do we log in an alternate file ? [DATE]_script.log
        self._log_alternate_file = False


    def dumps(self):
        """
            When passing env to multiprocess
            We pass it as a string in queue with this mehod
        """
        from .compatibility import function_attribute
        # Mutex and script are not serializable
        mutex = self._mutex
        self._mutex = None
        script = self._script
        self._script = None

        if script:
            # get modified _user_vars
            for key in self._user_vars.keys():
                if script.func:
                    func_globals = function_attribute(script.func, '__globals__')
                    if key in func_globals:
                        self._user_vars[key] = func_globals[key]

        # Update the scripts_status before dumps
        if self._get_scripts:
            s1, s2, s3 = self._get_scripts()
            scripts = s1 + s2 + s3
            for script in scripts:
                self._scripts_status[script.import_info()] = script.status
            get_scripts = self._get_scripts
            self._get_scripts = None

        # pickle
        str = pickle.dumps(self.__dict__)

        # reset values not serialized in ENV
        self._mutex = mutex
        self._script = script
        self._get_scripts = get_scripts

        return str

    def loads(self, str, mutex=None, script=None, status=False):
        """
            When a function is called, it's environment is loaded
            with this function (str) is the output of self.dumps
            that have been passed in queue

            if ``status`` is True, the script status will be updated.
            This is done when we loads on worker, but should not be done on return from worker.
        """
        from .compatibility import function_attribute
        # save the current vars that are not in serialization (and would be overwrited)
        if mutex == None:
            mutex = self._mutex
        if script == None:
            script = self._script
        get_scripts = self._get_scripts

        # unserialize
        # We need to update self._user_vars
        _user_vars = self._user_vars
        self.__dict__.update(pickle.loads(str))
        _user_vars.update(self._user_vars)
        self._user_vars = _user_vars

        # replace the saved vars
        self._mutex = mutex
        self._script = script
        self._get_scripts = get_scripts

        # Put script status to all scripts in worker
        if self._get_scripts and status:
            s1, s2, s3 = self._get_scripts()
            scripts = s1 + s2 + s3
            for script in scripts:
                if script.import_info() in self._scripts_status:
                    script.status = self._scripts_status[script.import_info()]

        if self._script and self._script.func:
            # inject _user_vars into script
            func_globals = function_attribute(self._script.func, '__globals__')
            for key in self._user_vars.keys():
                func_globals[key] = self._user_vars[key]

    def define(self, var_name, value, _log=True):
        """
            Declare a variable name with value.
            This vars will be injected in global env of each script
        """
        from .compatibility import function_attribute
        self._user_vars[var_name] = value
        if self._script and self._script.func:
            function_attribute(self._script.func, '__globals__')[var_name] = value

        if _log:
            # Automatic log of the defined values
            from .functions import log
            log("- {}={}".format(var_name, value))

ENV = Environment()