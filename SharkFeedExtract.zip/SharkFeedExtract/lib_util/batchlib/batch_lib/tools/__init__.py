"""
    Tools
    =====

    Batch tools are available from the command line with::

        python batch.py <tool> <args>

    You could always know what modules are available with::

        python batch.py -h

    And you could have help on each tools (and its arguments) by calling::

        python batch.py <tool> -h

    Exe
    ***

        .. automodule:: batch_lib.tools.exe

    Init
    ****

        .. automodule:: batch_lib.tools.init

    Translate
    *********

        .. automodule:: batch_lib.tools.translate

    Gui
    ***

        .. automodule:: batch_lib.tools.gui

    Graph
    *****

        .. automodule:: batch_lib.tools.graph

"""
