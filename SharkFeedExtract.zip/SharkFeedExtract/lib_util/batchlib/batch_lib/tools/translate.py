"""
    Command line::

        python batch.py translate script.cmd

    This tool translate old .cmd files to new .py script.

    .. note::

        This tool fails if something is not correct in the .cmd file.

        For example, it will fails if you use a variable that have not been set.

"""

from __future__ import print_function, unicode_literals, absolute_import
import os
import re
import shlex

from .init import Init

class Translate:
    """
        Convert the all .cmd script files to new .py script using batch
    """
    def __init__(self, log=print, dbg=print):
        self.log = log
        self.dbg = dbg
        self.vars = {}
        # We use the init class tool to append head and footer mandatory part.
        self.init = Init()
        # transformation handled (left values must be lowered, right values are case sensitive).
        self.default_transform = {
            "log": "log",
            "logdate": "logdate",
            "logtime": "logtime",
            "exec": "call",
            "delete": "delete",
            "waitfor": "waitflag"
        }
        self.multi_param_transform = {
            "createflag": "createflag",
            "copy": "copy"
        }

    def parser(self, subparsers, name):
        """
            Add the convert tool to subparser from main
        """
        parser = subparsers.add_parser(name, help='Convert a .cmd script to .py one')
        parser.add_argument('script', type=str, help="pathname to .cmd file (a new .py will be created next to it)")

    def execute(self, args):
        """
            The tool had been called from command line
        """
        self.go(args.script)

    def go(self, script_path):
        """
            Make the work
        """
        base, ext = os.path.splitext(script_path)
        if ext != ".cmd":
            self.dbg("Input file is not a .cmd one")
            return

        cmd_file = base + ".cmd"
        py_file = base + ".py"

        if not os.path.exists(cmd_file):
            self.dbg("{} doesn't exist ! Cannot convert it.".format(cmd_file))
            return

        if os.path.exists(py_file):
            self.dbg("{} already exist ! A translate would overide this existing file".format(py_file))
            return

        self.base = os.path.basename(base)

        # We read the script .cmd a first time to extract all the SET instruction
        with open(cmd_file, 'r') as cmd:
            for line in cmd:
                line = line.split()
                if len(line) > 2 and line[0].lower() == "set":
                    key_name = line[1].replace("$", "")
                    if line[2].lower() == "today()":
                        value = "today()"
                    else:
                        value = self.clean_arg(" ".join(line[2:]))
                    if key_name in self.vars:
                        self.dbg("${} is set two time ! Cannot translate this kind of things.".format(key_name))
                        return
                    self.vars[key_name] = value

        try:
            with open(py_file, 'w') as script:
                self.init.head(script)
                self.write_conf(script)
                self.convert(cmd_file, script)
        except Exception as e:
            os.remove(py_file)
            self.dbg("{}".format(e))

    def clean_arg(self, arg):
        """
            Transform $A to " + A + "
            Escape '\'
            Ensure there is quote around arg
        """
        # Ensure args are quoted
        if arg[0] != '"':
            arg = '"' + arg + '"'

        # Transform |"my args" (comment)| into |"my args"|
        if arg[-1:] != '"':
            arg = arg[:arg.find('"',1)+1]

        # ensure that used vars are defined
        find = re.findall(r'\$([a-zA-Z])', arg)
        if find:
            for key in find:
                if not key in self.vars.keys():
                    raise Exception("Use a variable not defined ! (${})".format(key))

        # Transform $A into " + a + "
        arg = re.sub(r'\$([a-zA-Z])', r'" + \1 + "', arg)

        # To ensure readibility transform ("" + A + "dfdsfds") => (A + "dfdsdfs")
        # and ("..." + A + "") => ("..." + A)
        if arg[:5] == '"" + ':
            arg = arg[5:]
        if arg[-5:] == ' + ""':
            arg = arg[:-5]

        # escape backslash
        arg = arg.replace("\\", "\\\\")

        # replace "" by \"
        if len(arg) > 3:
            arg = arg.replace("\"\"", '\\"')

        return arg

    def write_conf(self, new):
        """
            Conf are global variables that were written as "set $A value" before.
            After have reading the whole script searching this values we append them
            At the top of our new script
        """
        new.write("\n@init\n")
        tab = "    "
        new.write('def section_init():\n')
        for key, value in self.vars.items():
            new.write(tab)
            new.write("ENV.define(\"{}\", {})\n".format(key, value))
        new.write("\n\n")

    def convert(self, input_file, new):
        """
            Convert a .cmd file to a .py file
        """
        with open(input_file, 'r') as original:
            # script numbers
            n = 0
            n_name = "section_0"
            wait = 0
            wait_name = "section_0"
            tab = "    "
            tab_count = 0

            for line in original:
                line = line.split()

                # we keep line jump for readability
                if len(line) == 0:
                    new.write(tab * tab_count)
                    new.write("\n")
                    continue

                # convert comment
                if line[0][:9] != "//SECTION" and line[0][:9] != "//REPRISE" and line[0][:2] == "//":
                    new.write(tab * tab_count)
                    comment = "# "+ line[0][2:] + " ".join(line[1:])
                    new.write(comment.replace("\\","\\\\"))
                    new.write("\n")
                    continue

                # //SECTION
                if line[0][:9] == "//SECTION":
                    section = " ".join(line).split(';')

                    # if tab_count == 1 this is not the first script
                    if tab_count == 1:
                        new.write("\n")
                        new.write("@wait({})\n".format(wait_name))
                        n += 1
                    else:
                        tab_count = 1
                        new.write("\n@script\n")

                    wait_name = "{}".format(section[1])
                    new.write("def {}():\n".format(wait_name))
                    n_name = wait_name
                    n += 1
                    wait = n

                    # Put the section description into docstring
                    new.write(tab * tab_count)
                    new.write('"""\n')
                    new.write(tab * (tab_count + 1))
                    new.write(section[2])
                    new.write("\n")
                    new.write(tab * tab_count)
                    new.write('"""\n')
                    continue

                # First script
                if tab_count == 0:
                    new.write("\n@script\n")
                    new.write("def {}():\n".format(n_name))
                    tab_count = 1

                # Jump out winexec section
                if n != wait and line[0].lower() != "winexec":
                    n += 1
                    n_name = "section_{}".format(n)
                    new.write("@wait({})\n".format(wait_name))
                    new.write("def {}():\n".format(n_name))
                    wait = n
                    wait_name = n_name

                # convert functions
                if line[0].lower() in self.default_transform:
                    new.write(tab * tab_count)
                    new.write(self.default_transform[line[0].lower()] + "(" + self.clean_arg(" ".join(line[1:])))
                    new.write(")\n")
                    continue

                # multi args functions
                if line[0].lower() in self.multi_param_transform.keys():
                    new.write(tab * tab_count)
                    args = " ".join(line[1:])
                    args = shlex.split(args.replace("\\","/"))
                    args = map(os.path.normpath, args)
                    new.write(self.multi_param_transform[line[0].lower()] + "(" + ", ".join(map(self.clean_arg, args)))
                    new.write(")\n")
                    continue

                # waittime is special, because sometimes is:
                # WaitTime EVERYDAY 15:30:00
                # And could also be:
                # WaitTime 15:30:30  (EVERYDAY was optional and not used, then we now remove it)
                if line[0].lower() == "waittime":
                    # Search where the time is
                    if len(line) > 2:
                        time = line[2].split(':')
                    else:
                        time = line[1].split(':')
                    new.write(tab * tab_count)
                    new.write("waittime(hour={}, minute={}, second={})\n".format(*time))
                    continue

                # Winexec was a command that detach the process
                # Now we create a parallel script
                if line[0].lower() == "winexec":
                    new.write("\n")
                    new.write("@wait({})\n".format(wait_name))
                    n += 1
                    n_name = "section_{}".format(n)
                    new.write("def {}():\n".format(n_name))
                    new.write(tab * tab_count)
                    new.write("logtime(\"START call(" + self.clean_arg(" ".join(line[1:])).replace("\"","\\\"") + ")\")\n")
                    new.write(tab * tab_count)
                    new.write("call(" + self.clean_arg(" ".join(line[1:])))
                    new.write(")\n")
                    new.write(tab * tab_count)
                    new.write("logtime(\"END call(" + self.clean_arg(" ".join(line[1:])).replace("\"","\\\"") + ")\")\n")
                    new.write(tab * tab_count)
                    new.write("\n")
                    continue

                # //REPRISE
                if line[0][:9] == "//REPRISE":
                    new.write(tab * tab_count)
                    reprise = " ".join(line).split(';')
                    new.write("# REPRISE ")
                    line = reprise[1].split(' ')
                    if line[0].lower() in self.default_transform:
                        new.write(self.default_transform[line[0].lower()] + "(" + self.clean_arg(" ".join(line[1:])))
                        new.write(")")
                    elif line[0].lower() in ["createflag"]:
                        args = shlex.split(" ".join(line[1:]))
                        new.write("createflag" + "(" + ", ".join(map(self.clean_arg, args)))
                        new.write(")")
                    else:
                        new.write(" ".join(line[1:]))
                    new.write("\n")
                    continue

                # "Set" have already be handled by a first pass
                if line[0].lower() == "set":
                    continue

                # we don't know how to handle this line
                self.dbg("Can't handle this line :")
                self.dbg(" ".join(line))
                new.write(tab * tab_count)
                new.write("#")
                new.write(" ".join(line).replace("\\", "\\\\"))
                new.write("\n")

