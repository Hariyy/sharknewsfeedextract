from __future__ import print_function, unicode_literals, absolute_import
import sys
try:
    import wx
    from wx.lib.wordwrap import wordwrap
    import wx.lib.anchors as anchors
    import wx.lib.newevent
    import  wx.lib.buttons  as  buttons
    
    from .job_recovery import FrameRecovery
except ImportError:
    # create fake module and class
    # To accept file loading
    class wx:
        class Panel:
            pass
        class Frame:
            pass

    class FrameRecover:
        pass
    if sys.version_info[0] == 3:
        print("WARNING: Gui is not supported with Python {}.{}".format(sys.version_info[0], sys.version_info[1]))
    else:
        print("WARNING: wxPython is not installed. gui cannot work !")

import subprocess
import os
from datetime import datetime

if (os.path.isfile("dev.txt")):
    from batch_lib import __version__
else:
    from ...batch_lib import __version__

class BasicPanel(wx.Panel):
    """
        The basic Panel is for batch first release
        It should be replaced in future version
    """
    def __init__(self, parent):
        wx.Panel.__init__(self, parent, -1)

        self.selected_scripts = []
        self.selected_scripts_steps = []
        self.log_alternate_file = False
        self.available_scripts = self.get_list_file()
        self.process = None

        # Bind for process
        self.process_callbacks = []
        self.Bind(wx.EVT_TIMER, self.OnTimer)
        self.Bind(wx.EVT_END_PROCESS, self.OnProcessEnded)
        self.timer = wx.Timer(self)

        # BIND click to detect when close is done with the redcross (different to an end from taskscheduler)
        self.Bind(wx.EVT_MOUSE_EVENTS, self.OnEVT_MOUSE_EVENTS)
        self.lastMouseEvent = datetime.now()

        # Listbox of script files
        self.prompt = wx.StaticText(self, -1, 'Select scripts:')
        self.lb = wx.ListBox(self, -1, choices=self.available_scripts, style=wx.LB_EXTENDED|wx.LB_HSCROLL, size=(-1, 200))
        self.lb.Bind(wx.EVT_LISTBOX, self.change_selected_scripts)
        self.lb.Bind(wx.EVT_RIGHT_UP, self.OnRightClick_listbox)

        # Verbose checkbox
        self.cbverbose = wx.CheckBox(self, -1, "Verbose", style=wx.ALIGN_RIGHT)

        # Live checkbox
        self.cblive = wx.CheckBox(self, -1, "Live", style=wx.ALIGN_RIGHT)

        # Will receive stdout
        self.out = wx.TextCtrl(self, -1, '',
                               style=wx.TE_MULTILINE|wx.TE_READONLY|wx.TE_RICH2|wx.HSCROLL)
        font1 = wx.Font(8, wx.MODERN, wx.NORMAL, wx.NORMAL, False, u'Consolas')
        self.out.SetFont(font1)


        # Copy button (to copy stdout in clipboard)
        bmp = wx.ArtProvider.GetBitmap(wx.ART_COPY)
        copy = buttons.GenBitmapButton(self, -1, bmp) #, style=wx.BORDER_NONE)
        self.Bind(wx.EVT_BUTTON, self.copy_out, copy)

        # Delete button (to erase the content of stdout)
        bmp = wx.ArtProvider.GetBitmap(wx.ART_DELETE)
        delete = buttons.GenBitmapButton(self, -1, bmp) #, style=wx.BORDER_NONE)
        self.Bind(wx.EVT_BUTTON, self.delete_out, delete)

        # Execute button
        self.executeBtn = wx.Button(self, -1, 'Execute Job')
        self.executeBtn.Enable(False)
        self.executeBtn.Bind(wx.EVT_BUTTON, self.execute)

        # Kill button
        self.killBtn = wx.Button(self, -1, 'Kill Job')
        self.killBtn.Enable(False)
        self.killBtn.Bind(wx.EVT_BUTTON, self.kill)

        # Graph button
        self.graphBtn = wx.Button(self, -1, 'Show Execution Plan')
        self.graphBtn.Enable(False)
        self.graphBtn.Bind(wx.EVT_BUTTON, self.graph)

        # Play/Pause button
        self.pauseBtn = wx.Button(self, -1, 'Pause')
        self.pauseBtn.Enable(False)
        self.pauseBtn.Bind(wx.EVT_BUTTON, self.play_pause)

        # Recovery button
        self.recoverBtn = wx.Button(self, -1, 'Recover')
        self.recoverBtn.Enable(False)
        self.recoverBtn.Bind(wx.EVT_BUTTON, self.recover)
        
        # Control box (listbox + buttons)
        box1 = wx.BoxSizer(wx.HORIZONTAL)

        box11 = wx.BoxSizer(wx.VERTICAL)
        box11.Add(self.prompt, 0, wx.ALIGN_LEFT|wx.ALL, 5)
        box11.Add(self.lb, 0, wx.EXPAND|wx.ALL, 5)

        box12 = wx.BoxSizer(wx.VERTICAL)
        box12.Add(wx.StaticText(self, -1, ''), 1, wx.EXPAND|wx.TOP, 5)
        box12.Add(self.executeBtn, 0, wx.EXPAND|wx.ALIGN_LEFT|wx.TOP, 5)
        box12.Add(self.graphBtn, 0, wx.EXPAND|wx.ALIGN_LEFT|wx.TOP, 5)
        box12.Add(self.killBtn, 0, wx.EXPAND|wx.ALIGN_LEFT|wx.TOP, 5)
        box12.Add(self.pauseBtn, 0, wx.EXPAND|wx.ALIGN_LEFT|wx.TOP, 5)
        box12.Add(self.recoverBtn, 0, wx.EXPAND|wx.ALIGN_LEFT|wx.TOP, 5)
        box12.Add(self.cbverbose, 0, wx.ALIGN_RIGHT|wx.TOP, 25)
        box12.Add(self.cblive, 0, wx.ALIGN_RIGHT|wx.TOP, 5)

        # Copy and delete button
        box13 = wx.BoxSizer(wx.HORIZONTAL)
        box13.Add(copy, 0, wx.ALIGN_RIGHT, 5)
        box13.Add(delete, 0, wx.ALIGN_RIGHT, 5)
        box12.Add(box13, 0, wx.ALIGN_RIGHT|wx.TOP, 25)

        box1.Add(box11, 1, wx.EXPAND, 0)
        box1.Add(box12, 0, wx.ALIGN_RIGHT, 0)

        # The main grid
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(box1, 0, wx.EXPAND|wx.RIGHT|wx.LEFT|wx.TOP, 5)
        sizer.Add(self.out, 1, wx.EXPAND|wx.ALL, 5)

        self.SetSizer(sizer)
        self.SetAutoLayout(True)
        w, h = self.GetBestSizeTuple()
        parent.SetSize((700, 700))
        parent.SetMinSize((500, 500))

    def refresh_listbox(self, event=None):
        """
            Refresh the listbox content
        """
        selected = self.selected_scripts
        self.available_scripts = self.get_list_file()

        # Keep the previously inserted files
        for x in range(self.lb.GetCount()):
            text = self.lb.GetString(x)
            if os.path.exists(text) and not text in self.available_scripts:
                self.available_scripts.append(text)

        for item in selected:
            if (not item in self.available_scripts) and (os.path.exists(item)):
                self.available_scripts.append(item)

        self.lb.Clear()
        self.lb.InsertItems(self.available_scripts,0)

        # Reselect the ones that was selected
        for x in range(self.lb.GetCount()):
            text = self.lb.GetString(x)
            if text in selected:
                selected.remove(text)
                self.lb.Select(x)

        # Propagate the change (enable/disable buttons in function of numbers of scripts selected)
        self.change_selected_scripts(event)

    def get_list_file(self):
        """
            Return the list of file, that seems to be scripts
        """
        list_file = []
        for file in os.listdir(os.getcwd()):
            _, ext = os.path.splitext(file)
            if not ext == ".py":
                continue

            with open(file, 'r') as script_file:
                count = 0
                for line in script_file:
                    count += 1
                    if "from batch_lib" in line:
                        list_file.append(file.replace(".\\", ""))
                        break
                    # only search in 5 first lines
                    if count > 5:
                        break

        if "batch.py" in list_file:
            list_file.remove("batch.py")
        if "runner.py" in list_file:
            list_file.remove("runner.py")

        return list_file

    def change_selected_scripts(self, evt):
        """
            The user have changed the script selection in listbox
        """
        ids = self.lb.GetSelections()
        self.selected_scripts = []
        for i in ids:
            self.selected_scripts.append(self.available_scripts[i])

        if self.selected_scripts:
            self.executeBtn.Enable(True)
            self.graphBtn.Enable(True)
            self.recoverBtn.Enable(True)
        else:
            self.executeBtn.Enable(False)
            self.graphBtn.Enable(False)
            self.recoverBtn.Enable(False)

        if len(self.selected_scripts) > 1:
            self.prompt.SetLabel("Select scripts:  You have selected {} scripts.".format(len(self.selected_scripts)))
        else:
            self.prompt.SetLabel("Select scripts:")

    def kill(self, evt):
        """
            click on kill,
            we must kill the running script (and children)
        """
        if self.process.Exists(self.process_pid):
            # call taskkill with the /T option is the best (and simpliest)
            # way I have found to kill a process tree.
            # But it works only under windows and version after windows XP
            # wx.Kill and self.process.Kill are not working as of today, and I don't know why...
            subprocess.call(['taskkill', '/F', '/T', '/PID', str(self.process_pid)])
            self.out.AppendText("> STOP {} ! \n".format(self.process_pid))

            # Fix bug with scroll
            # http://trac.wxwidgets.org/ticket/716
            self.out.ScrollLines(-1)
            self.out.ScrollLines(1)

    def graph(self, evt):
        """
            Launch the graph cmd with selected scripts
        """
        if not self.process:
            if os.path.isfile("dev.txt"):
                cmd = "\"C:\\Python27\\python.exe\" \"batch_lib.py\" graph "
            else:
                cmd = "\"C:\\Python27\\python.exe\" \"batch.py\" graph "
            cmd += " ".join(self.selected_scripts)
            wx.Execute(cmd)
            self.out.AppendText(">" + cmd + "\n")
        else:
            self.stdin.write("GRAPH\n")


    def execute(self, evt):
        """
            Click on execute
        """
        # Disable control
        self.lb.Enable(False)
        self.executeBtn.Enable(False)
        self.cbverbose.Enable(False)
        self.cblive.Enable(False)
        self.pauseBtn.Enable(True)
        self.recoverBtn.Enable(False)

        # Launch process
        self.process = wx.Process(self)
        self.process.Redirect()

        # Clean the output console
        self.out.SetValue("")

        cmd = "\"C:\\Python27\\python.exe\" \"-u\" \"{}\" exe ".format(sys.argv[0])
        if self.cbverbose.IsChecked():
            cmd += "--verbose "
        if self.cblive.IsChecked():
            cmd += "--live "
        if self.selected_scripts_steps:
            cmd += "--steps {} ".format(','.join(self.selected_scripts_steps))
        if self.log_alternate_file:
            cmd += "--log-alternate-file "

        cmd += " ".join(self.selected_scripts)

        self.out.AppendText(">" + cmd + "\n")

        # Fix bug with scroll
        # http://trac.wxwidgets.org/ticket/716
        self.out.ScrollLines(-1)
        self.out.ScrollLines(1)

        self.process_pid = wx.Execute(cmd, wx.EXEC_ASYNC|wx.EXEC_MAKE_GROUP_LEADER, self.process)

        # get stdin
        self.stdin = self.process.GetOutputStream()
        self.stdin.write("\n")
        #self.stdin.flush()

        # Run the timer (to refresh stdout)
        self.timer.Start(100)

        # Enable Stop button
        self.killBtn.Enable(True)

    def play_pause(self, evt):
        """
            Button to change script play/pause status
        """
        label = self.pauseBtn.GetLabel()
        if label == "Pause":
            self.stdin.write("PAUSE\n")
            self.pauseBtn.SetLabel("Resume")
        elif label == "Resume":
            self.stdin.write("PLAY\n")
            self.pauseBtn.SetLabel("Pause")

    def OnTimer(self, event):
        """
            This event handler catches the process stdout.
        """
        if self.process is not None:
            # stdout
            stream = self.process.GetInputStream()
            if stream.CanRead():
                text = stream.read()
                if text:
                    self.out.AppendText(text)

                    # Limit the number of lines to 10 000
                    max_lines = 10000
                    nb_lines = self.out.GetNumberOfLines()
                    if nb_lines > max_lines:
                        for i in range(nb_lines - max_lines):
                            self.out.Remove(0, self.out.GetLineLength(0)+1)

                    # Fix bug with scroll
                    # http://trac.wxwidgets.org/ticket/716
                    self.out.ScrollLines(-1)
                    self.out.ScrollLines(1)

            # stderr
            stream = self.process.GetErrorStream()
            if stream.CanRead():
                text = stream.read()
                if text:
                    self.out.SetDefaultStyle(wx.TextAttr(wx.RED))
                    self.out.AppendText(text)
                    self.out.SetDefaultStyle(wx.TextAttr())

                    # Limit the number of lines to 10 000
                    max_lines = 10000
                    nb_lines = self.out.GetNumberOfLines()
                    if nb_lines > max_lines:
                        for i in range(nb_lines - max_lines):
                            self.out.Remove(0, self.out.GetLineLength(0)+1)

                    # Fix bug with scroll
                    # http://trac.wxwidgets.org/ticket/716
                    self.out.ScrollLines(-1)
                    self.out.ScrollLines(1)

            # stdin fix bug in wxProcess... (If I don't write on stdin, subprocess are blocked somewhere)
            # hopefully, this is not needed when launching scripts without the gui.
            self.stdin.write('\n')

    def OnProcessEnded(self, evt):
        """
            When this is the end of process
        """
        # If there is something in stream buffer, we should print it
        self.OnTimer(evt)

        # Stop the timer
        self.timer.Stop()

        # Disable stop button
        self.killBtn.Enable(False)

        # Re-enable control
        self.cbverbose.Enable(True)
        self.cblive.Enable(True)
        self.lb.Enable(True)
        self.executeBtn.Enable(True)
        self.pauseBtn.Enable(False)
        self.pauseBtn.SetLabel("Pause")
        self.recoverBtn.Enable(True)

        self.process = None

        # If there is callbacks call them (and clean the list)
        for callback in self.process_callbacks:
            callback.__call__(None)
        self.process_callbacks = []

    def OnEVT_MOUSE_EVENTS(self, event):
        """
            A wx.EVT_MOUSE_EVENTS had been catched
        """
        self.lastMouseEvent = datetime.now()

    def OnClose(self, event):
        """
            A wx.EVT_CLOSE had been catched
        """
        delta = (datetime.now() - self.lastMouseEvent).total_seconds()
        if self.process and self.process.Exists(self.process_pid) and event:
            if delta < 2.:
                dlg = wx.MessageDialog(self,
                    "Do you really want to close this application (a script is running, it will be killed if you confirm)?",
                    "Confirm Exit", wx.OK|wx.CANCEL|wx.ICON_QUESTION)
                result = dlg.ShowModal()
                dlg.Destroy()
                if result == wx.ID_OK:
                    self.kill(event)
                    self.Destroy()
                    return True
            else:
                self.kill(event)
                self.Destroy()
                return True
        else:
            self.Destroy()
            return True

    def OnRightClick_listbox(self, event):
        """
            When user do a right click on an item in the listbox
        """
        # get older selection
        selected = self.selected_scripts

        # Select under the right click
        id_clicked = self.lb.HitTest(event.GetPosition())
        if id_clicked == -1:
            return

        self.selected_scripts = []
        self.refresh_listbox()
        self.lb.Select(id_clicked)

        # open a menu
        menu = wx.Menu()

        # Show how to put an icon in the menu
        item = wx.MenuItem(menu, -1,"Open file location")
        item2 = wx.MenuItem(menu, -1,"Open file in PyScripter")
        menu.AppendItem(item)
        menu.AppendItem(item2)

        def open_file_location(_event):
            """
                Open the selected file location
            """
            EXPLORER = 'C:\\windows\\explorer.exe'
            subprocess.Popen(EXPLORER + ' /n,/e,/select,"{}"'.format(os.path.abspath(self.lb.GetString(id_clicked))))

        def open_py_scrypter(_event):
            """
                Open the file in pyscrypter
            """
            if os.path.exists(os.path.join("C:\\", "Program Files (x86)", "PyScripter", "PyScripter.exe")):
                PYSCRIPTER = os.path.join("C:\\", "Program Files (x86)", "PyScripter", "PyScripter.exe")
            elif os.path.exists(os.path.join("C:\\", "Program Files", "PyScripter", "PyScripter.exe")):
                PYSCRIPTER = os.path.join("C:\\", "Program Files", "PyScripter", "PyScripter.exe")
            else:
                PYSCRIPTER = "PyScripter.exe"
            subprocess.Popen(PYSCRIPTER + ' "{}"'.format(os.path.abspath(self.lb.GetString(id_clicked))))

        self.Bind(wx.EVT_MENU, open_file_location, item)
        self.Bind(wx.EVT_MENU, open_py_scrypter, item2)

        # Popup the menu.  If an item is selected then its handler
        # will be called before PopupMenu returns.
        self.PopupMenu(menu)
        menu.Destroy()

        # Reset the old selection
        self.selected_scripts = selected
        self.refresh_listbox()

    def copy_out(self, _evt):
        """
            Copy the content of stdout (self.out) to clipboard
        """
        text = wx.TextDataObject()
        text.SetText(self.out.GetValue().replace("\n", os.linesep))
        wx.TheClipboard.SetData(text)

    def delete_out(self, _evt):
        """
            Clean the stdout
        """
        # Clean the output console
        self.out.SetValue("")

    
    def recover(self, evt):
        frame = FrameRecovery(self, scripts=self.selected_scripts)
        frame.Show(True)  
#----------------------------------------------------------------------


class BatchFrame(wx.Frame):
    """
        The Batch main frame for gui
    """
    def __init__(self, verbose=False, scripts=[]):
        wx.Frame.__init__(self, None, -1, 'Batch {}'.format(__version__),
                            style=wx.DEFAULT_FRAME_STYLE | wx.CLIP_CHILDREN)

        self.panel = BasicPanel(self)
        self.create_menu()
        self.CreateStatusBar()
        self.scripts = scripts

        # Bind Close EVT
        self.Bind(wx.EVT_CLOSE, self.OnClose)

        # set things in functions of args
        self.panel.cbverbose.SetValue(verbose)
        if scripts:
            for script in scripts:
                self.panel.selected_scripts.append(script)
                self.panel.refresh_listbox()

            self.panel.execute(None)
            self.panel.process_callbacks.append(self.OnClose)

    def create_menu(self):
        """
            Create the menu
        """
        # Prepare the menu bar
        menuBar = wx.MenuBar()

        # "File"
        mfile = wx.Menu()
        mfile.Append(104, "&Open script ...", "Add a batch .py script to the listbox")
        mfile.Append(101, "&Create new script ...", "Create a new empty script with mandatory part")
        mfile.Append(103, "Refresh the script list\tF5", "Refresh the listbox (usefull if you have create/renamed or removed scripts files)")
        mfile.AppendSeparator()
        mfile.Append(102, "&Quit", "Quit Batch")
        # Add menu to the menu bar
        menuBar.Append(mfile, "&File")

        self.Bind(wx.EVT_MENU, self.new, id=101)
        self.Bind(wx.EVT_MENU, self.exit, id=102)
        self.Bind(wx.EVT_MENU, self.panel.refresh_listbox, id=103)
        self.Bind(wx.EVT_MENU, self.open, id=104)

        # "Tools"
        mtools = wx.Menu()
        mtools.Append(301, "Transform path in clipboard", "Double bakslash and normalize the path you have in clipboard")
        mtools.Append(302, "Convert from .cmd to batch .py ...", "Convert a .cmd into a .py script file")
        menuBar.Append(mtools, "&Tools")

        self.Bind(wx.EVT_MENU, self.clipboard_normalizer, id=301)
        self.Bind(wx.EVT_MENU, self.convert, id=302)

        # "Help"
        mhelp = wx.Menu()
        mhelp.Append(201, "About Batch", "Some informations about Batch")
        # Append "help" menu
        menuBar.Append(mhelp, "&Help")

        self.Bind(wx.EVT_MENU, self.AboutBatch, id=201)

        # Set the menubar
        self.SetMenuBar(menuBar)

    def new(self, _event):
        """
            Create a new empty script
        """
        dlg = wx.FileDialog(
            self, message="Create file as", defaultDir=os.getcwd(),
            defaultFile="new_script.py", wildcard="Python source (*.py)|*.py", style=wx.FD_SAVE
            )

        # This sets the default filter that the user will initially see. Otherwise,
        # the first filter in the list will be used by default.
        dlg.SetFilterIndex(2)

        # Show the dialog and retrieve the user response. If it is the OK response,
        # process the data.
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()
            from ..init import Init
            Init(dbg=wx.MessageBox).create(path)

            # add the new file to the selection
            self.panel.selected_scripts.append(os.path.relpath(path, os.getcwd()))

        # Destroy the dialog. Don't do this until you are done with it!
        dlg.Destroy()
        # New script must be put in the listbox
        self.panel.refresh_listbox()

    def open(self, _event):
        """
            Add a .py file to the listbox
        """
        dlg = wx.FileDialog(
            self, message="Open file", defaultDir=os.getcwd(),
            wildcard="Python source (*.py)|*.py", style=wx.FD_OPEN
            )

        # This sets the default filter that the user will initially see. Otherwise,
        # the first filter in the list will be used by default.
        dlg.SetFilterIndex(2)

        # Show the dialog and retrieve the user response. If it is the OK response,
        # process the data.
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()

            if os.path.exists(os.path.relpath(path, os.getcwd())):
                # add the new file to the selection
                self.panel.selected_scripts.append(os.path.relpath(path, os.getcwd()))

        # Destroy the dialog. Don't do this until you are done with it!
        dlg.Destroy()
        # New script must be put in the listbox
        self.panel.refresh_listbox()
    
    
    def convert(self, _event):
        """
            Convert a .cmd into a .py
        """
        dlg = wx.FileDialog(
            self, message="Convert .cmd", defaultDir=os.getcwd(),
            wildcard="Cmd source (*.cmd)|*.cmd", style=wx.OPEN
            )

        # This sets the default filter that the user will initially see. Otherwise,
        # the first filter in the list will be used by default.
        dlg.SetFilterIndex(2)

        # Show the dialog and retrieve the user response. If it is the OK response,
        # process the data.
        if dlg.ShowModal() == wx.ID_OK:
            path = dlg.GetPath()
            from ..translate import Translate
            Translate(dbg=wx.MessageBox).go(path)

            # add the new file to the selection
            self.panel.selected_scripts.append(os.path.relpath(path, os.getcwd()).replace(".cmd", ".py"))

        # Destroy the dialog. Don't do this until you are done with it!
        dlg.Destroy()
        # New script must be put in the listbox
        self.panel.refresh_listbox()

    def AboutBatch(self, _event):
        """
            Open an About dialog info
        """
        info = wx.AboutDialogInfo()
        info.Name = "Batch"
        info.Version = __version__
        info.Copyright = "(C) 2013 FactSet"
        #info.Description = wordwrap(
        #    "Batch is a script manager",
        #    350, wx.ClientDC(self))
        #info.WebSite = ("http://en.wikipedia.org/wiki/Hello_world", "Hello World home page")
        #info.Developers = [ "Matthieu guffroy" ]
        #info.License =

        # Then we call wx.AboutBox giving it that info object
        wx.AboutBox(info)

    def clipboard_normalizer(self, _event):
        """
            Normalize the path in clipboard
        """
        success = False
        do = wx.TextDataObject()
        if wx.TheClipboard.Open():
            success = wx.TheClipboard.GetData(do)

        if success:
            try:
                orig_content = do.GetText()
                content = os.path.normpath(orig_content)
                content = content.replace("\\", "\\\\")
                do.SetText(content)
                wx.TheClipboard.SetData(do)
                wx.MessageBox("The clipboard content was:\n{}\nit's now:\n{}".format(orig_content, content), "Clipboard normalizer")
            except Exception:
                wx.MessageBox("An unexcepted error occurs.\n(Is your clipboard data really a path ?)\n\n", "Error")
        else:
            wx.MessageBox("Your clipboard is empty, cannot normalize it!", "Error")

    def exit(self, _event):
        """
            Exit Batch
        """
        self.Close()

    def OnClose(self, event):
        """
            When there is a Close event
            we should say it to the panel
        """
        if self.panel.OnClose(event):
            self.Destroy()


class Gui():
    """
        Load an lauch one or more scripts files.
    """
    def __init__(self, log=print, dbg=print):
        self.log = log
        self.dbg = dbg

    def parser(self, subparsers, name):
        """
            Add the Exec tool to subparser from main
        """
        parser = subparsers.add_parser(name, help='Launch graphical user interface')
        parser.add_argument('--verbose', '-v', default=False, action="store_true", help="Batch will be verbose about it's worker")
        parser.add_argument('script', nargs='*', type=str, help="pathname of scripts you want to launch")

    def execute(self, args):
        """
            The tool had been called from command line
        """
        app = wx.App()
        try:
            frame = BatchFrame(verbose=args.verbose, scripts=args.script)
            frame.Show(True)
        except Exception as e:
            print(e)
        app.MainLoop()
