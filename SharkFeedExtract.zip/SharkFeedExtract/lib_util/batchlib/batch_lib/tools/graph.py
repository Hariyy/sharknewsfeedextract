"""
    Command line::

        python batch.py graph script.py

    Create a network graph, showing how your scripts are linked together inside files loaded.

    It will open your browser, and show you the script representation.

    .. warning::
        This tool need `graphviz <http://www.graphviz.org/>`_ to be installed on your system.

"""
from __future__ import unicode_literals, absolute_import

import sys
import os

if os.path.isfile("dev.txt"):
    from script import *
    from decorators import init
    from execute import get_scripts
else:
    from ..script import *
    from ..execute import get_scripts

import tempfile
import subprocess
import imp
import inspect
import textwrap

try:
    from pygments import highlight as pygments_highlight
    from pygments.lexers import PythonLexer
    from pygments.formatters import HtmlFormatter
    def highlight(code):
        return pygments_highlight(code, PythonLexer(), HtmlFormatter())

    def highlight_css():
        return HtmlFormatter().get_style_defs('.highlight')
except ImportError:
    def highlight(code):
        return code
    def highlight_css():
        return ""


__all__ = ['Graph']

# Constant for graph clusters
INIT = "INIT"
SCRIPTS = "SCRIPTS"
END = "END"

class Graph:
    """
        The class Graph, make a Graph with a list of scripts
        And export it to .dot format (and if dot is installed on host system) could export it to jpeg (or other format)
        And show it to the user
    """
    def __init__(self):
        self.nodes = []
        self.edges = []
        self.clusters = {}

    def parser(self, subparsers, name):
        """
            Add args to command line
        """
        parser = subparsers.add_parser(name, help='Plugins to show graph image of scripts')
        parser.add_argument('script', nargs='+', type=str, help="script file to load")

    def execute(self, args):
        """
            Class have been called from commandline
        """
        for s in args.script:
            dirname = os.path.abspath(os.path.dirname(s))
            sys.path.insert(0, dirname)
            module, _ = os.path.splitext(os.path.basename(s))
            __import__(module)
            sys.path.remove(dirname)

        self.auto_load()

        scripts = []
        for script in args.script:
            scripts.append(script.replace(".py", "").replace("\\","_"))
        if not os.path.exists("batch_graphs"):
            os.mkdir("batch_graphs")
        self.create_html_and_open_it(os.path.join("batch_graphs", "+".join(scripts)))


    def auto_load(self, soft=False):
        """
            Load scripts automatically from get_scripts()

            if soft=True, don't touch scripts (we are next to the execution, it's forbiden to do something)
            we have to let the execute part work
        """
        # link @init scripts with @script
        (init_scripts, scripts, end_scripts) = get_scripts()

        if not soft:
            if len(init_scripts) > 1:
                init = Script()
                for s in init_scripts:
                    init._and(s)
            elif len(init_scripts) == 1:
                init = init_scripts[0]
            else:
                init = None

            if init:
                for script in scripts:
                    if script.ready():
                        script.wait_success(init)

        self.clusters[INIT] = init_scripts
        self.clusters[SCRIPTS] = scripts
        self.clusters[END] = end_scripts

        if not soft:

            # Part of the hack to put end nodes at bottom
            scripts.reverse()
            scripts.extend(end_scripts)
            scripts.extend(init_scripts)
            scripts.reverse()


        self.load_scripts(scripts)

    def create_html(self, basename, refresh=None):
        """
            Create an html view
        """
        svgfile = os.path.join(os.getcwd(), basename + ".svg")
        svgfile = self.to_svg_file(path=svgfile)
        file = self.make_html_viewer(os.path.join(os.getcwd(), basename), refresh=refresh)
        # Remove the svg file
        os.remove(svgfile)
        return file

    def create_html_and_open_it(self, basename, refresh=None):
        """
            Create an html viewer and open it
        """
        file = self.create_html(basename, refresh)
        subprocess.call("start \"\" \"{}\"".format(file), shell=True)

    def add_node(self, node, t="complete", rec=True):
        """
            Add a node
        """
        if not node in self.clusters[SCRIPTS]:
            self.clusters[SCRIPTS].append(node)
            self.nodes.append(node)

        if rec and (node.mode == MODE_OR or node.mode == MODE_AND):
            for script in node.scripts:
                self.add_edge(script, node, t)


    def add_edge(self, n1, n2, t="complete"):
        """
            Add an edge between 2 nodes
        """
        # be sure n1 and n2 are nodes
        self.add_node(n1, t, rec=True)
        self.add_node(n2, t, rec=False)
        # add edge
        if not (n1, n2, t) in self.edges:
            self.edges.append((n1, n2, t))

    def to_dot(self):
        """
            Export the graph to .dot file
        """
        # colors for toplevel scripts
        color_list = ["black", "red","blue","green","purple","brown","yellow"]
        def color(param, background=False):
            color1 = "black"
            color2 = "white"

            if param == "default":
                color1 = "black"
            elif param == "success":
                color1 = "blue"
            elif param == "complete":
                color1 = "black"
            elif param == "error":
                color1 = "red"
            elif isinstance(param, Script):
                if param.mode == MODE_OR or param.mode == MODE_AND:
                    if param.success():
                        color1 = "green"
                        color2 = "lightgreen"
                    elif param.error():
                        color1 = "red"
                        color2 = "tomato"
                    elif param.complete():
                        color1 = "black"
                        color2 = "lightgrey"
                if param.status == NOT_EXECUTED:
                    color1 = "black"
                    color2 = "white"
                if param.status == IN_QUEUE:
                    color1 = "blue"
                    color2 = "white"
                if param.status == IN_EXECUTION:
                    color1 = "orange4"
                    color2 = "orange"
                if param.status == SUCCESS:
                    color1 = "green"
                    color2 = "lightgreen"
                if param.status == ERROR:
                    color1 = "red"
                    color2 = "tomato"
            if background:
                return color2
            else:
                return color1

        graph = "digraph \"\" {\n"
        graph += "\t compound = True; \n"

        # clusters
        nodes_done = []
        for name, nodes in [(INIT, self.clusters[INIT]), (END, self.clusters[END]), (SCRIPTS, self.clusters[SCRIPTS])]:
            if not nodes:
                continue

            graph += "\t subgraph cluster"+ name +" {\n"
            graph += "\t\t style=filled;\n\t\tcolor=lightgrey;\n"
            graph += "\t\t node [shape=plaintext]"
            for node in nodes:
                if node in nodes_done:
                    continue
                else:
                    nodes_done.append(node)

                if node.mode == MODE_OR or node.mode == MODE_AND:
                    shape = "ellipse"
                    label = "<<B>{}</B><BR />{}>".format(node.mode, node)
                    show = "'{}'".format(node)
                else:
                    shape = "box"
                    label = "<<FONT POINT-SIZE=\"12.0\" FACE=\"tahoma\"><B>{}</B></FONT>".format(node)
                    if node.func.__doc__:
                        doc = node.func.__doc__
                        start = doc.find('\n') + 1
                        end = doc.find('\n', start)
                        if end == -1:
                            doc = doc[start:]
                        else:
                            doc = doc[start:end]
                        doc = textwrap.dedent(doc)
                        doc = textwrap.wrap(doc, 20)
                        label += "<BR /><BR /><FONT POINT-SIZE=\"10.0\" FACE=\"tahoma\">" + "<BR />".join(doc) + "</FONT>"
                    label += ">"
                    show = "var_{}".format(id(node))
                graph += "\t\t \"{}\" [label={}, color={}, fillcolor={}, style=\"filled\", shape={}, href=\"javascript:show({});\"];\n".format(id(node), label, color(node), color(node, True), shape, show)
            graph += "\t\t \"{}\" [label=\"{}\", shape=plaintext] \n".format(name, name)
            graph += "\t }\n"

        # EDGES
        self.edges.reverse()
        for edge in self.edges:
            graph += "\t {} -> {} [color={}];\n".format(id(edge[0]), id(edge[1]), color(edge[2]))

        if self.clusters[INIT]:
            graph += "\t {INIT} -> {SCRIPTS} [ltail=cluster{INIT}, lhead=cluster{SCRIPTS}, style=\"invis\"]; \n".format(INIT=INIT, SCRIPTS=SCRIPTS);

        if self.clusters[END]:
            graph += "\t {SCRIPTS} -> {END} [ltail=cluster{SCRIPTS}, lhead=cluster{END}]; \n".format(SCRIPTS=SCRIPTS, END=END);

            # put invisible edges on the end (to put it at bottom)
            try:
                node_from = self.clusters[SCRIPTS][len(self.clusters[SCRIPTS]) - 1]
                graph += "\t {} -> END [style=\"invis\"];\n".format(id(node_from))
            except:
                pass

        graph += "}"

        return graph

    def to_dot_file(self, path=None):
        """
            Create a .dot file, with the graph content
            Will return the temp path
        """
        if not path:
            _, path = tempfile.mkstemp(".dot")
        with open(path, 'w') as target:
            target.write(self.to_dot())
        return path

    def to_jpeg_file(self, path=None):
        """
            Create a .jpeg image with the graph
        """
        if not path:
            _, path = tempfile.mkstemp(".jpg")
        dotpath = self.to_dot_file(path=path.replace(".jpg", ".dot"))
        cmd = "dot -Tjpg -o{} {}".format(path, dotpath)
        subprocess.call(cmd, shell=True)
        os.remove(dotpath)
        return path

    def to_svg_file(self, path=None):
        """
            Create a .jpeg image with the graph
        """
        if not path:
            _, path = tempfile.mkstemp(".svg")
        dotpath = self.to_dot_file(path=path.replace(".svg", ".dot"))
        cmd = "dot -Tsvg -o{} {}".format(path, dotpath)
        subprocess.call(cmd, shell=True)
        os.remove(dotpath)
        return path

    def load_scripts(self, scripts):
        """
            Add a list of scripts in the graph
        """
        for script in scripts:
            #self.add_node(script)
            for item in script.wait:
                if isinstance(item.im_self, Script):
                    self.add_node(item.im_self, item.im_func.__name__)
                    self.add_edge(item.im_self, script, item.im_func.__name__)
                # else waiting other things than script is not implemented !

    def make_html_viewer(self, file, refresh=None):
        """
            Make an html file, with some functions to improve the svg file
        """
        # Set code func
        code_func = ""
        all_parts = []
        parts = {INIT:[], SCRIPTS:[], END:[]}
        for name, nodes in [(INIT, self.clusters[INIT]), (END, self.clusters[END]), (SCRIPTS, self.clusters[SCRIPTS])]:
            for node in nodes:
                if node.mode == MODE_OR or node.mode == MODE_AND:
                    continue

                if "var_{}".format(id(node)) in all_parts:
                    continue

                try:
                    show = inspect.getsource(node.func)
                except IOError:
                    show = ""
                show = highlight(show)
                show = show.replace("\\\\", "\\\\\\\\")
                show = show.replace("\"","\\\"").replace("'", "\\'").replace("\n","<br />' +\n'")
                show = show.replace('\\\\"', '\\\\\\"')
                show = show.replace('\\\\\\\\"', '\\\\\\"')
                code_func += "\t\t var_{} = \'{}\';\n".format(id(node), show)
                all_parts.append("var_{}".format(id(node)))
                parts[name].append("var_{}".format(id(node)))

        # Make a good ordering.
        all_parts = parts[INIT] + parts[SCRIPTS] + parts[END]

        if refresh:
            refresh_meta = """<meta http-equiv="refresh" content="{}">""".format(refresh)
        else:
            refresh_meta = ""

        with open(file + ".html", 'w') as html:
            # Write the first part of html file
            html.write("""<!DOCTYPE HTML>
<html>
<head>
    """ + refresh_meta + """
    <title>Batch graph viewer</title>
    <script>
        function show(content) {
            document.getElementById("sourcecode").innerHTML=content;
        }
        function show_all() {
            show(""" + " + ".join(all_parts) + """)
        }
        """ + code_func + """
    </script>
    <style>
        html, body {
          height: 100%;
          width: 100%;
          margin: 0;
          padding: 0;
          border: none;
          }
          """ + highlight_css() + """
    </style>
</head>
<body>
       <table border=0 height="100%" width="100%">
       <tr><td width="50%" height="100%">
       <div style="float:left; width:100%; height:100%; overflow:auto;">
            <h2 style="text-align:center;">Graph</h2>
            <br />""")
            # write the svg content
            with open(file + ".svg", 'r') as svg:
                svg.readline()
                svg.readline()
                svg.readline()
                for line in svg:
                    html.write(line)

            # Write end of html file
            html.write("""        </div></td><td width="50%" height="100%">
        <div style="float:left; width:100%; height:100%; margin-left:10px; overflow:auto;">
            <h2 style="text-align:center;"> Source code <input type="button" value="Show all !" onclick="show_all();" /></h2>
            <br />
            <pre id="sourcecode">
                Please click on a script in the graph...
            </pre>
        </div></td></tr></table>
</body>
</html>""")
        return file + ".html"




