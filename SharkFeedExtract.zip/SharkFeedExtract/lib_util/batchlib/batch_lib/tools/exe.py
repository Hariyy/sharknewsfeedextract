"""
    Command line::

        python batch.py exe [--verbose] [--live] script_pathname [script_pathname ...]

    The exe tool, is for launching scripts.

    script_pathname, is the path to your .py scripts (relative or absolute).

    .. note::

        ``--verbose`` will add some output from batch, like information when a process is spawned.
        When a process start a task, when it end this task when the process end...

    .. note::

        ``--live`` will open a browser, and show the graph with colour representing the current states in live.

        White: The script has not been yet executed

        White, with blue border: The script is ready to be launched

        Orange: This script is currently running

        Green: The script has end with success

        Red: The Script has end with error

"""

from __future__ import print_function, absolute_import
import os
import sys

if os.path.isfile("dev.txt"):
    from execute import run
else:
    from ..execute import run


class Exe:
    """
        Load an lauch one or more scripts files.
    """
    def __init__(self, log=print, dbg=print):
        self.log = log
        self.dbg = dbg

    def parser(self, subparsers, name):
        """
            Add the Exec tool to subparser from main
        """
        parser = subparsers.add_parser(name, help='Execute one or more scripts')
        parser.add_argument('--verbose', '-v', default=False, action="store_true", help="Batch will be verbose about it's worker")
        parser.add_argument('--live', '-l', default=False, action="store_true", help="A live graph execution")
        parser.add_argument('--steps', '-s', default=None, nargs='?', help="A live graph execution")
        parser.add_argument('--log-alternate-file', '-la', dest='log_alternate_file', default=False, action="store_true", help="Logs go in a [DATE]_script.log")
        parser.add_argument('script', nargs='+', type=str, help="pathname of the scripts you want to launch.")


    def _fix_argument_list(self, arguments):
        """
            When passing arguments with ' ' in them, for example some windows paths, we need to
            not treat them as different scripts to be run
            arguments are of format key=value or myscript.py
            This fixes a bug in python 2.7 used with argparse subparsers.
            Example of bug with argument line : key1=c:\program files\factset key2=value myscript.py
            Would give : [key1=C:\program][files\factset][key2=value][myscript.py]
            With the fix: [key1=C:\program files\factset][key2=value][myscript.py]
        """
        args = []
        for arg in arguments:
            if "=" in arg or ".py" in arg:
                args.append(arg)
            else: #this argument is not key=value nor a script, so it's part of the previous one
                args[len(args) - 1] = args[len(args) - 1] + ' ' + arg
        return args

    def execute(self, args):
        """
            The tool had been called from command line
        """
        # arguments key=value are global to all python scripts to run
        arguments = self._fix_argument_list(args.script)
        args_keyval = []
        for s in arguments:
            if '=' in s:
                args_keyval.append(s)

        for s in arguments:
            # skip key=value arguments already processed before
            if '=' in s:
                continue

            #python script name, empty args
            dirname = os.path.abspath(os.path.dirname(s))
            sys.path.insert(0, dirname)
            module, _ = os.path.splitext(os.path.basename(s))
            __import__(module)
            sys.path.remove(dirname)

        run(verbose=args.verbose, live=args.live, pyargs=args_keyval, steps=args.steps, log_alternate_file=args.log_alternate_file)
