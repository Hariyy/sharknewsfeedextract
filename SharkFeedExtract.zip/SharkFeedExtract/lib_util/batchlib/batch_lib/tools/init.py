"""

    Command line::

        batch.py init script.py

    This tool will create you a file `script.py` with all the mandatory part
    needed inside a Batch script.

    .. note::
        If `script.py` already exist, the tool will fails, and you original files won't be overwritten.

"""

from __future__ import print_function, absolute_import
import os

class Init:
    """
        Create a script file with all the mandatory part
    """
    def __init__(self, log=print, dbg=print):
        self.log = log
        self.dbg = dbg

    def parser(self, subparsers, name):
        """
            Add the init tool to subparser from main
        """
        parser = subparsers.add_parser(name, help='Create an empty script, with mandatory parts')
        parser.add_argument('script', type=str, help="pathname where you want to create a new script")

    def execute(self, args):
        """
            The tool had been called from command line
        """
        self.create(args.script)


    def create(self, script):
        """
            Create an empty script
        """
        if os.path.exists(script):
            self.dbg("Cannot create {} script because a file already exist there.".format(script))
            return

        with open(script, 'w') as file:
            self.head(file)
            file.write(
'''

@init
def job_init():
    """
        Initialisation
    """
    ENV.define("var_name", "var_value")

@script
def job_script():
    """
        Main script
    """
    log("var_name: "+var_name)

@end
def job_end():
    """
        End of script
    """
    pass

''')

    def head(self, file):
        """
            Write the head mandatory part
        """
        file.write(
"""# MANDATORY --------------------------------------------------------------------
# -*- coding: utf-8 -*-
from batch_lib import *
# ------------------------------------------------------------------------------
""".format(batchpyz=os.path.join(os.getcwd(), "batch_lib.pyz")))




