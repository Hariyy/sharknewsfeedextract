# MANDATORY --------------------------------------------------------------------
# -*- coding: utf-8 -*-
from batch_lib import *
# ------------------------------------------------------------------------------


@init
def job_init():
    """Define vars"""
    ENV.define("var_name", "var_value")
    log("JOB INIT : INIT")

@wait(job_init)
def step1():
    """This is step 1"""
    log("STEP 1 : waits job_init")


@wait(step1)
def step2():
    """This is step 2"""
    log("STEP 2 : waits step1")


@wait(step2)
def step3():
    """This is step 3"""
    log("STEP 3 : waits step2")

@wait(step3)
def step4():
    """This is step 4"""
    log("STEP 4 : waits step3")


@script
def step5():
    """This is step 5"""
    log("STEP 5 : waits nothing")

@end
def job_end():
    """End"""