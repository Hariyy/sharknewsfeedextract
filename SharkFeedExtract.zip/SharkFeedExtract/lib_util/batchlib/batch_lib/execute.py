from __future__ import print_function, unicode_literals, absolute_import
import multiprocessing
import threading
import os
import sys
from .compatibility import Empty

from .environment import ENV, Environment

"""
    This file contains all things related to the scripts
    execution.
    Workers / Queue etc...
"""

__all__ = ["run", "add_script", "get_scripts"]


def log(mutex, *msg):
    mutex.acquire()
    msg = list(msg)
    # map is an iterator in python3, so we cannot use insert on it
    msg = list(map(str, msg))
    msg.insert(0, "BATCH")
    print(";".join(msg))
    mutex.release()

def nolog(*args):
    pass

def dbg(mutex, *msg):
    mutex.acquire()
    msg = list(msg)
    # map is an iterator in python3, so we cannot use insert on it
    msg = list(map(str, msg))
    msg.insert(0, "BATCH")
    print(";".join(msg), file=sys.stderr)
    mutex.release()


class Worker(multiprocessing.Process):
    """
        A Worker is a process
        which execute task obtained from the tasks_queue
        If there is no more work it automatically end
    """
    def __init__(self, script_queue, result_queue, mutex, log=log, dbg=dbg, verbose=False):
        """
            script_queue is the input queue (that's where tasks come)
            result_queue is where worker send back information, essentially
                            script output, but also output some information about
                            worker state.
            mutex is a Lock to say when stdout is free for writing.
        """
        multiprocessing.Process.__init__(self)
        self.script_queue = script_queue
        self.result_queue = result_queue
        self.mutex = mutex
        self.log = log
        self.dbg = dbg
        self.verbose = verbose

    def run(self):
        """
            The worker logic
            This function end only if there is no more work.
        """
        if self.verbose:
            self.log(self.mutex, "{} START".format(self.name))
        while True:
            # get a task
            try:
                # if there is no tasks you simply end
                # Wait one seconds, it's better for perf to wait one seconds for tasks
                # Than ending the process and spawning a new one...
                script_serialized, env = self.script_queue.get(True, 1)

                # Say to manager that I'm starting a task
                self.result_queue.put(("start", {"script": script_serialized, "worker_pid": os.getpid()}))

                # Execute safely the task
                try:

                    #  get the script
                    path, module, name = script_serialized
                    sys.path.append(path)
                    imp = __import__(module, fromlist=[name])
                    script = getattr(imp, name)
                    sys.path.remove(path)

                    # Set values in ENV
                    ENV._script = script
                    ENV.loads(env, self.mutex, script, True)
                    ENV._status = "success"

                    self.log(self.mutex, "{} - EXECUTE - {}".format(self.name, ENV._script.name))

                    # Change current working dir to script one
                    os.chdir(path)

                    # EXECUTE THE TASK !!!
                    script()
                    # Force stdout to be flushed
                    sys.stdout.flush()
                    self.result_queue.put(("done", {"script": script_serialized, "env": ENV.dumps()}))
                except Exception as e:
                    self.dbg(self.mutex, {"script": script_serialized, "exception": e})
                    self.result_queue.put(("exception", {"script": script_serialized, "exception": e, "env": ENV.dumps()}))
                self.log(self.mutex, "{} - END - {}".format(self.name, script.name))
            except Empty:
                break
                # There is no more tasks, let the worker stop
            except Exception as e:
                # That's not normal
                self.dbg(self.mutex, "WORKER {} raise an exception {}:{}".format(self.name, type(e), e))
                break
        self.result_queue.put(("worker_end", {"worker_pid": os.getpid()}))
        self.log(self.mutex, "{} - STOP".format(self.name))

class ScriptManager(object):
    """
        Register all script, and manage queue
        in order to put script in queue following the rules predefined.
        A single instance of this class is instancied.
        run and add_script methods are exposed outside of this modules.
        Each time a function is decorated and become a script, add_script is called.
        And run is generally called at bottom of script files to launch the work.

        nb_workers_max = 0 => Unlimited
    """
    def __init__(self, verbose=False):
        """
            Init the ScriptManager
        """
        if verbose:
            self.log = log
        else:
            self.log = nolog
        self.dbg = dbg
        self.verbose = verbose
        self.nb_workers = 0
        # Init scripts are before scripts, and scripts make an @wait_success on inits one
        self.init_scripts = []
        self.scripts = []
        # End scripts are executed at end after all the others scripts, whatever passed on inits one.
        self.end_scripts = []

        # A thread read input from stdin
        # When it receive a "PAUSE" msg it set this vars to True
        # And when it receive a "START" msg it set this vars to False
        # It let jobbers debug their script by pausing script execution.
        self.pause = False

        # instantiate the 2 Queue
        # One is used to send work to workers
        # and the other is used to receive back from them informations
        self.script_queue = multiprocessing.Queue(0)
        self.in_queue = 0
        self.result_queue = multiprocessing.Queue(0)

    def clear(self):
        self.init_scripts = []
        self.scripts = []
        self.end_scripts = []


    def spawn_workers(self):
        """
            Spawn some workers only if it seems needed.
            => Never launch more worker than nb_max
            => Never launch more worker than tasks in queue
        """
        if ENV.max_workers_numbers <= 0:
            # Unlimited workers
            n = self.in_queue - self.nb_workers
        else:
            # Limited number of workers
            n = min(self.in_queue - self.nb_workers, ENV.max_workers_numbers - self.nb_workers)

        for i in range(n):
            p = Worker(self.script_queue, self.result_queue, ENV._mutex, self.log, self.dbg, self.verbose)
            self.nb_workers += 1
            p.start()

    def add_script(self, script):
        """
            All the script added by this function will be launched (accordingly to their ready() method)
        """
        self.scripts.append(script)

    def set_init(self):
        """
            Take all the scripts in self.scripts that are ready(), and ask them
            to wait_success all the scripts in self.init_scripts
        """
        for script in self.scripts:
            if script.ready(self.steps):
                script.wait_success(*self.init_scripts)
        
        self.scripts.extend(self.init_scripts)
        self.init_scripts = []

    def get_scripts(self):
        """
            Return all the scripts that have been loaded
            Used by plugins (example: the graph one, use it to get all script it have to put as node)
        """
        return (self.init_scripts, self.scripts, self.end_scripts)

    def handle_result(self, msg_type, msg):
        """
            When there is msg back from worker, they are treated by this function
        """
        # A script pass from "IN_QUEUE" to "IN_EXECUTION"
        if msg_type == "start":
            for s in self.scripts + self.end_scripts:
                if s.import_info() == msg['script']:
                    s.set_inexecution(msg['worker_pid'])
                    return

        # A script has completed
        if msg_type == "done":
            self.in_queue -= 1
            ENV.loads(msg['env'], ENV._mutex, None)
            for s in self.scripts + self.end_scripts:
                if s.import_info() == msg['script']:
                    s.set_executed(ENV._status)
                    return

        # A script have raised an exception
        if msg_type == "exception":
            self.in_queue -= 1
            ENV.loads(msg['env'], ENV._mutex, None)
            for s in self.scripts + self.end_scripts:
                if s.import_info() == msg['script']:
                    s.set_exception(msg['exception'])
                    return

        # A worker end
        if msg_type == "worker_end":
            self.nb_workers -= 1
            # If this worker was on a script, this is not normal, put the script in exception state
            for s in self.scripts + self.end_scripts:
                if s.pid == msg['worker_pid']:
                    s.set_exception(None)
                    return

        # There is a message from stdin
        if msg_type == "stdin":
            if msg == "PLAY":
                self.pause = False
                self.log(ENV._mutex, "self.pause: {}".format(self.pause))
            elif msg == "PAUSE":
                self.pause = True
                self.log(ENV._mutex, "self.pause: {}".format(self.pause))
            elif msg == "STATUS":
                self.log(ENV._mutex, "self.pause: {}".format(self.pause))
            elif msg == "GRAPH":
                from .tools.graph import Graph
                graph = Graph()
                graph.auto_load(soft=True)
                if not os.path.exists("batch_graphs"):
                    os.mkdir("batch_graphs")
                graph.create_html_and_open_it(os.path.join("batch_graphs", "tmp_live"))

    def read_stdin(self):
        """
            This method is launched inside a thread.
            When there is line coming from stdin it send them on the self.result_queue
        """
        while True:
            data = sys.stdin.readline()
            data = data.replace("\n", "").replace("\r", "")
            data.replace(os.linesep, "")
            if data:
                self.result_queue.put(("stdin", data))


    def _set_env_from_pyargs(self, pyargs):
        if pyargs is None:
            return
        for arg in pyargs:
            keyval = arg.split('=')
            ENV.define(keyval[0], keyval[1], False)


    def delete_non_recovered_scripts(self):
        for script in self.init_scripts[:]:
            if  self.steps and script.name not in self.steps:
                self.init_scripts.remove(script)
        for script in self.scripts[:]:
            if  self.steps and script.name not in self.steps:
                self.scripts.remove(script)
        for script in self.end_scripts[:]:
            if  self.steps and script.name not in self.steps:
                self.end_scripts.remove(script)


    def run(self, verbose=None, live=False, pyargs=None, steps=None, log_alternate_file=False):
        """
            Launch the work !
        """
        from .tools.graph import Graph
        if not verbose == None:
            self.verbose = verbose
            if self.verbose:
                self.log = log

         # filter: only some steps could be asked to run
        self.steps = steps.split(',') if steps else None
        self.delete_non_recovered_scripts()

        # Make the @script to wait_success the @init one
        self.set_init()

        # Open the graph if we are in live mode
        if live:
            graph = Graph()
            graph.auto_load(soft=True)
            if not os.path.exists("batch_graphs"):
                os.mkdir("batch_graphs")
            graph.create_html_and_open_it(os.path.join("batch_graphs", "tmp_live"), refresh=1)

        # Is the end_scripts running ?
        end = False

        # counters
        self.in_queue = 0

        # Launch the reading_stdin thread
        read_stdin = threading.Thread(None, self.read_stdin, None)
        read_stdin.daemon = True
        read_stdin.start()

        # set the pyargs env
        self._set_env_from_pyargs(pyargs)
        if log_alternate_file:
            ENV._log_alternate_file = True

        # Infinite loop while there is works
        while True:
            # Put ready scripts in queue
            if self.pause == False:
                for script in self.scripts:
                    # if recovery mode, force script even if it has to wait on non-selected script
                    if script.ready(steps):
                        self.script_queue.put((script.import_info(), ENV.dumps()))
                        script.set_inqueue()
                        self.in_queue += 1

            # Launch if possible and/or needed more workers
            self.spawn_workers()

            # If we are in live mode we have to refresh the graph
            if live:
                graph.create_html(os.path.join("batch_graphs", "tmp_live"), refresh=1)

            # When queue is empty, it's the END !
            if self.in_queue == 0 and self.pause == False:
                if not end:
                    # Add end script to queue
                    end = True
                    for script in self.end_scripts:
                        self.in_queue += 1
                        self.script_queue.put((script.import_info(), ENV.dumps()))
                        script.set_inqueue()

                    if self.in_queue == 0:
                        # There was no end scripts, then this is end.
                        break
                    else:
                        # spawn workers for the end scripts.
                        self.spawn_workers()
                else:
                    break
            else:
                # Force stdout/stderr to be flushed
                sys.stdout.flush()
                sys.stderr.flush()

                # Wait informations from workers
                wait = True
                while wait:
                    try:
                        (msg_type, msg) = self.result_queue.get(True, 1)
                        self.handle_result(msg_type, msg)
                        wait = False
                    except Empty:
                        # If there is no more children and they don't send a message
                        # that's mean they have been killed, in this condition we killed ourself too
                        if (self.nb_workers == 0 or multiprocessing.active_children() == 0) and self.pause == False:
                            sys.exit(1)

        # If we are in live mode we have to refresh the graph
        if live:
            graph.create_html(os.path.join("batch_graphs", "tmp_live"), refresh=None)

# Export functions
manager = ScriptManager()
add_script = manager.add_script
run = manager.run
get_scripts = manager.get_scripts
ENV._get_scripts = get_scripts

