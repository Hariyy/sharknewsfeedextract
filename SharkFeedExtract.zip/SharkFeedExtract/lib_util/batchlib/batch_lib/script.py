from __future__ import absolute_import
import types
import os
import sys
import inspect

from .environment import ENV
from .execute import add_script

# const values for Script mode
MODE_OR = " or "         # script is a logical mix of script
MODE_AND = " and "       # script is a logical mix of script
MODE_UNKNOWN = "unknown" # script mode is not defined
MODE_SCRIPT = "script"   # script is a job script (a function)

# Status where script can be
NOT_A_SCRIPT = "not a script"   # the script is not a function, certainly a set
NOT_EXECUTED = "not executed"   # The script has not been pushed in Queue
IN_QUEUE     = "in queue"       # The script has been pushed in Queue, but is waiting for a worker
IN_EXECUTION = "in execution"   # At this time, Script is inside a process
SUCCESS      = "success"        # The script has terminated in a successfull way
ERROR        = "error"          # The script has returned something bad... (Raised an exception ?)

def wrap_func_call(func, args, kwargs):
    """
        Call a function, with the needed args
    """
    accept = inspect.getargspec(func)
    if accept.varargs and accept.keywords:
        result = func(*args, **kwargs)
    elif not accept.varargs and accept.keywords:
        result = func(**kwargs)
    elif accept.varargs and not accept.keywords:
        result = func(*args)
    elif not accept.args:
        result = func()
    elif len(args) == len(accept.args):
        result = func(*args)
    else:
        data = {}
        for key in accept.args[len(args):]:
            if key in kwargs:
                data.update({key: kwargs[key]})
        result = func(*args, **data)
    return result

class Script():
    """
        Script class
        The main part of Batch
    """
    def __init__(self, name=None, func=None):
        """
            Init a script
            name is the readable name of script (Default will be __module__+'.'+__name__)
            func is the original functions to call
            complete/success/error are scripts list that we must wait before making job
        """
        if func and not isinstance(func, types.FunctionType):
            raise Exception("Only functions are convertible to Script")

        # The script as it is written by the job
        self.func = func

        # Docstring
        self.doc = self.func.__doc__

        # Define pretty name for this script
        if name:
            self.name = name
        elif self.func:
            self.name = self.func.__name__
        else:
            self.name = "noname script"

        if self.func:
            # Like this script is a launchable one, we add it to the ScriptManager
            # in order to be trigerred by "run"
            add_script(self)

        # What's this script ?
        # Is it a function (=> a real script)
        # Or a set of multiple one, linked by logical vars between them
        if self.func:
            self.mode = MODE_SCRIPT
            self.status = NOT_EXECUTED
        else:
            self.mode = MODE_UNKNOWN
            self.status = NOT_A_SCRIPT

        # Save the pid numbers of scripts master
        self.pid = None

        # The sub scripts
        # used with mode OR and AND
        self.scripts = []

        # self.wait contains a list of function that we must wait
        self.wait = []

        # For plugins and various things
        # for now only before, and after are implemented (but on_success, on_error ...) could be imaginated.
        self.callbacks = {
            "before": [],
            "after": []
        }

        # Default args used by @runmth
        self.args = []

    def import_info(self):
        """
            return the needed information, that we should transmit to worker,
            in order it is able to reimport the same script.
        """
        if self.func:
            return (os.path.dirname(sys.modules[self.func.__module__].__file__), self.func.__module__, self.func.__name__)
        else:
            return (None, None, None)


    def complete(self):
        """
            Used to know if this script is complete or no
            A complete script, is a script that have been executed and have terminated
            Don't precise if it was a successefull way or an erroneous one
        """
        if self.status == NOT_A_SCRIPT:
            if self.mode == MODE_OR:
                for script in self.scripts:
                    if script.complete():
                        return True
                return False
            elif self.mode == MODE_AND:
                for script in self.scripts:
                    if not script.complete():
                        return False
                return True
            else:
                raise Exception("You asked me to know the status of an '{}' script...".format(self.mode))
        return self.status == SUCCESS or self.status == ERROR

    def success(self):
        """
            Return true if the script has terminated in a successfull way
        """
        if self.status == NOT_A_SCRIPT:
            if self.mode == MODE_OR:
                for script in self.scripts:
                    if script.success():
                        return True
                return False
            elif self.mode == MODE_AND:
                for script in self.scripts:
                    if not script.success():
                        return False
                return True
            else:
                raise Exception("You asked me to know the status of an '{}' script...".format(self.mode))
        return self.status == SUCCESS

    def error(self):
        """
            Return true if the script has terminated in an erroneous way
        """
        if self.status == NOT_A_SCRIPT:
            if self.mode == MODE_AND:
                for script in self.scripts:
                    if not script.error():
                        return False
                return True
            elif self.mode == MODE_OR:
                for script in self.scripts:
                    if script.error():
                        return True
                return False
            else:
                raise Exception("You asked me to know the status of an '{}' script...".format(self.mode))
        return self.status == ERROR

    def reset_status(self):
        """
            When status are updated in wait_complete, wait_success and wait_error.
            we need to replace script that where in status == "ERROR/SUCCESS" to
            status NOT_EXECUTED to be ready for a new execution if needed
            It only apply to script that are in MODE_SCRIPT
        """
        if self.mode != MODE_SCRIPT:
            return
        if self.status == ERROR or self.status == SUCCESS:
            self.status = NOT_EXECUTED

    def add_wait(self, operator, mode, *objs):
        """
            Generic function to add the waits scripts (and functions)
        """
        objs = list(objs)
        for obj in objs:
            if isinstance(obj, types.FunctionType):
                if operator == "AND":
                    self.wait.append(objs.pop(obj))
                    continue
                else:
                    raise Exception("Wait function in mode {} is not implemented".format(mode))
            if isinstance(obj, Script):
                continue
            if isinstance(obj, list):
                objs.remove(obj)
                objs.extend(obj)
                continue
            if isinstance(obj, tuple):
                objs.remove(obj)
                for o in obj:
                    objs.append(o)
                continue
            raise Exception("Cannot wait object of type {}".format(type(obj)))

        if len(objs) > 1:
            newscript = Script()
            for script in objs:
                if operator == "AND":
                    newscript._and(script)
                else:
                    newscript._or(script)
            self.wait.append(getattr(newscript, mode))
        elif len(objs) == 1:
            self.wait.append(getattr(objs[0], mode))


    def wait_complete(self, *scripts):
        self.add_wait("AND", "complete", *scripts)

    def wait_error(self, *scripts):
        self.add_wait("AND", "error", *scripts)

    def wait_success(self, *scripts):
        self.add_wait("AND", "success", *scripts)

    def wait_any_complete(self, *scripts):
        self.add_wait("OR", "complete", *scripts)

    def wait_any_error(self, *scripts):
        self.add_wait("OR", "error", *scripts)

    def wait_any_success(self, *scripts):
        self.add_wait("OR", "success", *scripts)


    def ready(self, steps=None):
        """
            Return if all the self.wait functions are True
        """
        if self.status != NOT_EXECUTED:
            return False
        for fn in self.wait:
            # recovery : don't ask to execute the @wait if it's not in selected steps
            # in other words: what is not in steps is already 'done' conceptually
            if steps and fn.im_self.name not in steps:
                continue
            if not fn():
                return False
        return True

    ############################################################################
    ##
    ##  Logical operators between scripts
    ##  And various magical methods
    ##
    ############################################################################
    def _or(self, script):
        """
            Internal methods to define what result of s1 | s2
            It result to a script without function who links the two one
        """
        self.mode = MODE_OR
        self.scripts.append(script)

    def _and(self, script):
        """
            Internal methods to define what result of s1 & s2
            It result to a script without function who links the two one
        """
        self.mode = MODE_AND
        self.scripts.append(script)

    def __or__(self, script):
        """
            Magic method to handle the or operator |
        """
        if self.mode == MODE_OR:
            self._or(script)
            return self
        else:
            s = Script()
            s._or(self)
            s._or(script)
            return s

    def __and__(self, script):
        """
            Magic method to handle the and operator &
        """
        if self.mode == MODE_AND:
            self._and(script)
            return self
        else:
            s = Script()
            s._and(self)
            s._and(script)
            return s

    def __str__(self, depth=1):
        """
            Magic method to print the script
        """
        if self.mode == "script":
            return self.name
        elif depth > 5:
            return "..."
        else:
            l = []
            for s in self.scripts:
                l.append(s.__str__(depth+1))
            return "(" + self.mode.join(l) + ")"

    def __call_function(self, *args, **kwargs):
        """
            Call the function behind a Script
            Used by workers and when writing a script and calling it directly from PyScripter
            (or other IDE)
            *args and **kwargs are only used for direct call, in "batch use"
            When worker call a function all args must be named one, and they will be
            taken from ENV.
            Return of function is only used for saying if result is SUCCESS or ERROR.
        """
        from .functions import dbg

        # Call the before callabacks
        for (c_func, c_args, c_kwargs) in self.callbacks['before']:
            try:
                wrap_func_call(c_func, [self] + c_args, c_kwargs)
            except Exception as e:
                dbg(self.name, "A before callbacks as raised an exception", type(e), e)

        result = wrap_func_call(self.func, self.args + list(args), kwargs)

        # Call the end callabacks
        for (c_func, c_args, c_kwargs) in self.callbacks['after']:
            try:
                wrap_func_call(c_func, [self] + c_args, c_kwargs)
            except Exception as e:
                dbg(self.name, "A end callbacks as raised an exception", type(e), e)

        return result

    def __call__(self, *args, **kwargs):
        """
            magic method that transform Script instance into a callable
            This is this way that we launch a batch script
        """
        if self.mode == MODE_SCRIPT:
            return self.__call_function(*args, **kwargs)
        raise Exception("Script mode {} are not callable".format(self.mode))

    def set_executed(self, status=SUCCESS):
        """
            This script has been successfully executed
        """
        self.status = status
        self.pid = None

    def set_inqueue(self):
        """
            This script have been pushed to Queue, it will be started has soon as
            a worker will be available for him
        """
        self.status = IN_QUEUE
        self.pid = None

    def set_inexecution(self, pid):
        """
            This script has entered in execution mode.
            The worker handling this script has pid = pid
        """
        self.status = IN_EXECUTION
        self.pid = pid

    def set_exception(self, exception):
        """
            This script has raised this exception during execution...
        """
        self.status = ERROR
        self.pid = None
