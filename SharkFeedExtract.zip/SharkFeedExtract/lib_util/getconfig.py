#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals  
from __future__ import print_function
import os
import configparser

from . import lib_log
from .get_server_config import GetServerConfig

__version__='1.0'


class GetConfig(object):
    """
    Pass the config.ini file path, it extracts the parameters, loads the values in to variable, and verifies path


    example::

        self.config_par = GetConfig(config_file)
        self.server = self.config_par.config.get('feed', 'server').strip()
        self.database = self.config_par.config.get('feed', 'database').strip()
        self.output = self.config_par.config.get('feed', 'output').strip()
    """

    def __init__(self, configfile):
        self.server_config = GetServerConfig()
        self.config_file = self.server_config.get_dir_for_current_host(configfile)
        self.current_filename = os.path.basename(__file__).replace(".py","")
        
        # self.config = object
        self.read_config()
        self.verify_parameter()

    def read_config(self):
        """
        Read config file and load parameters to the variables
        """
        self.config = configparser.ConfigParser()
        self.config.read(self.config_file)

    def verify_parameter(self):
        """
        Verify all paths passed in software.ini file
        """
        logger = lib_log.Logger()
        # Feed Parameter
        try:
            script_path = self.config.get('feed', 'scriptpath').strip()
            script_path = self.server_config.get_dir_for_current_host(script_path)
        except:
           logger.write_dbg("Missing script_path value")
           raise ValueError
        try:
            server = self.config.get('feed', 'server').strip()
        except:
            logger.write_dbg("Missing server value in software.ini file")
            raise ValueError     
        try:
            database = self.config.get('feed', 'database').strip()
        except:
            logger.write_dbg("Missing database value in software.ini file")
            raise ValueError
        try:
            output = self.config.get('feed', 'output').strip()
            output = self.server_config.get_dir_for_current_host(output)
        except:
            logger.write_dbg("Missing output value in software.ini file")
            raise ValueError
        if not os.path.isdir(script_path):
            logger.write_dbg("Directory doesnt exists!!! sqlpath:{0} ".format(script_path))
            raise ValueError(
                "Directory doesnt exists!!! sqlpath:{0} ".format(
                    script_path))
        if not os.path.isdir(output):
            logger.write_dbg("Directory doesnt exists!!! output:{0} ".format(
                    output))
            raise ValueError(
                "Directory doesnt exists!!! output:{0} ".format(
                    output))
