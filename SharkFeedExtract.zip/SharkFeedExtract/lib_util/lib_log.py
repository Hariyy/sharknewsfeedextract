# -*- coding: utf-8 -*-
# mguffroy 15/02/2013 - datetime.datetime.now() -> datetime.datetime.utcnow()
#                       It's better like script can run all over the earth ^^
# -------------------------------------------------------------------------------
# Name:        logger library
# Purpose:     Allows to write in log/dbg files
#
# Author:      ccazarre
#
# Created:     27/07/2012
# Copyright:   (c) FactSet 2012
# -------------------------------------------------------------------------------

from __future__ import print_function
from __future__ import unicode_literals
import os
import datetime
import traceback
import sys
import codecs

class Logger:
    def __init__(self):
        """
        Creates a logger (dbg or log files writter)
        The dump of message is made both in console and in the file
        The file is normally created near by the principal .py file (the one with name=='__main__')
        """
        main_py_file = None

        for filename, line, function, code in traceback.extract_stack():
            # However, for the specific case of PyScrypter, the main becomes remserver.py
            # so we investigate the stack and keep the first unamed module which will be ours
            # because of this, we cannot directly use inspect.stack()[-1][1]
            if os.path.isfile(filename):
                path = os.path.normpath(filename)
                path_list = path.split(os.sep)
                if not 'Python36_64' in path_list and not 'batch_lib.pyz' in path_list and not 'deef.pyz' in path_list and not 'spawn.py' in path_list and not 'process.py' in path_list:
                    main_py_file = path_list[len(path_list) - 1]
                    break
            if os.path.split(filename)[1].lower() == 'remserver.py':
                continue
            # Same kind of specific case with Visual Studio 2012
            if os.path.split(filename)[1].lower() == 'visualstudio_py_launcher.py':
                continue
            if function.lower() == '<module>':
                if filename == "<string>":
                    continue
                main_py_file = filename
                break
        # Could not get the file???? Console print and default to current file
        if main_py_file is None:
            print('Unable to determine the main .py, defaulting to {0}'.format(__file__))
            main_py_file = __file__

        # manage the .pyz case
        if ".pyz" in main_py_file:
            main_py_file = main_py_file.split(".pyz")[0]

        if("forking" in main_py_file.lower()):
            for x in [x for x in sys.argv if 'runner.py' not in x.lower() and '.py' in x.lower()]:
                main_py_file = os.path.basename(x[:x.find(".py")+3])
                break

        self.log_filename = main_py_file.replace('.py', '') + '.log'
        self.dbg_filename = main_py_file.replace('.py', '') + '.dbg'

    def write_log(self, message, print_to_console_also=True):
        """
        Dumps a message in the module's log file
        Stamp is NOW UTC
        """
        with codecs.open(self.log_filename, 'a', 'utf-8-sig') as logfile:
            buffer_to_write = str(datetime.datetime.now())
            buffer_to_write += ';'
            buffer_to_write += message
            buffer_to_write += '\n'
            self.__write(logfile, buffer_to_write, print_to_console_also)

    def write_dbg(self, message, print_to_console_also=True, stack=False):
        """
        Dumps a message in the module's dbg file
        Also dumps stack trace till just before the current function
            IF STACK = TRUE
        Stamp is NOW UTC
        """
        with codecs.open(self.dbg_filename, 'a', 'utf-8-sig') as logfile:
            max_size = 0
            current_actions = []
            if stack:
                for filename, line, function, code in reversed(traceback.extract_stack()):
                    if function == 'write_dbg':
                        continue
                    report = '\tModule {0}, line {1}, in {2}'.format(os.path.split(filename)[1], line, function)
                    max_size = max(max_size, len(report))
                    current_actions.append((report, code))
                    if function == '<module>':
                        break;
            buffer_to_write = str(datetime.datetime.now())
            buffer_to_write += ';'
            buffer_to_write += message
            buffer_to_write += '\n'
            if stack:
                for action in current_actions:
                    buffer_to_write += action[0].ljust(max_size)
                    if action[1]:
                        buffer_to_write += '\t' + action[1].strip()
                    buffer_to_write += '\n'
            self.__write(logfile, buffer_to_write, print_to_console_also, file=sys.stderr)

    def write_log_and_dbg(self, message, print_to_console_also=True):
        self.write_dbg(message, print_to_console_also)
        self.write_log('ERROR: {0}'.format(message), False)

    def __write(self, logfile, message, print_to_console_also, file=sys.stdout):
        logfile.write(message)
        if print_to_console_also:
            print(message.replace('\r\n', '\r').replace('\n', '\r').encode('mbcs'), file=file)


def run_with_try_except(function, *args, **kwargs):
    """
    Calls a method/function in a safe fashion (no exception should be escape out of the run_with_try_except)
    If any exception occures, it will trapped and a dbg with stack trace will be generated nearby the main py file
    Excepted signature of the called function is by default:
        def myfunction(*args, **kwargs)
    However, the magic here is that you may also write:
        def myfunction(x)
    Exemple of use:
        impot lib_log
        lib_log.run_with_try_except(myfunction)
        lib_log.run_with_try_except(myfunction, x = 2)
    """
    try:
        function(*args, **kwargs)
    except Exception as e:
        Logger().write_dbg(unicode(e))
