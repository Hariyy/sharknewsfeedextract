#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals  
from __future__ import print_function
import datetime
from .get_server_config import GetServerConfig

__version__='1.0'

class GetFileName():
    """
    It is used to generate file names. We can generate file name with sequence number in it or timestamp in it
    """

    def __init__(self):
        self.dic = dict()
        self.filename = ''
        self.timezone = ''
        self.server_config = GetServerConfig()

    def create_dict(self):
        self.dic['[YYYY]']= self.year
        self.dic['[MM]']=self.month
        self.dic['[DD]']=self.day
        self.dic['[HH]']=self.hour
        self.dic['[TT]']=self.minute
        self.dic['[SS]']=self.seconds
        self.dic['[FY]']=self.year
        self.dic['[FM]']=self.month
        self.dic['[FD]']=self.day
        self.dic['[PH]']=self.hour
        self.dic['[PT]']=self.minute
        self.dic['[PS]']=self.seconds
        self.dic['[ST]']=self.st

    def get_time_variables(self):
        """
        **Objective**
            It is used to convert the datetime parameters to string and build the timestamp

        :return:
        """
        if self.timezone.lower()=='utc':
            date = datetime.datetime.utcnow()
        else:
            date = datetime.datetime.now()
        self.year = date.strftime('%Y')
        self.month = date.strftime('%m')
        self.day = date.strftime('%d')
        self.hour = date.strftime('%H')
        self.minute = date.strftime('%M')
        self.seconds = date.strftime('%S')
        self.st = self.hour+'_'+self.minute

    def get_filename_timestamp(self, filename, timezone='utc'):
        """
        **Objective**
            This function is used to generate the file name with time stamp

        :param filename: pass the zip filename with the format you want
        :param timezone: pass the time zone, default is 'utc'
                'est'
                'utc'


        example::

            # using timestamp in the zip filename
            # i.e.
            # entity_naics_industry_map_[FY][FM][FD][HH][TT].zip
            # entity_naics_industry_map_[YYYY][MM][DD][HH][TT].zip

            ENV.define("zip_filename", "inc_filermst_[YYYY][MM][DD].zip")
            get_file_name = get_filename.GetFileName()
            zip_filename_timestamp_0 = get_file_name.get_filename_timestamp(zip_filename, 'est')
        """
        self.timezone = timezone
        self.filename = filename
        self.get_time_variables()
        self.create_dict()
        for old, new in self.dic.items():
            self.filename = self.filename.replace(old, new)
        return self.filename

    def get_filename_seqnumber(self, filename, filepath, is_calc_path = True):
        """
        **Objective**
            This function is used to generate filename with sequence number

        :param filename: pass the filename to begin with
                i.e.
                'entity_naics_industry_map' will resul into entity_naics_industry_map_943.zip
        :param filepath: provide the path from where we can get the last sequence number


        example::

            # using the sequence number in the zip filename

            ENV.define("zip_filename_0", "entity_v1_full_#.zip")
            ENV.define("sequence_number_file", base_directory + "sequence_number.ini")

            get_file_name = get_filename.GetFileName()
            zip_filename, sequence_number = get_file_name.get_filename_seqnumber(zip_filename_0, sequence_number_file)
        """
        sequence_number = 0
        filepath = self.server_config.get_dir_for_current_host(filepath, is_calc_path)
        file_obj = open(filepath, 'r')
        for line in file_obj:
            if 'sequence_number' in line:
                string_array = line.split('=')
                file_obj.close()
                sequence_number = int(string_array[1])+1
                break
        file_obj.close()
        return filename.replace('#', str(sequence_number)), sequence_number              
        
