sql
===
Objective:
----------
1. To specify and run SQL
2. Captures the data into dataframe (memory)  
3. Transform the data into dataframe (triming, convert, encoding, etc)
4. Create the output files

Functions:
----------

.. automodule:: sql
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance: